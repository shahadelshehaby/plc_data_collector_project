"""
Engineering City - backend (each building holds floors; each program floor is one platform).

Each program floor is watched in two ways, and neither changes the program:
  1. From the outside: its Python process (found by its port) is measured like Task Manager:
     CPU, GPU, memory and I/O. These become an auto-calibrated activity score and a health light.
  2. From the inside, if the platform offers it: the read-only page /building/status tells the
     building its team, current step and how many items it has processed. Items x the manual
     minutes of each role = the engineers' work the platform is doing.
Serves the building at http://127.0.0.1:5050
"""
import ast
import csv
import io
import json
import math
import operator
import random
import os
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from concurrent.futures import ThreadPoolExecutor

import psutil
from flask import Flask, jsonify, request, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
SETTINGS_PATH = os.path.join(HERE, "building_settings.json")
TRACKING_PATH = os.path.join(HERE, "building_tracking.json")
CPU_COUNT = psutil.cpu_count() or 1
WORK_WINDOW_MIN = 60          # people = engineers' work averaged over the last hour


# =============================================================== defaults
def _row(key, label, expr, unit="", show=False):
    return {"key": key, "label": label, "expr": str(expr), "unit": unit, "show": show}


def SUGGESTED_MODEL():
    """Works for any platform: uses the live counters and the team's minutes per item."""
    return [
        _row("productive_hours", "Productive hours per engineer per day", 7, "h"),
        _row("hourly_cost", "Engineer cost per hour (your currency)", 0, ""),
        _row("hours_saved_today", "Engineer hours done by the platform today",
             "items_today * automated_minutes / 60", "h", True),
        _row("hours_by_engineers_today", "Engineer hours still needed today",
             "items_today * human_minutes / 60", "h", True),
        _row("engineers_saved_today", "Engineers' work saved today",
             "hours_saved_today / productive_hours", "engineers", True),
        _row("cost_saved_today", "Cost saved today", "hours_saved_today * hourly_cost", "", False),
    ]


CAMERA_JD = {
    "description": (
        "Monitors the health of every camera across terminals, equipment types and machines. "
        "On a daily schedule (with a configurable start time, window and minimum gap between "
        "cameras so the network is never overloaded), or on demand for a chosen terminal, "
        "equipment type, machine or single camera, it captures a snapshot from each active "
        "camera and diagnoses it as OK, no view, too dark, overexposed, green, blue or red tint, "
        "dirty or blurry lens, or partial occlusion, each with a confidence level. Engineers "
        "verify each result, and the platform reuses their past verdicts for the same camera "
        "so it learns what normal looks like for each unit."),
    "steps": [
        "Capture a snapshot from each active camera on a staggered schedule, or on demand",
        "Diagnose the image and score its confidence",
        "Match the result against engineers' past verdicts for that camera",
        "Engineer verification (same as detected, normal, old camera, other issue)",
        "Single, batch and filtered PDF reports, plus CSV export"],
}

STYLES = ("tech", "loft", "studio")
LAYOUTS = ("a", "b", "c")
ID_RE = re.compile(r"^[a-z0-9_-]{1,40}$")


def program_template():
    return {"kind": "program", "floor": "New floor", "name": "New program", "title": "New program",
            "visible": True, "shield": False, "url": "", "status_path": "/building/status",
            "match_mode": "port", "match_text": "", "style": "tech", "layout": "a",
            "jd": {"description": "", "steps": []}, "team": [], "model": SUGGESTED_MODEL()}


def existing_template():
    return {"kind": "existing", "floor": "New floor", "name": "Existing building", "visible": True}


DEFAULT_FLOORS = [   # bottom to top
    {**existing_template(), "id": "ground", "floor": "Ground floor"},
    {**existing_template(), "id": "first", "floor": "Floor 1"},
    {**program_template(), "id": "camera", "floor": "Floor 2", "name": "Camera platform",
     "title": "Camera Health Platform", "url": "http://127.0.0.1:5002/", "style": "tech", "layout": "a",
     "jd": CAMERA_JD},
    {**program_template(), "id": "fdd", "floor": "Floor 3", "name": "FDD", "title": "Fault Detection and Diagnosis",
     "url": "http://127.0.0.1:5000/", "style": "loft", "layout": "b",
     "jd": {"description": "Fault detection and diagnosis for equipment using PLC data: maps signals to "
                           "equipment, runs diagnostic rules over the history and matches them against known "
                           "faults, so engineers see real faults with likely causes instead of raw alarms.",
            "steps": ["Import PLC data and the fault list", "Map signals to equipment and faults",
                      "Run diagnostic rules over the history", "Evaluate rules against recorded faults"]}},
    {**program_template(), "id": "ai", "floor": "Floor 4", "name": "AI performance", "title": "AI Performance",
     "style": "studio", "layout": "c",
     "jd": {"description": "Monitors how well AI models perform over time: collects predictions and real "
                           "outcomes, calculates accuracy, checks for drift and raises alerts when performance drops.",
            "steps": ["Collect predictions and outcomes", "Calculate performance metrics",
                      "Check for drift", "Raise alerts"]}},
]
FACADES = ("sand", "stone", "glass", "brick", "white", "slate")


def building_template():
    return {"name": "New building", "location": "", "visible": True, "facade": "stone",
            "x": None, "z": None, "w": None, "d": None, "floors": []}


DEFAULT_BUILDINGS = [
    {**building_template(), "id": "eng", "name": "Engineering Building", "facade": "sand",
     "floors": [DEFAULT_FLOORS[0], DEFAULT_FLOORS[1], DEFAULT_FLOORS[2], DEFAULT_FLOORS[3]]},
    {**building_template(), "id": "analytics", "name": "Analytics Centre", "facade": "glass",
     "floors": [{**existing_template(), "id": "an_ground", "floor": "Ground floor"},
                {**DEFAULT_FLOORS[4], "floor": "Floor 1"}]},
]
DEFAULTS = {"port": 5050, "refresh_seconds": 3, "city_name": "Engineering City", "buildings": DEFAULT_BUILDINGS}

app = Flask(__name__, static_folder=os.path.join(HERE, "static"))
settings_lock = threading.Lock()


# =============================================================== settings
def _merge(base, extra):
    out = json.loads(json.dumps(base))
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        elif k in out:
            out[k] = v
    return out


def _clean_team(team):
    out = []
    for r in team or []:
        role = str(r.get("role", "")).strip()
        if not role:
            continue
        try:
            minutes = float(r.get("manual_minutes_per_item", r.get("minutes", 0)) or 0)
        except (TypeError, ValueError):
            minutes = 0.0
        out.append({"role": role, "description": str(r.get("description", "") or ""),
                    "automated": bool(r.get("automated")), "manual_minutes_per_item": max(0.0, minutes)})
    return out


def normalize_floor(f):
    tpl = program_template() if f.get("kind") == "program" else existing_template()
    out = _merge(tpl, f)
    out["id"] = str(f.get("id", ""))
    if out["kind"] == "program":
        out["style"] = out["style"] if out["style"] in STYLES else "tech"
        out["layout"] = out["layout"] if out["layout"] in LAYOUTS else "a"
        out["team"] = _clean_team(out["team"])
        if not out["status_path"].startswith("/"):
            out["status_path"] = "/" + out["status_path"]
    return out


def normalize_building(b):
    floors = b.get("floors") or []
    out = _merge(building_template(), {k: v for k, v in b.items() if k != "floors"})
    out["id"] = str(b.get("id", ""))
    out["facade"] = out["facade"] if out["facade"] in FACADES else "stone"
    for k in ("x", "z", "w", "d"):
        try:
            out[k] = float(out[k]) if out[k] is not None else None
        except (TypeError, ValueError):
            out[k] = None
    out["floors"] = [normalize_floor(f) for f in floors]
    return out


def _migrate(saved):
    """Older settings had one building ("floors" at the top level); turn it into a city of one."""
    floors = saved.get("floors")
    if isinstance(floors, dict):          # very first version stored three programs in a dict
        lst = [dict(DEFAULT_FLOORS[0]), dict(DEFAULT_FLOORS[1])]
        for d in DEFAULT_FLOORS[2:]:
            old = floors.get(d["id"], {})
            lst.append({**d, **{k: v for k, v in old.items() if k in d}})
        floors = lst
    if "buildings" not in saved and isinstance(floors, list):
        saved["buildings"] = [{**building_template(), "id": "eng", "name": "Engineering Building",
                               "facade": "sand", "floors": floors}]
        saved.setdefault("city_name", "Engineering City")
    saved.pop("floors", None)
    return saved


# ---------------- random city layout
GAP = 45


def _overlaps(a, b):
    return not (a["x"] + a["w"] + GAP <= b["x"] or b["x"] + b["w"] + GAP <= a["x"] or
                a["z"] + a["d"] + GAP <= b["z"] or b["z"] + b["d"] + GAP <= a["z"])


def place_buildings(buildings, only=None, resize=True):
    """Gives buildings (all, or the ids in `only`) a random size and a free random spot."""
    rnd = random.Random()
    fixed = [b for b in buildings if b["x"] is not None and (only is not None and b["id"] not in only)]
    todo = [b for b in buildings if b not in fixed]
    n = max(1, len(buildings))
    span_x, span_z = 300 + 230 * math.ceil(math.sqrt(n)), 200 + 160 * math.ceil(math.sqrt(n))
    for b in todo:
        if resize or b["w"] is None:
            b["w"], b["d"] = float(rnd.randint(120, 200)), float(rnd.randint(75, 125))
        for attempt in range(4000):
            grow = 1 + attempt // 800 * 0.25
            b["x"] = float(rnd.randint(0, int(span_x * grow - b["w"])))
            b["z"] = float(rnd.randint(0, int(span_z * grow - b["d"])))
            if not any(_overlaps(b, o) for o in fixed):
                break
        fixed.append(b)
    return buildings


def load_settings():
    with settings_lock:
        saved = {}
        if os.path.exists(SETTINGS_PATH):
            try:
                with open(SETTINGS_PATH, encoding="utf-8") as fh:
                    saved = _migrate(json.load(fh))
            except Exception:
                saved = {}
        s = {"port": saved.get("port", DEFAULTS["port"]),
             "refresh_seconds": saved.get("refresh_seconds", DEFAULTS["refresh_seconds"]),
             "city_name": saved.get("city_name") or DEFAULTS["city_name"]}
        s["buildings"] = [normalize_building(b) for b in (saved.get("buildings") or DEFAULT_BUILDINGS)]
        missing = [b["id"] for b in s["buildings"] if None in (b["x"], b["z"], b["w"], b["d"])]
        if missing:
            place_buildings(s["buildings"], only=set(missing), resize=False)
            with open(SETTINGS_PATH, "w", encoding="utf-8") as fh:
                json.dump(s, fh, indent=2)
        return s


def save_settings(s):
    with settings_lock:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as fh:
            json.dump(s, fh, indent=2)


def all_floors(s):
    return [f for b in s["buildings"] for f in b["floors"]]


def program_floors(s):
    return [f for f in all_floors(s) if f["kind"] == "program"]


# =============================================================== formula engine
KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
FUNCS = {"min": min, "max": max, "round": round, "abs": abs, "ceil": math.ceil, "floor": math.floor}
BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
       ast.Pow: operator.pow, ast.Mod: operator.mod}


def _calc(node, get):
    if isinstance(node, ast.Expression):
        return _calc(node.body, get)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.Name):
        return get(node.id)
    if isinstance(node, ast.BinOp) and type(node.op) in BIN:
        return BIN[type(node.op)](_calc(node.left, get), _calc(node.right, get))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        v = _calc(node.operand, get)
        return -v if isinstance(node.op, ast.USub) else v
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCS \
            and not node.keywords:
        return FUNCS[node.func.id](*[_calc(a, get) for a in node.args])
    raise ValueError("only numbers, names, + - * / ** %, brackets and min/max/round/abs/ceil/floor are allowed")


def evaluate_model(rows, live):
    exprs, out = {}, []
    for r in rows:
        k = str(r.get("key", "")).strip()
        if KEY_RE.match(k):
            exprs[k] = str(r.get("expr", "")).strip()
    cache, busy = {}, set()

    def get(name):
        if name in cache:
            return cache[name]
        if name in exprs:
            if name in busy:
                raise ValueError(f"circular formula: '{name}' ends up using itself")
            busy.add(name)
            try:
                text = exprs[name].replace(",", "") if re.fullmatch(r"[\d,\.]+", exprs[name]) else exprs[name]
                cache[name] = float(_calc(ast.parse(text, mode="eval"), get))
            finally:
                busy.discard(name)
            return cache[name]
        if name in live:
            return float(live[name] or 0)
        raise ValueError(f"unknown name '{name}'")

    for r in rows:
        k = str(r.get("key", "")).strip()
        item = {"key": k, "label": r.get("label", k), "unit": r.get("unit", ""), "show": bool(r.get("show"))}
        if not KEY_RE.match(k):
            item["error"] = "key must be one word: letters, digits, underscore"
        elif not exprs[k]:
            item["error"] = "empty"
        else:
            try:
                item["value"] = get(k)
            except ZeroDivisionError:
                item["error"] = "division by zero"
            except SyntaxError:
                item["error"] = "formula is not valid"
            except Exception as e:
                item["error"] = str(e)
        out.append(item)
    return out


def parse_model_file(name, data):
    """Accepts .json, .csv or .xlsx with columns: key, label, expression (or value/formula), unit, show."""
    ext = os.path.splitext(name.lower())[1]
    if ext == ".json":
        obj = json.loads(data.decode("utf-8-sig"))
        table = obj.get("model", obj) if isinstance(obj, dict) else obj
    elif ext == ".csv":
        table = list(csv.DictReader(io.StringIO(data.decode("utf-8-sig"))))
    elif ext in (".xlsx", ".xlsm"):
        import openpyxl
        ws = openpyxl.load_workbook(io.BytesIO(data), data_only=False, read_only=True).active
        it = ws.iter_rows(values_only=True)
        head = [str(h or "").strip() for h in next(it)]
        table = [dict(zip(head, r)) for r in it if any(c is not None for c in r)]
    else:
        raise ValueError("Use a .xlsx, .csv or .json file")
    rows = []
    for t in table:
        low = {str(k).strip().lower(): v for k, v in dict(t).items()}
        expr = next((low[k] for k in ("expression", "expr", "formula", "value") if low.get(k) not in (None, "")), "")
        expr = str(expr).lstrip("=")          # allow Excel-style "=a*b"
        key = str(low.get("key") or "").strip()
        if not key:
            continue
        show = str(low.get("show", "")).strip().lower() in ("1", "true", "yes", "y", "x")
        rows.append(_row(key, str(low.get("label") or key), expr, str(low.get("unit") or ""), show))
    if not rows:
        raise ValueError("No rows found. The first row must be headers: key, label, expression, unit, show")
    return rows
LIVE_VARS = ("cpu", "gpu", "memory_mb", "running", "activity", "items_today", "items_last_hour",
             "issues_today", "automated_minutes", "human_minutes", "platform_engineers", "human_engineers")


# =============================================================== platform status page
def fetch_status(url, path, timeout=1.0):
    """Reads the platform's /building/status page. Returns (data, error)."""
    if not url:
        return None, "no address"
    full = urllib.parse.urljoin(url if url.endswith("/") else url + "/", path.lstrip("/"))
    try:
        with urllib.request.urlopen(full, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        if not isinstance(data, dict):
            return None, "the page did not return a JSON object"
        return data, None
    except urllib.error.HTTPError as e:
        return None, f"no status page ({e.code})"
    except Exception as e:
        return None, str(e)


def _num(v):
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


# =============================================================== process monitor
PROCS = {}            # pid -> psutil.Process, kept so CPU % is measured between samples
IO_PREV = {}          # floor id -> (bytes, time, pid set)
GPU = {"ok": None, "by_pid": {}}
SNAP, SNAP_LOCK = {}, threading.Lock()
TRACK, TRACK_LOCK = {}, threading.Lock()   # per floor: per-minute history used for calibration and health
WORK = {}             # floor id -> deque of (time, items_total, items_today) from the status page
pool = ThreadPoolExecutor(max_workers=8)


def _port(url):
    try:
        return urllib.parse.urlparse(url).port
    except ValueError:
        return None


def _with_children(pids):
    out = set()
    for pid in pids:
        try:
            p = psutil.Process(pid)
            out.add(pid)
            out.update(c.pid for c in p.children(recursive=True))
        except psutil.Error:
            pass
    return out


def _find_pids(floor, listeners):
    me = os.getpid()
    if floor["match_mode"] == "cmd" and floor["match_text"].strip():
        needle = floor["match_text"].strip().lower()
        pids = set()
        for p in psutil.process_iter(["pid", "cmdline"]):
            try:
                if p.info["pid"] != me and needle in " ".join(p.info["cmdline"] or []).lower():
                    pids.add(p.info["pid"])
            except psutil.Error:
                pass
        return pids
    port = _port(floor["url"])
    return {listeners[port]} if port in listeners else set()


def _measure(fid, pids):
    cpu = mem = 0.0
    io_bytes = 0
    for pid in pids:
        try:
            proc = PROCS.get(pid)
            if proc is None or not proc.is_running():
                proc = PROCS[pid] = psutil.Process(pid)
                proc.cpu_percent(None)
            cpu += proc.cpu_percent(None)
            try:
                mem += proc.memory_full_info().uss
            except psutil.Error:
                mem += proc.memory_info().rss
            try:
                c = proc.io_counters()
                io_bytes += c.read_bytes + c.write_bytes      # on Windows this includes network traffic
            except (psutil.Error, AttributeError):
                pass
        except psutil.Error:
            PROCS.pop(pid, None)
    now = time.time()
    prev = IO_PREV.get(fid)
    io_rate = 0.0
    if prev and prev[2] == frozenset(pids) and now > prev[1]:
        io_rate = max(0.0, (io_bytes - prev[0]) / (now - prev[1]))
    IO_PREV[fid] = (io_bytes, now, frozenset(pids))
    gpu = min(100.0, sum(GPU["by_pid"].get(pid, 0.0) for pid in pids)) if GPU["ok"] else None
    return round(cpu / CPU_COUNT, 1), (round(gpu, 1) if gpu is not None else None), round(mem / 1048576, 1), io_rate / 1048576


# ---------- per-minute history: calibration, uptime, restarts, memory trend
def _track(fid):
    with TRACK_LOCK:
        return TRACK.setdefault(fid, {"minutes": [], "cur": None, "restarts": [], "last_pids": [],
                                      "last_running": 0, "stopped_at": 0, "ever_running": False})


def _record(fid, running, cpu, gpu, io, mem, pids):
    t = _track(fid)
    now = time.time()
    minute = int(now // 60)
    cur = t["cur"]
    if cur is None or cur["m"] != minute:
        if cur is not None:
            t["minutes"].append([cur["m"], cur["cpu"], cur["gpu"], cur["io"], cur["mem"], cur["run"]])
            cutoff = minute - 7 * 24 * 60
            while t["minutes"] and t["minutes"][0][0] < cutoff:
                t["minutes"].pop(0)
        cur = t["cur"] = {"m": minute, "cpu": 0.0, "gpu": 0.0, "io": 0.0, "mem": 0.0, "run": 0}
    if running:
        cur["cpu"] = max(cur["cpu"], cpu)
        cur["gpu"] = max(cur["gpu"], gpu or 0.0)
        cur["io"] = max(cur["io"], io)
        cur["mem"] = max(cur["mem"], mem)
        cur["run"] = 1
        main = sorted(pids)
        if t["last_pids"] and main != t["last_pids"]:
            t["restarts"].append(now)                       # the program was restarted
        elif not t["last_pids"] and t["stopped_at"] and now - t["stopped_at"] < 600:
            t["restarts"].append(now)                       # came back within 10 minutes of stopping
        t["last_pids"], t["last_running"], t["ever_running"] = main, now, True
    else:
        if t["last_pids"]:
            t["stopped_at"] = now
        t["last_pids"] = []
    t["restarts"] = [x for x in t["restarts"] if now - x < 86400]


def _p95(values):
    if not values:
        return 0.0
    v = sorted(values)
    return v[min(len(v) - 1, int(len(v) * 0.95))]


MIN_REF = {"cpu": 2.0, "gpu": 5.0, "io": 5.0}


def _calibration(fid):
    t = _track(fid)
    rows = [r for r in t["minutes"] if r[5]]
    learned = len(rows) >= 30
    default = {"cpu": 100.0 / CPU_COUNT, "gpu": 50.0, "io": 5.0}
    if not learned:
        return default, False, len(rows)
    refs = {"cpu": max(MIN_REF["cpu"], _p95([r[1] for r in rows])),
            "gpu": max(MIN_REF["gpu"], _p95([r[2] for r in rows])),
            "io": max(MIN_REF["io"], _p95([r[3] for r in rows]))}
    return refs, True, len(rows)


def _health(fid, configured, running, status_data):
    t = _track(fid)
    now = time.time()
    minute = int(now // 60)
    day = [r for r in t["minutes"] if r[0] >= minute - 1440]
    uptime = round(100 * sum(r[5] for r in day) / len(day), 1) if day else None
    mems = [r[4] for r in t["minutes"] if r[0] >= minute - 120 and r[5]]
    leak = False
    if len(mems) >= 90:
        q = len(mems) // 4
        first, last = sum(mems[:q]) / q, sum(mems[-q:]) / q
        ups = sum(1 for a, b in zip(mems, mems[1:]) if b >= a)
        leak = last > first * 1.3 and last - first > 50 and ups / (len(mems) - 1) > 0.7
    restarts = len(t["restarts"])
    recent_restart = any(now - x < 1800 for x in t["restarts"])
    platform_error = bool(status_data and (status_data.get("status") == "error" or status_data.get("last_error")))
    notes = []
    if not configured:
        state = "off"
    elif not running:
        state = "stopped" if t["ever_running"] else "never"
        if state == "stopped":
            notes.append("The program stopped. Restart it with its run.bat.")
    else:
        state = "ok"
        if recent_restart:
            notes.append("Restarted in the last 30 minutes.")
        if leak:
            notes.append("Memory has kept rising for two hours; it may be leaking memory.")
        if platform_error:
            notes.append("The platform reports an error: " + str(status_data.get("last_error") or "unknown"))
        if notes:
            state = "warn"
    stopped_since = t["stopped_at"] if (state == "stopped" and t["stopped_at"]) else None
    return {"state": state, "uptime_24h": uptime, "restarts_24h": restarts, "memory_leak": leak, "notes": notes,
            "stopped_since": stopped_since}


def _work(fid, status_data, settings_team):
    """Items processed in the last hour, from the platform's status page."""
    if not status_data:
        WORK.pop(fid, None)
        return None
    c = status_data.get("counters") or {}
    items_today, items_total = _num(c.get("items_today")), _num(c.get("items_total"))
    last_hour = _num(c.get("items_last_hour"))
    now = time.time()
    hist = WORK.setdefault(fid, deque())
    hist.append((now, items_total, items_today))
    while hist and now - hist[0][0] > WORK_WINDOW_MIN * 60 + 120:
        hist.popleft()
    if last_hour is None and len(hist) > 1:
        old = next((h for h in hist if now - h[0] <= WORK_WINDOW_MIN * 60), hist[0])
        if items_total is not None and old[1] is not None:
            last_hour = max(0.0, items_total - old[1])
        elif items_today is not None and old[2] is not None:
            last_hour = items_today - old[2] if items_today >= old[2] else items_today   # new day started
    team = settings_team or _clean_team(status_data.get("team"))
    auto_min = sum(r["manual_minutes_per_item"] for r in team if r["automated"])
    human_min = sum(r["manual_minutes_per_item"] for r in team if not r["automated"])
    lh = last_hour or 0.0
    job = status_data.get("current_job") or {}
    return {"items_today": items_today, "items_last_hour": last_hour,
            "issues_today": _num(c.get("issues_today")),
            "platform_engineers": round(lh * auto_min / WORK_WINDOW_MIN, 2),
            "human_engineers": round(lh * human_min / WORK_WINDOW_MIN, 2),
            "automated_minutes": auto_min, "human_minutes": human_min,
            "team": team, "team_source": "settings" if settings_team else "platform",
            "status": status_data.get("status"), "platform": status_data.get("platform"),
            "step": job.get("step"), "items_done": _num(job.get("items_done")),
            "items_total": _num(job.get("items_total")), "last_error": status_data.get("last_error"),
            "security": status_data.get("security") if isinstance(status_data.get("security"), dict) else None}


def monitor_loop():
    while True:
        s = load_settings()
        try:
            listeners = {}
            for c in psutil.net_connections("tcp"):
                if c.status == psutil.CONN_LISTEN and c.laddr and c.pid:
                    listeners.setdefault(c.laddr.port, c.pid)
        except psutil.Error:
            listeners = {}
        floors = program_floors(s)
        status_jobs = {f["id"]: pool.submit(fetch_status, f["url"], f["status_path"]) for f in floors if f["url"]}
        snap = {}
        for f in floors:
            fid = f["id"]
            configured = bool(f["url"]) or (f["match_mode"] == "cmd" and f["match_text"].strip())
            main = _find_pids(f, listeners) if configured else set()
            pids = _with_children(main)
            if pids:
                cpu, gpu, mem, io = _measure(fid, pids)
            else:
                cpu, gpu, mem, io = 0.0, (0.0 if GPU["ok"] else None), 0.0, 0.0
                IO_PREV.pop(fid, None)
            running = bool(pids)
            _record(fid, running, cpu, gpu, io, mem, main)
            data, err = status_jobs[fid].result() if fid in status_jobs else (None, "no address")
            if not running:
                data = None
            refs, learned, minutes = _calibration(fid)
            parts = {"cpu": cpu / refs["cpu"], "gpu": (gpu or 0) / refs["gpu"], "io": io / refs["io"]}
            score = min(1.0, max(parts.values())) if running else 0.0
            work = _work(fid, data, f["team"])
            snap[fid] = {
                "configured": bool(configured), "running": running, "pids": sorted(main),
                "cpu": cpu, "gpu": gpu, "memory_mb": mem, "io_mbps": round(io, 2),
                "activity": {"score": round(score * 100, 1), "busiest": max(parts, key=parts.get) if running else None,
                             "refs": {k: round(v, 2) for k, v in refs.items()}, "learned": learned,
                             "minutes": minutes},
                "health": _health(fid, configured, running, data),
                "work": work,
                "status_page": {"found": data is not None, "error": None if data is not None else err},
                "team_settings": f["team"],
            }
        with SNAP_LOCK:
            SNAP.clear()
            SNAP.update(snap)
        time.sleep(max(1, int(s["refresh_seconds"])))


def save_tracking_loop():
    while True:
        time.sleep(300)
        try:
            with TRACK_LOCK:
                data = {k: {kk: vv for kk, vv in v.items() if kk != "cur"} for k, v in TRACK.items()}
            with open(TRACKING_PATH, "w", encoding="utf-8") as fh:
                json.dump(data, fh)
        except Exception:
            pass


def load_tracking():
    if os.path.exists(TRACKING_PATH):
        try:
            with open(TRACKING_PATH, encoding="utf-8") as fh:
                data = json.load(fh)
            with TRACK_LOCK:
                for k, v in data.items():
                    v["cur"], v["last_pids"] = None, []
                    TRACK[k] = v
        except Exception:
            pass


GPU_PS = ("$s=(Get-Counter '\\GPU Engine(*)\\Utilization Percentage' -ErrorAction SilentlyContinue).CounterSamples;"
          "foreach($x in $s){$x.InstanceName+'|'+([math]::Round($x.CookedValue,3)).ToString("
          "[cultureinfo]::InvariantCulture)}")


def gpu_loop():
    """Windows only: reads the same GPU counters Task Manager uses."""
    if os.name != "nt":
        GPU["ok"] = False
        return
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    fails = 0
    while True:
        try:
            res = subprocess.run(["powershell", "-NoProfile", "-Command", GPU_PS], capture_output=True,
                                 text=True, timeout=20, creationflags=flags)
            per = {}
            for line in res.stdout.splitlines():
                m = re.match(r"pid_(\d+)_.*engtype_([^|]+)\|([\d.]+)", line.strip())
                if m:
                    pid, eng, val = int(m.group(1)), m.group(2), float(m.group(3))
                    per.setdefault(pid, {}).setdefault(eng, 0.0)
                    per[pid][eng] += val
            if res.stdout.strip():
                GPU["by_pid"] = {pid: max(e.values()) for pid, e in per.items()}  # Task Manager shows the busiest engine
                GPU["ok"], fails = True, 0
            else:
                fails += 1
        except Exception:
            fails += 1
        if fails >= 3 and not GPU["ok"]:
            GPU["ok"] = False
            return
        time.sleep(2)



# =============================================================== routes
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


EMPTY_LIVE = {"configured": False, "running": False, "pids": [], "cpu": 0, "gpu": None, "memory_mb": 0,
              "io_mbps": 0, "activity": {"score": 0, "busiest": None, "refs": {}, "learned": False, "minutes": 0},
              "health": {"state": "off", "uptime_24h": None, "restarts_24h": 0, "memory_leak": False, "notes": []},
              "work": None, "status_page": {"found": False, "error": None}}


def _floor_state(f, snap):
    if f["kind"] != "program":
        return {"id": f["id"], "kind": "existing", "floor": f["floor"], "name": f["name"], "visible": f["visible"]}
    live = snap.get(f["id"], EMPTY_LIVE)
    w = live["work"] or {}
    variables = {"cpu": live["cpu"], "gpu": live["gpu"] or 0, "memory_mb": live["memory_mb"],
                 "running": 1 if live["running"] else 0, "activity": live["activity"]["score"]}
    team = w.get("team") or f["team"]
    variables.update({
        "items_today": w.get("items_today") or 0, "items_last_hour": w.get("items_last_hour") or 0,
        "issues_today": w.get("issues_today") or 0, "platform_engineers": w.get("platform_engineers") or 0,
        "human_engineers": w.get("human_engineers") or 0,
        "automated_minutes": sum(r["manual_minutes_per_item"] for r in team if r["automated"]),
        "human_minutes": sum(r["manual_minutes_per_item"] for r in team if not r["automated"])})
    return {**live, "id": f["id"], "kind": "program", "floor": f["floor"], "name": f["name"],
            "title": f["title"], "url": f["url"], "style": f["style"], "layout": f["layout"],
            "jd": f["jd"], "visible": f["visible"], "team": team, "shield": bool(f.get("shield")),
            "results": [r for r in evaluate_model(f["model"], variables) if r["show"]]}


@app.get("/api/state")
def state():
    s = load_settings()
    with SNAP_LOCK:
        snap = dict(SNAP)
    buildings = [{**{k: v for k, v in b.items() if k != "floors"},
                  "floors": [_floor_state(f, snap) for f in b["floors"]]} for b in s["buildings"]]
    return jsonify(city_name=s["city_name"], buildings=buildings, refresh_seconds=s["refresh_seconds"],
                   gpu_available=GPU["ok"], cores=CPU_COUNT, window_minutes=WORK_WINDOW_MIN)


@app.get("/api/settings")
def get_settings():
    return jsonify(load_settings())


@app.get("/api/templates")
def templates():
    return jsonify(program=program_template(), existing=existing_template(), building=building_template(),
                   model=SUGGESTED_MODEL(), facades=list(FACADES))


def _validate(s):
    s["port"] = int(s["port"])
    s["refresh_seconds"] = max(1, int(s["refresh_seconds"]))
    s["city_name"] = str(s["city_name"]).strip()
    if not s["city_name"]:
        raise ValueError("The city needs a name")
    if not s["buildings"]:
        raise ValueError("The city needs at least one building")
    bids = [b["id"] for b in s["buildings"]]
    if len(set(bids)) != len(bids) or not all(ID_RE.match(i) for i in bids):
        raise ValueError("Every building needs its own id")
    fids = [f["id"] for f in all_floors(s)]
    if len(set(fids)) != len(fids) or not all(ID_RE.match(i) for i in fids):
        raise ValueError("Every floor needs its own id")
    for b in s["buildings"]:
        if not str(b["name"]).strip():
            raise ValueError("Every building needs a name")
        if not b["floors"]:
            raise ValueError(f"{b['name']}: a building needs at least one floor")
        for f in b["floors"]:
            if not str(f["floor"]).strip():
                raise ValueError(f"{b['name']}: every floor needs a floor label")
            if f["kind"] != "program":
                continue
            f["jd"]["steps"] = [x.strip() for x in f["jd"].get("steps", []) if str(x).strip()]
            keys = [str(r["key"]) for r in f["model"]]
            bad = [k for k in keys if not KEY_RE.match(k)]
            if bad:
                raise ValueError(f"{f['floor']}: key '{bad[0]}' must be one word (letters, digits, underscore)")
            if len(set(keys)) != len(keys):
                raise ValueError(f"{f['floor']}: two savings rows use the same key")
            clash = [k for k in keys if k in LIVE_VARS]
            if clash:
                raise ValueError(f"{f['floor']}: '{clash[0]}' is a live value name; pick another key")
    return s


@app.post("/api/settings")
def post_settings():
    data = request.get_json(force=True, silent=True) or {}
    try:
        s = {"port": data.get("port", 5050), "refresh_seconds": data.get("refresh_seconds", 3),
             "city_name": data.get("city_name", ""),
             "buildings": [normalize_building(b) for b in data.get("buildings", [])]}
        s = _validate(s)
        missing = [b["id"] for b in s["buildings"] if None in (b["x"], b["z"], b["w"], b["d"])]
        if missing:
            place_buildings(s["buildings"], only=set(missing))
    except (TypeError, ValueError, KeyError) as e:
        return jsonify(ok=False, error=str(e)), 400
    save_settings(s)
    return jsonify(ok=True)


@app.post("/api/layout/random")
def layout_random():
    """New random spots (and sizes) for some or all buildings. Returns positions; Save keeps them."""
    d = request.get_json(force=True, silent=True) or {}
    blds = [{"id": str(b.get("id")), "x": b.get("x"), "z": b.get("z"), "w": b.get("w"), "d": b.get("d")}
            for b in d.get("buildings", [])]
    only = set(d["only"]) if d.get("only") else {b["id"] for b in blds}
    centre = d.get("centre")
    if centre and any(b["id"] == centre for b in blds):
        others = [b for b in blds if b["id"] != centre and b["x"] is not None]
        c = next(b for b in blds if b["id"] == centre)
        if c["w"] is None:
            c["w"], c["d"] = 130.0, 100.0
        if others:
            mx = sum(b["x"] + b["w"] / 2 for b in others) / len(others)
            mz = sum(b["z"] + b["d"] / 2 for b in others) / len(others)
            c["x"], c["z"] = round(mx - c["w"] / 2), round(mz - c["d"] / 2)
        clash = {b["id"] for b in others if _overlaps(b, c)}
        place_buildings(blds, only=clash, resize=False)   # buildings in the way move aside
    else:
        place_buildings(blds, only=only)
    return jsonify(ok=True, positions={b["id"]: {k: b[k] for k in ("x", "z", "w", "d")} for b in blds})


@app.post("/api/floor/visible")
def floor_visible():
    d = request.get_json(force=True, silent=True) or {}
    s = load_settings()
    for b in s["buildings"]:
        if d.get("building") and b["id"] != d["building"]:
            continue
        for f in b["floors"]:
            if d.get("id") == "*" or f["id"] == d.get("id"):
                f["visible"] = bool(d.get("visible"))
    save_settings(s)
    return jsonify(ok=True)


@app.post("/api/building/visible")
def building_visible():
    d = request.get_json(force=True, silent=True) or {}
    s = load_settings()
    for b in s["buildings"]:
        if d.get("id") == "*" or b["id"] == d.get("id"):
            b["visible"] = bool(d.get("visible"))
    save_settings(s)
    return jsonify(ok=True)


@app.post("/api/status/test")
def status_test():
    d = request.get_json(force=True, silent=True) or {}
    data, err = fetch_status(d.get("url", ""), d.get("path", "/building/status"), timeout=3)
    if data is None:
        return jsonify(ok=False, error=err)
    return jsonify(ok=True, data=data, team=_clean_team(data.get("team")))


@app.post("/api/calibration/reset")
def calibration_reset():
    fid = (request.get_json(force=True, silent=True) or {}).get("id")
    with TRACK_LOCK:
        if fid in TRACK:
            TRACK[fid]["minutes"] = [m for m in TRACK[fid]["minutes"] if False]
    return jsonify(ok=True)


@app.post("/api/model/eval")
def model_eval():
    rows = (request.get_json(force=True, silent=True) or {}).get("model", [])
    return jsonify(results=evaluate_model(rows, {k: 0 for k in LIVE_VARS}))


@app.post("/api/model/upload")
def model_upload():
    f = request.files.get("file")
    if not f:
        return jsonify(ok=False, error="No file received"), 400
    try:
        return jsonify(ok=True, model=parse_model_file(f.filename, f.read()))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


def start_background():
    load_tracking()
    threading.Thread(target=gpu_loop, daemon=True).start()
    threading.Thread(target=monitor_loop, daemon=True).start()
    threading.Thread(target=save_tracking_loop, daemon=True).start()


if __name__ == "__main__":
    start_background()
    app.run(host="127.0.0.1", port=load_settings()["port"], debug=False)
