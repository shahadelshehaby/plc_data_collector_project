"""
crane_collector.py
==================
One crane: UDP listener -> InfluxDB v2.  Normally started by launch_cranes.py,
but it can be run by hand for testing:

    python crane_collector.py A201 12201 2.1

Replaces typingtensions_updatedv2.py (version "2") and
typingtensions_updatedv2.1.py (version "2.1"). Field names, slots and types
are identical to those scripts, so the data in InfluxDB looks the same.
"""
import json
import logging
import os
import socket
import struct
import sys
import time
from collections import deque
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler

from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS

import collector_settings as S

# ═════════════════════════════════════════════════════════════════════════════
#  PACKET LAYOUT  (slot = 4-byte word index, as in the PLC ConvertValArr)
# ═════════════════════════════════════════════════════════════════════════════

# REAL values  ('>f')
REALS_COMMON = [
    (0, "In_TRIM"), (1, "In_LIST"), (2, "In_SKEW"), (3, "In_RT"), (4, "In_RG"),
    (5, "In_CYLINDER1"), (6, "In_CYLINDER2"),
    (7, "In_GANTRY1"), (8, "GANTRYSPEED1"),
    (9, "In_TROLLEYPOMUX"), (10, "In_TROLLEYENC"), (11, "TROLLEYSPEED1"),
    (12, "In_HOIST"), (13, "HOISTSPEED1"),
    (14, "Gantry_obs_start"), (15, "Gantry_obs_end"),
    # 16-20 : PLCTime string (see below)
    (21, "In_RIGHTLC"), (22, "In_LEFTLC"), (23, "In_NEARSLC"), (24, "In_FARSLC"),
    (25, "In_GANTRYCurrent1"), (26, "In_GANTRYCurrent2"),
    (27, "In_HOISTCurrent1"), (28, "In_HOISTCurrent2"),
    (29, "In_TROLLEYCurrent1"), (30, "In_TROLLEYCurrent2"),
    (31, "ControlState"), (32, "HoistSpdLim"), (33, "TrolleySpdLim"),
    (34, "ConnectedDeskNo"),
    (35, "In_GANTRYVoltage1"), (36, "In_GANTRYVoltage2"),
    (37, "In_TROLLEYVoltage1"), (38, "In_HOISTVoltage1"),
    (39, "In_HOISTVoltage2"), (40, "In_TROLLEYVoltage2"),
    (41, "FwdCraneGantry"), (42, "BwdCraneGantry"),
    # 51-53 : ContainerID string (see below)
    (54, "GANTRYSPEED2"), (55, "HOISTSPEED2"), (56, "TROLLEYSPEED2"),
    (57, "GantryTorque1"), (58, "GantryTorque2"),
    (59, "HoistTorque1"), (60, "HoistTorque2"),
    (61, "TrolleyTorque1"), (62, "TrolleyTorque2"),
    (63, "PCR_SpdRef"), (64, "PCR_SpdActual"),
    (65, "PCR_TorqueRef"), (66, "PCR_TorqueAct"), (67, "PCR_Current"),
    (68, "In_GANTRY2"), (69, "GantrySpdRef"), (70, "GantrySpdLim"), (71, "GantrySpdReq"),
    (78, "GantryRef"), (79, "TrolleyRef"), (80, "HoistRef"),
]

# DINT values  ('>I')
DINTS_COMMON = [
    (72, "WorkorderIdent"), (73, "MoveType"), (74, "LandingType"),
    (75, "JobClearance"), (76, "TargetType"), (77, "ControlReject"),
    (81, "Step"), (82, "StepInfo"), (83, "RemoteRequestInfo"),
]

# Slot 84 : StatusWord, bit 0 .. 31
STATUSWORD_BITS = [
    "ControlON", "Spreader20ft", "Spreader40ft", "Spreader45ft",
    "SingleMode", "TwinMode", "LandedAllPins", "TwistlockLocked",
    "TwistlockUnlocked", "InnerLaneInPosition", "OuterLaneInPosition", "GantrySynchOk",
    "Gantry_obs_active", "AbortRequest",
    # Anti-collision (PLC already inverts: 1 = active). Nearside = Landside, Farside = Waterside
    "AntiCLandSrightPreStop", "AntiCLandSrightStop", "AntiCLandSrightWarning",
    "AntiCWaterSrightPreStop", "AntiCWaterSrightStop", "AntiCWaterSrightWarning",
    "AntiCLandSLeftPreStop", "AntiCLandSLeftStop", "AntiCLandSLeftWarning",
    "AntiCWaterSLeftPreStop", "AntiCWaterSLeftStop", "AntiCWaterSLeftWarning",
    # Long-range anti-collision stop
    "LongDLandSRight", "LongDLandSLeft", "LongDWaterSLeft", "LongDWaterSRight",
    # Gantry anti-collision latch
    "AntiCGantryFwdLatch", "AntiCGantryBwdLatch",
]

# Slot 85 : StatusWord2, bit 0 ..
STATUSWORD2_BITS_V2 = ["AutoActive", "ManualIntervention", "ForwardRequest", "BackwardRequest"]
STATUSWORD2_BITS_V21 = STATUSWORD2_BITS_V2 + [
    f"Brake{i}Released" for i in range(1, 13)               # bits 4 .. 15
] + ["RailBrake1LeftReleased", "RailBrake2LeftReleased"]    # bits 16, 17

REALS_V21_EXTRA = [
    (86, "FwdCraneState"), (87, "BwdCraneState"),
    (88, "FwdCraneDistance"), (89, "BwdCraneDistance"),
    (90, "SpreaderSkew"),
]

LAYOUTS = {
    "2":   {"reals": REALS_COMMON,                   "sw2_bits": STATUSWORD2_BITS_V2,  "min_size": 86 * 4},
    "2.1": {"reals": REALS_COMMON + REALS_V21_EXTRA, "sw2_bits": STATUSWORD2_BITS_V21, "min_size": 91 * 4},
}


def _real(data, slot):
    return struct.unpack(">f", data[slot * 4:slot * 4 + 4])[0]


def _dint(data, slot):
    return int(struct.unpack(">I", data[slot * 4:slot * 4 + 4])[0])


def parse_packet(data: bytes, version: str) -> dict:
    """Return {field_name: value} exactly as the old scripts wrote them."""
    layout = LAYOUTS[version]
    f = {}
    f["PLCTime"] = data[16 * 4:83].decode(errors="replace").strip()
    for slot, name in layout["reals"]:
        f[name] = _real(data, slot)
    for slot, name in DINTS_COMMON:
        f[name] = _dint(data, slot)
    f["ContainerID"] = data[51 * 4:54 * 4 - 1].decode(errors="replace").rstrip()

    sw = struct.unpack(">I", data[84 * 4:85 * 4])[0]
    f["StatusWord"] = sw
    for bit, name in enumerate(STATUSWORD_BITS):
        f[name] = int(bool(sw & (1 << bit)))

    sw2 = struct.unpack(">I", data[85 * 4:86 * 4])[0]
    f["StatusWord2"] = sw2
    for bit, name in enumerate(layout["sw2_bits"]):
        f[name] = int(bool(sw2 & (1 << bit)))
    return f


def build_point(crane_id: str, fields: dict) -> Point:
    p = (
        Point("crane_telemetry")
        .tag("crane_id", crane_id)
        .time(datetime.now(timezone.utc), "ms")
    )
    for name, val in fields.items():
        p = p.field(name, val)
    return p


def read_token() -> str:
    token = os.environ.get("INFLUX_TOKEN", "").strip()
    if not token and S.INFLUX_TOKEN_FILE.exists():
        token = S.INFLUX_TOKEN_FILE.read_text(encoding="utf-8").strip()
    if not token:
        raise SystemExit(f"No InfluxDB token: create {S.INFLUX_TOKEN_FILE} "
                         f"or set the INFLUX_TOKEN environment variable.")
    return token


# ═════════════════════════════════════════════════════════════════════════════
#  STATUS FILE  (read by crane_status.py / the launcher screen)
# ═════════════════════════════════════════════════════════════════════════════
class Status:
    def __init__(self, crane_id, port, version):
        self.path = S.STATUS_DIR / f"{crane_id}.json"
        self.d = {
            "crane": crane_id, "port": port, "version": version,
            "expected_size": S.PACKET_SIZE.get(version),
            "pid": os.getpid(), "started": time.time(), "updated": time.time(),
            "packets_received": 0, "packets_written": 0,
            "wrong_size_count": 0, "write_errors": 0,
            "last_packet_time": None, "last_write_time": None,
            "last_size": None, "last_source": None, "sources_60s": [],
            "last_error": None, "last_error_time": None,
            "last_write_ok": None, "packets_last_60s": 0,
            "last_values": {},
        }
        self._recent = deque()          # (time, source_ip)

    def packet(self, size, source_ip):
        now = time.time()
        self.d["packets_received"] += 1
        self.d["last_packet_time"] = now
        self.d["last_size"] = size
        self.d["last_source"] = source_ip
        self._recent.append((now, source_ip))

    def error(self, msg):
        self.d["last_error"] = msg
        self.d["last_error_time"] = time.time()

    def save(self):
        now = time.time()
        while self._recent and self._recent[0][0] < now - 60:
            self._recent.popleft()
        self.d["packets_last_60s"] = len(self._recent)
        self.d["sources_60s"] = sorted({ip for _, ip in self._recent})
        self.d["updated"] = now
        tmp = self.path.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(self.d), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError:
            pass                        # viewer had the file open; next save will work


# ═════════════════════════════════════════════════════════════════════════════
def setup_logging(crane_id):
    S.LOG_DIR.mkdir(exist_ok=True)
    log = logging.getLogger("crane")
    log.setLevel(logging.DEBUG if S.LOG_EVERY_PACKET else logging.INFO)
    fmt = logging.Formatter(f"%(asctime)s  [{crane_id}]  %(levelname)s  %(message)s",
                            "%Y-%m-%d %H:%M:%S")
    fh = RotatingFileHandler(S.LOG_DIR / f"{crane_id}.log", maxBytes=S.LOG_MAX_BYTES,
                             backupCount=S.LOG_BACKUP_COUNT, encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    if sys.stdout.isatty():             # run by hand -> also show in the window
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        log.addHandler(sh)
    return log


class Throttle:
    """Log the same kind of problem at most once per `every` seconds."""
    def __init__(self, every=60):
        self.every, self.last, self.count = every, {}, {}

    def __call__(self, key):
        now = time.time()
        self.count[key] = self.count.get(key, 0) + 1
        if now - self.last.get(key, 0) >= self.every:
            self.last[key] = now
            n, self.count[key] = self.count[key], 0
            return n
        return 0


def main():
    if len(sys.argv) != 4:
        print("Usage:  python crane_collector.py <CRANE_ID> <UDP_PORT> <VERSION>")
        print(f"        VERSION is one of: {', '.join(LAYOUTS)}")
        sys.exit(2)
    crane_id, port, version = sys.argv[1].upper(), int(sys.argv[2]), sys.argv[3]
    if version not in LAYOUTS:
        sys.exit(f"Unknown collector version '{version}'. Known: {', '.join(LAYOUTS)}")

    S.STATUS_DIR.mkdir(exist_ok=True)
    log = setup_logging(crane_id)
    sys.excepthook = lambda *e: log.critical("Crashed", exc_info=e)
    expected = S.PACKET_SIZE[version]
    min_size = LAYOUTS[version]["min_size"]
    status = Status(crane_id, port, version)
    throttle = Throttle(60)

    log.info("Starting: crane=%s port=%d version=%s expected size=%d bytes  pid=%d",
             crane_id, port, version, expected, os.getpid())

    client = InfluxDBClient(url=S.INFLUX_URL, token=read_token(), org=S.INFLUX_ORG,
                            timeout=S.INFLUX_TIMEOUT_MS)
    write_api = client.write_api(write_options=SYNCHRONOUS)
    try:
        health = client.health()
        if health.status == "pass":
            log.info("InfluxDB %s reachable", S.INFLUX_URL)
        else:
            log.warning("InfluxDB health check failed: %s (will keep trying)", health.message)
    except Exception as exc:
        log.warning("InfluxDB health check failed: %s (will keep trying)", exc)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind((S.LISTEN_ADDRESS, port))
    except OSError as exc:
        status.error(f"Cannot open UDP port {port}: {exc}")
        status.save()
        log.error("Cannot open UDP port %d: %s", port, exc)
        sys.exit(3)
    sock.settimeout(1.0)
    log.info("Listening on UDP port %d", port)
    status.save()

    next_save = next_summary = time.time()
    win_rx = win_wr = 0
    try:
        while True:
            now = time.time()
            if now >= next_save:
                status.save()
                next_save = now + 2
            if now >= next_summary + S.SUMMARY_EVERY_SEC:
                d = status.d
                log.info("Last %ds: received %d, written %d | last size %s from %s | total written %d",
                         S.SUMMARY_EVERY_SEC, win_rx, win_wr, d["last_size"],
                         ", ".join(d["sources_60s"]) or "-", d["packets_written"])
                if win_rx == 0:
                    log.warning("No packets received in the last %ds", S.SUMMARY_EVERY_SEC)
                win_rx = win_wr = 0
                next_summary = now

            try:
                data, (src_ip, src_port) = sock.recvfrom(S.BUFFER_SIZE)
            except socket.timeout:
                continue
            except ConnectionResetError:     # Windows ICMP quirk on UDP sockets
                continue

            size = len(data)
            status.packet(size, src_ip)
            win_rx += 1
            log.debug("UDP packet from %s:%d (%d bytes)", src_ip, src_port, size)

            recent_sources = {ip for t, ip in status._recent if t > now - 60}
            if len(recent_sources) > 1 and throttle("multi"):
                log.warning("Packets from MORE THAN ONE source on port %d: %s - "
                            "two PLCs may be configured with the same port!",
                            port, ", ".join(sorted(recent_sources)))

            if size != expected:
                status.d["wrong_size_count"] += 1
                msg = (f"Packet size {size} bytes, expected {expected} for version {version} "
                       f"- check the Collector Version in the Excel")
                status.error(msg)
                n = throttle("size")
                if n:
                    log.warning("%s (%d times)", msg, n)
                if size < min_size:
                    continue                 # too short to parse

            try:
                fields = parse_packet(data, version)
            except Exception as exc:
                status.error(f"Parse error: {exc}")
                if throttle("parse"):
                    log.warning("Parse error: %s - skipping", exc)
                continue

            try:
                write_api.write(bucket=S.INFLUX_BUCKET, org=S.INFLUX_ORG,
                                record=build_point(crane_id, fields))
                status.d["packets_written"] += 1
                status.d["last_write_time"] = time.time()
                status.d["last_write_ok"] = True
                status.d["last_values"] = {k: fields[k] for k in
                                           ("WorkorderIdent", "Step", "In_GANTRY2",
                                            "TrolleyRef", "HoistRef", "StatusWord")}
                win_wr += 1
                log.debug("written #%d | WO %d | Step %d | In_GANTRY2 %.2f",
                          status.d["packets_written"], fields["WorkorderIdent"],
                          fields["Step"], fields["In_GANTRY2"])
            except Exception as exc:
                status.d["write_errors"] += 1
                status.d["last_write_ok"] = False
                status.error(f"InfluxDB write failed: {exc}")
                n = throttle("write")
                if n:
                    log.error("InfluxDB write failed (%d times): %s", n, exc)

    except KeyboardInterrupt:
        log.info("Stopped. Received %d | Written %d",
                 status.d["packets_received"], status.d["packets_written"])
    finally:
        status.save()
        sock.close()
        client.close()


if __name__ == "__main__":
    main()
