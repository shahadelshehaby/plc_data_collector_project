"""
utils.py
========
Shared helpers used by the orchestrator and report builders.
"""
import math
import os
import re
from datetime import timedelta

MACHINE_NAME_RE = re.compile(r"^[A-Za-z]+\d+")


def derive_machine_name(filename: str) -> str:
    """
    'A205_2026-07-01.csv' -> 'A205'. Falls back to the filename stem if the
    leading letters+digits pattern isn't found.
    """
    stem = os.path.splitext(os.path.basename(filename))[0]
    m = MACHINE_NAME_RE.match(stem)
    if m:
        return m.group(0)
    # Not at the start (e.g. "raw_B203_2026-10-12" or "export B203"): use the
    # first part of the name that looks like a crane code.
    for part in re.split(r"[\s_\-.()]+", stem):
        if re.fullmatch(r"[A-Za-z]{1,4}\d{2,}", part):
            return part.upper()
    return stem


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def format_hms(total_seconds: float) -> str:
    if total_seconds is None:
        return "-"
    td = timedelta(seconds=round(total_seconds))
    total = int(td.total_seconds())
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def format_energy_kwh(power_result, decimals: int = 3) -> str:
    """Formats a PowerResult's total_energy_kwh for display, WITHOUT ever
    printing a literal 'nan'. If the underlying phase had no usable
    current/voltage readings at all (every relevant column empty for that
    phase), this shows 'no consumption data' instead of a numeric 0.000 or
    'nan' - a real 0.000 means "we measured it and it truly was zero",
    which is a different fact from "we have no reading to measure at all"."""
    if power_result is None:
        return "no consumption data"
    value = power_result.total_energy_kwh
    if not power_result.has_any_data or value is None or (isinstance(value, float) and math.isnan(value)):
        return "no consumption data"
    return f"{value:.{decimals}f}"


def format_cost(energy_kwh_value, config, decimals: int = 2) -> str:
    """Formats energy_kwh_value * config.power.cost_per_kwh as a currency
    string, e.g. '$1.23'. Returns '-' if no cost_per_kwh is configured, and
    'no consumption data' if energy_kwh_value itself is None/NaN (no usable
    reading to price). NOTE: energy_kwh_value must already be a kWh figure
    (i.e. power already integrated over the move's elapsed time) - do NOT
    pass a duration in separately, the multiplication is cost = kWh * rate
    only, nothing else."""
    rate = getattr(config.power, "cost_per_kwh", None) if config is not None else None
    if rate is None:
        return "-"
    if energy_kwh_value is None or (isinstance(energy_kwh_value, float) and math.isnan(energy_kwh_value)):
        return "no consumption data"
    currency = getattr(config.power, "currency", "USD") if config is not None else "USD"
    symbol = {"USD": "$", "EUR": "\u20ac", "GBP": "\u00a3"}.get(currency, currency + " ")
    return f"{symbol}{energy_kwh_value * rate:.{decimals}f}"


# ---------------------------------------------------------------- display
# When a report covers more than one day, time-only columns ("23:40:30")
# become ambiguous, so the pipeline switches this on to show "01.07 23:40:30".
_SHOW_DATE_IN_TIMES = False


def set_show_date_in_times(flag: bool):
    global _SHOW_DATE_IN_TIMES
    _SHOW_DATE_IN_TIMES = bool(flag)


def display_time(ts_str: str) -> str:
    """'2026-07-01 23:40:30' -> '23:40:30' (single day) or '01.07 23:40:30' (period)."""
    ts_str = str(ts_str)
    parts = ts_str.split(" ")
    time_part = parts[-1]
    if _SHOW_DATE_IN_TIMES and len(parts) > 1:
        y, m, d = (parts[0].split("-") + ["", "", ""])[:3]
        return f"{d}.{m} {time_part}"
    return time_part


def display_date(iso_date: str) -> str:
    """'2026-07-01' -> '01.07.2026'."""
    try:
        y, m, d = iso_date.split("-")
        return f"{d}.{m}.{y}"
    except ValueError:
        return iso_date


def lane_of(machine: str) -> str:
    """Block lane from the machine name, using the active profile's lane rule
    (Settings > Lanes): by default the leading letters, 'B203' -> 'B'."""
    from rules import lane_of as _lane_of
    return _lane_of(machine)


def energy_basis_note(config) -> str:
    """One line for report headers: how energy was calculated."""
    energy = getattr(config, "energy", None) if config is not None else None
    if energy is None or energy.method != "torque_speed":
        return "Energy: estimated from drive voltage x current x power factor (energy used)."
    basis = ("net of energy fed back by braking (used minus fed back)" if energy.basis == "net"
             else "energy used only (energy fed back by braking not deducted)")
    refs = [f"{a} {x.p_ref:.0f} kW" for a, x in energy.axes.items() if x.p_ref and x.torque_cols]
    missing = [a for a, x in energy.axes.items() if not x.p_ref and x.torque_cols]
    text = (f"Energy: torque x speed per drive, {basis}. Efficiency {energy.efficiency:.3f}. "
            f"P_ref per drive: {', '.join(refs) or 'none'}.")
    if missing:
        text += f" Not included (P_ref not set): {', '.join(missing)}."
    return text


def energy_split_text(pw) -> str:
    """'used 1.23, fed back 0.30, net 0.93 kWh' for the torque x speed method."""
    if pw is None or getattr(pw, "method", "") != "torque_speed" or not pw.has_any_data:
        return ""
    return (f"used {pw.consumed_kwh:.3f} kWh, fed back {pw.regenerated_kwh:.3f} kWh, "
            f"net {pw.net_kwh:.3f} kWh")
