@echo off
title FDD Platform - Evaluation
cd /d "%~dp0"
echo ==============================================
echo   FDD Platform - Evaluation  (port 5120)
echo ==============================================
echo Checking Python packages (first run only, may take a minute)...
python -m pip install -r requirements.txt -q
echo.
echo Starting Evaluation - your browser will open automatically.
echo The NAS sync runs while this window is open.
python app.py
pause
