@echo off
REM For testing: runs all cranes in this window (closing the window stops them).
REM Do not use while the service is installed and running.
cd /d "%~dp0"
sc query CraneCollectorT2 2>nul | find "RUNNING" >nul
if not errorlevel 1 (
    echo The CraneCollectorT2 service is running. Use view_status.bat instead,
    echo or stop the service first with uninstall_service.bat.
    pause & exit /b 1
)
title Terminal 2 - crane launcher
python launch_cranes.py
pause
