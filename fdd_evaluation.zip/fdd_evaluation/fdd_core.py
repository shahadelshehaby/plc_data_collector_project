"""
Core logic for the FDD Rule Builder & Backtester (Python version).

Reads a master fault list, a 1-second PLC data file, and a fault event
history file; lets you define time-versioned boolean rules per fault
(replicating what you believe the PLC/interlock logic does); evaluates
those rules against the real PLC data; and backtests the result against
the actual recorded fault events to measure precision/recall.

This is a decision-support / validation tool only. It does not read from
or write to any PLC, and it does not touch control or safety logic.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional


# --------------------------------------------------------------------------
# File reading
# --------------------------------------------------------------------------

CSV_ENCODINGS = ["utf-8-sig", "utf-8", "utf-16", "utf-16-le", "utf-16-be", "cp1252", "latin1"]


def read_table(path: str | Path) -> pd.DataFrame:
    """Read a .csv, .xlsx, or .xls file into a DataFrame.

    For CSV, tries a sequence of encodings and sniffs the delimiter, since
    historian/SCADA exports are frequently UTF-16 or semicolon-delimited
    rather than plain UTF-8 comma-separated.
    """
    path = Path(path)
    ext = path.suffix.lower()

    if ext in (".xlsx", ".xls"):
        return pd.read_excel(path)

    if ext == ".csv":
        last_err = None
        for enc in CSV_ENCODINGS:
            try:
                df = pd.read_csv(path, encoding=enc, sep=None, engine="python")
                if df.shape[1] > 1:
                    return df
                last_err = ValueError(f"Parsed with encoding={enc} but got only 1 column — likely wrong delimiter/encoding.")
            except Exception as e:  # noqa: BLE001
                last_err = e
                continue
        raise ValueError(f"Could not parse {path} with any of {CSV_ENCODINGS}. Last error: {last_err}")

    raise ValueError(f"Unsupported file type: {ext} (expected .csv, .xlsx, or .xls)")


def merge_plc_store(store_path, new_df: pd.DataFrame, ts_col: str, machine_col: str | None) -> dict:
    """Merge new_df into a persistent, growing PLC dataset on disk, keeping
    only rows whose (machine, timestamp) — or just timestamp, if no machine
    column is set — doesn't already exist in the store. Existing stored rows
    are never overwritten; a duplicate in new_df is simply skipped, not used
    to replace what's already there. Returns the full merged DataFrame plus
    counts of how many rows were newly added vs skipped as duplicates.
    """
    key_cols = [c for c in ([machine_col, ts_col] if machine_col else [ts_col]) if c]

    def make_key(df):
        return df[key_cols].astype(str).agg("|".join, axis=1)

    if store_path.exists():
        store_df = pd.read_csv(store_path)
        store_df[ts_col] = pd.to_datetime(store_df[ts_col])
    else:
        store_df = new_df.iloc[0:0].copy()

    existing_keys = set(make_key(store_df)) if len(store_df) else set()
    new_keys = make_key(new_df)
    is_new = ~new_keys.isin(existing_keys)
    to_add = new_df.loc[is_new]

    merged = pd.concat([store_df, to_add], ignore_index=True)
    merged = merged.sort_values(ts_col).reset_index(drop=True)
    tmp = store_path.with_name(store_path.name + ".tmp")
    merged.to_csv(tmp, index=False)
    tmp.replace(store_path)

    return {"merged": merged, "added": int(is_new.sum()), "skipped_duplicates": int((~is_new).sum()), "total": len(merged)}


def inspect(path: str | Path, n: int = 5) -> None:
    """Print columns, dtypes, and a few sample rows — use this to figure out
    exact column names before writing a config file."""
    df = read_table(path)
    print(f"\n{path}")
    print(f"  rows: {len(df):,}   columns: {len(df.columns)}")
    print("  columns:")
    for c in df.columns:
        print(f"    - {c!r}  (dtype={df[c].dtype})")
    print(f"  first {n} rows:")
    with pd.option_context("display.max_columns", None, "display.width", 160):
        print(df.head(n))


# --------------------------------------------------------------------------
# Datetime parsing
# --------------------------------------------------------------------------

def to_datetime_series(s: pd.Series) -> pd.Series:
    """Parse a column to datetimes, trying common formats before giving up."""
    parsed = pd.to_datetime(s, errors="coerce")
    if parsed.notna().mean() > 0.9:
        return parsed
    # try day-first (common outside the US)
    parsed_dayfirst = pd.to_datetime(s, errors="coerce", dayfirst=True)
    if parsed_dayfirst.notna().sum() > parsed.notna().sum():
        return parsed_dayfirst
    return parsed


# --------------------------------------------------------------------------
# Rule evaluation
# --------------------------------------------------------------------------

_OPS = {
    ">=": lambda a, b: a >= b,
    ">":  lambda a, b: a > b,
    "<=": lambda a, b: a <= b,
    "<":  lambda a, b: a < b,
    "==": lambda a, b: a == b,
    "!=": lambda a, b: a != b,
}


def apply_timer(times: pd.Series, raw_mask: pd.Series, timer_seconds: float) -> pd.Series:
    """Transform a raw boolean condition into a debounced one: True only once
    the raw condition has held continuously for at least timer_seconds. This
    mirrors a PLC on-delay (TON) timer on a single contact — the timer
    resets the instant the raw condition goes false, no bridging of gaps.
    """
    if not timer_seconds or timer_seconds <= 0 or not len(raw_mask):
        return raw_mask
    changed = raw_mask.ne(raw_mask.shift(1, fill_value=not bool(raw_mask.iloc[0])))
    seg_id = changed.cumsum()
    seg_start_time = times.groupby(seg_id).transform("min")
    elapsed = (times - seg_start_time).dt.total_seconds()
    return raw_mask & (elapsed >= timer_seconds)


BYPASS_OPS = ("in", "not_in")


def bypass_inside(plc: pd.DataFrame, ts_col: str, column: str, bypass: dict, widen: float = 0.0) -> pd.Series:
    """True on every row where `column` lies inside one of the bypass's ranges, using the bypass version in force
    at that row's time (a version applies from its effective_from, or the start of the data if blank, up to the
    next version's date).

    bypass: {"name": str, "versions": [{"effective_from": str|None, "ranges": [{"from": x, "to": y}, ...]}]}
    Both range ends are included and may be typed either way round. widen (>= 0) grows every range by that
    amount at both ends. A blank / non-numeric value is never inside a range, so a missing reading can not
    hide a fault.
    """
    times = plc[ts_col]
    values = pd.to_numeric(plc[column], errors="coerce")
    inside = pd.Series(False, index=plc.index)
    widen = abs(float(widen or 0))
    vs = [(pd.to_datetime(v["effective_from"]) if v.get("effective_from") else None, v)
          for v in (bypass.get("versions") or [])]
    vs.sort(key=lambda t: (t[0] is not None, t[0] if t[0] is not None else pd.Timestamp.min))
    for i, (start, v) in enumerate(vs):
        end = vs[i + 1][0] if i + 1 < len(vs) else None
        window = (times >= (start if start is not None else pd.Timestamp.min)) & \
                 (times < (end if end is not None else pd.Timestamp.max))
        if not window.any():
            continue
        for r in v.get("ranges") or []:
            try:
                lo, hi = float(r.get("from")), float(r.get("to"))
            except (TypeError, ValueError):
                continue
            if lo > hi:
                lo, hi = hi, lo
            inside |= window & values.between(lo - widen, hi + widen)
    return inside



def leaf_conditions(conditions):
    """Every plain condition in a condition list, including those inside sub-logic groups (any depth)."""
    for c in conditions or []:
        if c.get("type") == "group":
            yield from leaf_conditions(c.get("conditions"))
        else:
            yield c


def evaluate_conditions(plc: pd.DataFrame, ts_col: str, conditions: list, bypasses: dict | None = None):
    """Boolean Series for one list of conditions, combined strictly top to bottom with each item's joiner
    (((c1 j2 c2) j3 c3) ...). An item {"type": "group", "joiner", "mode", "mode_value", "conditions": [...]} is a
    sub-logic: its own list is evaluated first (recursively, like brackets) and the result is used as ONE item.
    A group's "timer" mode means the whole sub-logic must stay true for that many seconds. Empty groups are
    ignored. Returns None for an empty list."""
    times = plc[ts_col]
    cond_mask = None
    for c in conditions or []:
        mode = c.get("mode", "none")
        mode_value = c.get("mode_value", 0) or 0

        if c.get("type") == "group":
            this_mask = evaluate_conditions(plc, ts_col, c.get("conditions"), bypasses)
            if this_mask is None:
                continue
            if mode == "timer" and mode_value:
                this_mask = apply_timer(times, this_mask, mode_value)
        else:
            col, op = c["column"], c["op"]
            if col not in plc.columns:
                raise ValueError(f"Condition references unknown PLC column: {col!r}")

            if op in BYPASS_OPS:
                bp = (bypasses or {}).get(c.get("bypass"))
                if not bp:
                    raise ValueError(f"The {'IN' if op == 'in' else 'NOT IN'} condition on {col!r} uses a bypass that "
                                     f"does not exist in this terminal / type. Pick one in the Logic tab.")
                inside = bypass_inside(plc, ts_col, col, bp, mode_value if mode == "tolerance" else 0)
                this_mask = inside if op == "in" else ~inside
                if mode == "timer" and mode_value:
                    this_mask = apply_timer(times, this_mask, mode_value)
            elif op not in _OPS:
                raise ValueError(f"Unknown operator: {op!r}")
            elif mode == "tolerance" and mode_value:
                val = c["value"]
                series = plc[col]
                if op == ">=":
                    this_mask = series >= (val - mode_value)
                elif op == ">":
                    this_mask = series > (val - mode_value)
                elif op == "<=":
                    this_mask = series <= (val + mode_value)
                elif op == "<":
                    this_mask = series < (val + mode_value)
                elif op == "==":
                    this_mask = (series - val).abs() <= mode_value
                else:  # !=
                    this_mask = (series - val).abs() > mode_value
            else:
                this_mask = _OPS[op](plc[col], c["value"])
                if mode == "timer" and mode_value:
                    this_mask = apply_timer(times, this_mask, mode_value)

        if cond_mask is None:
            cond_mask = this_mask
        else:
            joiner = c.get("joiner", "AND")
            cond_mask = (cond_mask | this_mask) if joiner == "OR" else (cond_mask & this_mask)
    return cond_mask


def evaluate_versions(plc: pd.DataFrame, ts_col: str, versions: list[dict], bypasses: dict | None = None) -> pd.Series:
    """Return a boolean Series over plc's rows: True where the applicable
    rule version's conditions hold (AND/OR combined per each condition's
    'joiner', evaluated top to bottom).

    versions: list of {"effective_from": Timestamp|None, "conditions": [
        {"column": str, "op": str, "value": float, "joiner": "AND"|"OR",
         "timer_seconds": float}, ...]}
    "timer_seconds" (optional, default 0) requires that individual
    condition's raw comparison to hold continuously for that many seconds
    before it counts as true — e.g. "Pressure >= 10, timer 1" means
    Pressure must stay >= 10 for more than 1 second.
    Alternatively "mode": "tolerance" with "mode_value": X loosens the
    threshold itself by X (e.g. ">= 10" with tolerance 0.3 behaves like
    ">= 9.7") — useful for sensor noise rather than timing.
    op "in" / "not_in" with "bypass": <id> tests the column against the
    ranges of that bypass (see bypass_inside); `bypasses` is the program's
    {id: bypass} dict. Timer works as usual; tolerance widens the ranges.
    An item {"type": "group", ...} is a sub-logic (brackets) — see evaluate_conditions.
    Sorted internally by effective_from; a version applies from its
    effective_from (or the start of the data, if None) up to the next
    version's effective_from.
    """
    times = plc[ts_col]
    mask = pd.Series(False, index=plc.index)

    sortable = sorted(
        versions,
        key=lambda v: (v["effective_from"] is not None, v["effective_from"] or pd.Timestamp.min),
    )

    for i, v in enumerate(sortable):
        start = v["effective_from"] if v["effective_from"] is not None else pd.Timestamp.min
        end = sortable[i + 1]["effective_from"] if i + 1 < len(sortable) else pd.Timestamp.max
        if end is None:
            end = pd.Timestamp.max
        window = (times >= start) & (times < end)
        if not window.any():
            continue
        cond_mask = evaluate_conditions(plc, ts_col, v["conditions"], bypasses)
        if cond_mask is None:
            continue
        mask |= window & cond_mask

    return mask


def mask_to_intervals(times: pd.Series, mask: pd.Series, max_gap_seconds: float) -> pd.DataFrame:
    """Group a boolean mask into contiguous [start, end] intervals, merging
    across gaps up to max_gap_seconds (since PLC data only logs while the
    machine is running, so small gaps shouldn't split one real event)."""
    true_times = times[mask].reset_index(drop=True)
    if true_times.empty:
        return pd.DataFrame(columns=["start", "end"])
    diffs = true_times.diff().dt.total_seconds()
    group_id = (diffs > max_gap_seconds).cumsum()
    grouped = true_times.groupby(group_id).agg(["min", "max"])
    grouped.columns = ["start", "end"]
    return grouped.reset_index(drop=True)


def filter_min_duration(intervals: pd.DataFrame, min_duration_seconds: float) -> pd.DataFrame:
    """Drop predicted intervals shorter than min_duration_seconds — useful
    when the real PLC logic has a debounce/persistence timer before a fault
    latches, so brief threshold crossings shouldn't count as triggers."""
    if not min_duration_seconds or min_duration_seconds <= 0 or intervals.empty:
        return intervals
    dur = (intervals["end"] - intervals["start"]).dt.total_seconds()
    return intervals.loc[dur >= min_duration_seconds].reset_index(drop=True)


# --------------------------------------------------------------------------
# Matching predicted intervals to real events
# --------------------------------------------------------------------------

def match_events(intervals: pd.DataFrame, ground_truth: pd.DataFrame, tolerance_seconds: float, plc_times=None) -> dict:
    """Match predicted intervals to real events by OVERLAP, not just onset
    time. A real event spans [coming, going] (e.g. a fault that lasted 5
    seconds); a predicted interval matches if it overlaps that window
    (expanded by +/- tolerance_seconds on both ends). This is deliberately
    more forgiving than exact onset-time matching, since real PLC logic
    often has a debounce/persistence delay before a fault latches — the
    historian's recorded onset time and your rule's raw threshold-crossing
    time won't line up to the second even when they're the same event.

    ground_truth: DataFrame with 'coming' and, ideally, 'going' columns
    (going may be missing/NaT per row, in which case that event's window
    collapses to just [coming, coming]).

    Every interval that overlaps a real event's window counts as belonging
    to that event (not just the single closest one) — if your rule's
    condition briefly drops out and splits one real occurrence into two
    predicted intervals, both are credited to that event rather than one
    being wrongly counted as a false positive. The single nearest interval
    to each event's onset is still reported as "the" match for the delta
    shown to you, but every overlapping interval is excluded from the
    false-positive list.

    plc_times (optional): sorted array of every PLC timestamp available.
    An unmatched real event is only counted as "missed" (a genuine rule
    failure) if the PLC actually had SOME data during that event's window.
    If there's no PLC coverage at all for that window, it's reclassified
    as "no_data" instead — the rule logic can't be faulted for a period
    where there was nothing to evaluate — and excluded from the recall
    calculation entirely, rather than silently making recall look worse
    than the logic actually deserves.
    """
    intervals = intervals.sort_values("start").reset_index(drop=True)
    gt = ground_truth.sort_values("coming").reset_index(drop=True)
    tol = pd.Timedelta(seconds=tolerance_seconds)

    starts = intervals["start"].to_numpy() if len(intervals) else np.array([], dtype="datetime64[ns]")
    ends = intervals["end"].to_numpy() if len(intervals) else np.array([], dtype="datetime64[ns]")
    used = np.zeros(len(intervals), dtype=bool)

    matched_idx, delta_s = [], []
    for _, ev in gt.iterrows():
        coming = ev["coming"]
        going = ev["going"] if pd.notna(ev.get("going")) else coming
        win_start = np.datetime64(coming - tol)
        win_end = np.datetime64(going + tol)

        if len(starts):
            overlap = (starts <= win_end) & (ends >= win_start)
            idxs = np.nonzero(overlap)[0]
        else:
            idxs = np.array([], dtype=int)

        if len(idxs):
            used[idxs] = True  # every overlapping interval belongs to this event, not just the nearest
            diffs = np.abs((starts[idxs] - np.datetime64(coming)) / np.timedelta64(1, "s"))
            best_local = int(idxs[int(np.argmin(diffs))])
            matched_idx.append(best_local)
            delta_s.append(float(diffs.min()))
        else:
            matched_idx.append(None)
            delta_s.append(None)

    gt = gt.copy()
    gt["matched_interval_idx"] = matched_idx
    gt["delta_seconds"] = delta_s
    gt["status"] = np.where(gt["matched_interval_idx"].notna(), "matched", "missed")

    if plc_times is not None and len(plc_times):
        plc_times_arr = np.asarray(plc_times, dtype="datetime64[ns]")
        going_filled = gt["going"].fillna(gt["coming"]) if "going" in gt.columns else gt["coming"]
        win_start_s = (gt["coming"] - tol).to_numpy(dtype="datetime64[ns]")
        win_end_s = (going_filled + tol).to_numpy(dtype="datetime64[ns]")
        lo_idx = np.searchsorted(plc_times_arr, win_start_s, side="left")
        hi_idx = np.searchsorted(plc_times_arr, win_end_s, side="right")
        has_plc_data = hi_idx > lo_idx
        missed_mask = (gt["status"] == "missed").to_numpy()
        gt.loc[missed_mask & ~has_plc_data, "status"] = "no_data"

    tp = int((gt["status"] == "matched").sum())
    fn = int((gt["status"] == "missed").sum())
    no_data = int((gt["status"] == "no_data").sum())
    fp = int((~used).sum())

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None  # no_data intentionally excluded from this denominator
    f1 = (2 * precision * recall / (precision + recall)) if precision and recall and (precision + recall) > 0 else None

    extra_intervals = intervals.loc[~used].reset_index(drop=True)

    return {
        "tp": tp, "fp": fp, "fn": fn, "no_data": no_data,
        "precision": precision, "recall": recall, "f1": f1,
        "matched_events": gt,
        "extra_intervals": extra_intervals,
    }


# --------------------------------------------------------------------------
# Root-cause classification (human-in-the-loop)
# --------------------------------------------------------------------------

def _to_native(v):
    """Convert a NumPy/pandas scalar to a plain Python type so it's
    JSON-serializable (jsonify chokes on numpy.int64, numpy.float64, etc.)."""
    if v is None:
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (np.floating,)):
        return None if np.isnan(v) else float(v)
    if isinstance(v, (np.bool_,)):
        return bool(v)
    if isinstance(v, pd.Timestamp):
        return str(v)
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    return v


def snapshot_features(plc: pd.DataFrame, ts_col: str, times, feature_columns: list[str]) -> list[dict]:
    """For each timestamp in times, find the nearest PLC row (plc must be
    sorted by ts_col) and return its values for feature_columns. Used to
    capture the machine's context (valve state, engine running, position,
    etc.) at the moment each fault occurred."""
    ts = plc[ts_col].to_numpy()
    times = pd.to_datetime(pd.Series(times)).to_numpy()
    rows = []
    for t in times:
        idx = int(np.searchsorted(ts, t))
        candidates = [i for i in (idx - 1, idx) if 0 <= i < len(ts)]
        if not candidates:
            rows.append({c: None for c in feature_columns})
            continue
        best = min(candidates, key=lambda i: abs(ts[i] - t))
        row = plc.iloc[best]
        rows.append({c: (None if c not in plc.columns else _to_native(row[c])) for c in feature_columns})
    return rows


def _feature_match(a, b, tolerance: float) -> bool:
    """Does value a match representative value b, within tolerance?
    tolerance <= 0 means an exact match is required."""
    if a is None or b is None:
        return a == b
    if tolerance and tolerance > 0:
        try:
            return abs(float(a) - float(b)) <= tolerance
        except (TypeError, ValueError):
            return a == b
    return a == b


def bucket_index(value, buckets: list) -> tuple:
    """buckets: [{"upper_bound": float|None, "label": str}, ...] sorted
    ascending, last entry's upper_bound is None (catch-all). Returns
    (index, label) for the first bucket whose upper_bound exceeds value,
    or (None, None) if value is None."""
    if value is None or not buckets:
        return None, None
    for i, b in enumerate(buckets):
        if b["upper_bound"] is None or value < b["upper_bound"]:
            return i, b["label"]
    return len(buckets) - 1, buckets[-1]["label"]


def is_digital_column(plc: pd.DataFrame, col: str, sample: int = 5000) -> bool:
    """Auto-detects whether a column is digital (only ever 0/1) or analog,
    so the right sensor-health check applies without the engineer having to
    classify every column by hand."""
    if col not in plc.columns:
        return False
    s = plc[col].dropna()
    if len(s) > sample:
        s = s.sample(sample, random_state=0)
    if s.empty:
        return False
    return bool(s.isin([0, 1]).all())


def analog_jump_baseline(plc: pd.DataFrame, col: str, iqr_multiplier: float = 3.0):
    """Learns what a 'normal' step size looks like for an analog column
    from its own history, using an IQR-based outlier bound — the same
    robust-statistics idea as a boxplot's whiskers. No manually-chosen
    jump size; each sensor gets its own learned baseline."""
    if col not in plc.columns:
        return None
    diffs = plc[col].diff().abs().dropna()
    if diffs.empty:
        return None
    q1, q3 = diffs.quantile(0.25), diffs.quantile(0.75)
    iqr = q3 - q1
    bound = float(q3 + iqr_multiplier * iqr) if iqr > 0 else float(diffs.quantile(0.995))
    return {"bound": bound, "median_jump": float(diffs.median())}


def check_analog_jump(plc: pd.DataFrame, ts_col: str, col: str, window_start, window_end, baseline) -> dict:
    """Checks whether col made an abnormally large jump (vs its own
    learned baseline) within [window_start, window_end]."""
    if baseline is None:
        return {"flagged": False, "max_jump": 0.0, "bound": None}
    sub = plc[(plc[ts_col] >= window_start) & (plc[ts_col] <= window_end)]
    if len(sub) < 2:
        return {"flagged": False, "max_jump": 0.0, "bound": baseline["bound"]}
    diffs = sub[col].diff().abs().dropna()
    max_jump = float(diffs.max()) if len(diffs) else 0.0
    return {"flagged": max_jump > baseline["bound"], "max_jump": max_jump, "bound": baseline["bound"]}


def natural_split(values: list, min_gap_ratio: float = 0.15):
    """Unsupervised guess at a meaningful split point in a distribution,
    used before there's enough engineer feedback to find one with actual
    evidence: finds the single largest gap between consecutive sorted
    values and returns its midpoint — but only if that gap is a real
    fraction of the overall spread (min_gap_ratio), otherwise returns None
    rather than pretending a split exists in a smooth distribution.
    """
    vals = sorted({v for v in values if v is not None})
    if len(vals) < 2:
        return None
    span = vals[-1] - vals[0]
    if span <= 0:
        return None
    best_gap, best_mid = 0, None
    for i in range(len(vals) - 1):
        gap = vals[i + 1] - vals[i]
        if gap > best_gap:
            best_gap, best_mid = gap, (vals[i] + vals[i + 1]) / 2
    if best_gap / span < min_gap_ratio:
        return None
    return best_mid


def suggest_threshold(labeled_points: list, target_label: str, min_samples: int = 7):
    """Given (value, label) pairs across ALL descriptions assigned so far
    on one diagnostic column, finds the single split point that best
    separates target_label from everything else — a one-level decision
    tree / decision stump, chosen for being exactly as transparent as the
    conclusion it draws. Returns None if there isn't enough contrasting
    evidence yet (needs both target_label examples AND other-label
    examples — a single class alone has no boundary to find).
    """
    pts = [(v, l) for v, l in labeled_points if v is not None]
    n_target = sum(1 for _, l in pts if l == target_label)
    n_other = len(pts) - n_target
    if n_target < min_samples or n_other < 2:
        return None
    values = sorted({v for v, _ in pts})
    if len(values) < 2:
        return None
    best = None
    for i in range(len(values) - 1):
        split = (values[i] + values[i + 1]) / 2
        acc_lt = sum(1 for v, l in pts if (v < split) == (l == target_label)) / len(pts)
        acc_ge = sum(1 for v, l in pts if (v >= split) == (l == target_label)) / len(pts)
        if acc_lt >= acc_ge and (best is None or acc_lt > best[0]):
            best = (acc_lt, split, "<")
        elif acc_ge > acc_lt and (best is None or acc_ge > best[0]):
            best = (acc_ge, split, ">=")
    if best is None:
        return None
    confidence, threshold, direction = best
    return {"threshold": threshold, "direction": direction, "confidence": confidence, "n": len(pts), "n_target": n_target}


def check_trigger_variance(feature_rows: dict, feature_specs: list[dict]) -> list[str]:
    """Warn about any "trigger" column that isn't actually constant across
    the matched events. A trigger variable is only safe to exclude from
    clustering because it's supposed to already be guaranteed by the fault's
    rule condition (e.g. Jerk >= 6 is always true whenever the fault fires).
    If a column tagged trigger actually varies, it was probably mistagged —
    it's carrying real discriminating information that's silently being
    thrown away."""
    warnings = []
    for s in feature_specs:
        if s.get("role", "diagnostic") != "trigger":
            continue
        col = s["column"]
        values = {row.get(col) for row in feature_rows.values() if row.get(col) is not None}
        if len(values) > 1:
            sample = ", ".join(str(v) for v in list(values)[:5])
            warnings.append(
                f'"{col}" is marked as a trigger variable but its value actually varies across occurrences '
                f"(found: {sample}) — trigger columns are excluded from grouping, so this may be merging "
                f"occurrences that should be treated as different root causes. Consider marking it as a "
                f"diagnostic feature instead."
            )
    return warnings


def compute_flicker_info(plc: pd.DataFrame, ts_col: str, trigger_columns: list, window_start, window_end, threshold: int = 2) -> dict:
    """Count how many times each trigger column rises 0->1 within
    [window_start, window_end]. One clean rise means the sensor latched
    normally; two or more means it flickered (chattered) rather than
    latching cleanly — a hardware/contact reliability signature, not a
    real detection pattern."""
    sub = plc[(plc[ts_col] >= window_start) & (plc[ts_col] <= window_end)]
    counts = {}
    flicker = False
    for col in trigger_columns:
        if col not in sub.columns or sub.empty:
            counts[col] = 0
            continue
        series = sub[col]
        rising = int(((series.shift(1) == 0) & (series != 0)).sum())
        counts[col] = rising
        if rising >= threshold:
            flicker = True
    return {"counts": counts, "flicker": flicker}


def _diagnostic_mask(plc: pd.DataFrame, diagnostic_specs: list, representative: dict) -> pd.Series:
    """Vectorized version of _feature_match across a whole PLC column: True
    wherever every diagnostic column's value is within tolerance of the
    cluster's representative value (proximity mode) or in the same bucket
    (threshold mode) — used to find every time the machine was "at" this
    pattern, not just the times a fault happened to also fire."""
    mask = pd.Series(True, index=plc.index)
    for s in diagnostic_specs:
        col = s["column"]
        rep = representative.get(col)
        if rep is None or col not in plc.columns:
            continue
        if s.get("mode") == "threshold":
            buckets = s.get("buckets", [])
            rep_idx, _ = bucket_index(rep, buckets)
            idxs = plc[col].apply(lambda v: bucket_index(v, buckets)[0])
            mask &= (idxs == rep_idx)
        else:
            tol = s.get("tolerance") or 0
            if tol > 0:
                mask &= (plc[col] - rep).abs() <= tol
            else:
                mask &= plc[col] == rep
    return mask


def compute_cluster_risk(plc: pd.DataFrame, ts_col: str, diagnostic_specs: list, representative: dict,
                          max_gap_seconds: float, fault_starts, ewma_span: float = 10) -> dict:
    """Exposure-normalized, recency-weighted risk for one cluster's pattern.

    Finds every time the machine's diagnostic columns were near this
    cluster's representative values at all (not just when the fault also
    fired) — each contiguous stretch is one "visit." For each visit,
    chronologically, records whether a fault's own trigger onset fell
    inside it. Two numbers come out of that sequence:
      - wilson_lower: a statistically conservative lower bound on the
        overall fault rate across all visits (protects against small
        sample sizes making a rare event look artificially damning)
      - ewma_risk: an exponentially-weighted moving average over the same
        sequence, so recent visits count more than old ones — if the
        underlying cause gets fixed, a run of clean visits pulls this back
        down within roughly ewma_span visits, with no date to configure.
    """
    mask = _diagnostic_mask(plc, diagnostic_specs, representative)
    intervals = mask_to_intervals(plc[ts_col], mask, max_gap_seconds)
    if intervals.empty:
        return {"exposure_count": 0, "fault_count": 0, "rate": None, "wilson_lower": None, "ewma_risk": None}

    starts = intervals["start"].to_numpy()
    ends = intervals["end"].to_numpy()
    fs = np.sort(pd.to_datetime(pd.Series(list(fault_starts))).to_numpy()) if len(fault_starts) else np.array([], dtype="datetime64[ns]")

    outcomes = []
    for i in range(len(starts)):
        if len(fs) == 0:
            outcomes.append(0)
            continue
        lo = int(np.searchsorted(fs, starts[i], side="left"))
        outcomes.append(1 if (lo < len(fs) and fs[lo] <= ends[i]) else 0)

    n = len(outcomes)
    fault_count = sum(outcomes)
    rate = fault_count / n if n else None

    wilson_lower = None
    if n > 0:
        z = 1.96
        phat = rate
        denom = 1 + z * z / n
        centre = phat + z * z / (2 * n)
        adj = z * ((phat * (1 - phat) + z * z / (4 * n)) / n) ** 0.5
        wilson_lower = max(0.0, (centre - adj) / denom)

    ewma = None
    alpha = 2 / (ewma_span + 1) if ewma_span else 1.0
    for o in outcomes:
        ewma = float(o) if ewma is None else (alpha * o + (1 - alpha) * ewma)

    return {"exposure_count": n, "fault_count": fault_count, "rate": rate,
            "wilson_lower": wilson_lower, "ewma_risk": ewma}


def _tuplify(x):
    """JSON turns tuples into lists; turn them back so saved cluster keys
    still compare equal after the app restarts."""
    return tuple(_tuplify(i) for i in x) if isinstance(x, (list, tuple)) else x


def cluster_events(feature_rows: dict, feature_specs: list[dict], clusters: list[dict], machine_by_key: dict | None = None) -> dict:
    """Group events into pattern clusters by their diagnostic-feature values.

    feature_rows: {event_key: {column: value, ...}}
    feature_specs: [{"column": str, "role": "trigger"|"diagnostic",
                      "mode": "proximity"|"threshold", "tolerance": float,
                      "buckets": [...]}]
        Only "diagnostic" columns are used for grouping. "proximity" columns
        group values within +/- tolerance of the first value seen;
        "threshold" columns sort events into pre-named buckets.

    machine_by_key: optional {event_key: machine name}. When given, machines
        never share a cluster — a position or reading on one machine is not
        assumed to mean the same thing on another — and each cluster
        remembers which machine it belongs to.

    clusters: the fault's persisted cluster list (mutated in place).
    Returns {event_key: cluster_id}.
    """
    diagnostic_specs = [s for s in feature_specs if s.get("role", "diagnostic") != "trigger"]
    threshold_specs = [s for s in diagnostic_specs if s.get("mode") == "threshold"]
    proximity_specs = [s for s in diagnostic_specs if s.get("mode") != "threshold"]

    assignment = {}
    for key, feats in feature_rows.items():
        machine = machine_by_key.get(key) if machine_by_key is not None else None
        part_key = []
        label_parts = []
        for s in threshold_specs:
            idx, label = bucket_index(feats.get(s["column"]), s.get("buckets", []))
            part_key.append((s["column"], idx))
            if label:
                label_parts.append(label)
        if machine_by_key is not None:
            part_key.append(("__machine__", machine))
        part_key = tuple(part_key)
        threshold_desc = " + ".join(label_parts) if label_parts else ""

        match = None
        for cl in clusters:
            if _tuplify(cl.get("partition_key", ())) != part_key:
                continue
            if all(_feature_match(feats.get(s["column"]), cl["representative"].get(s["column"]), s.get("tolerance") or 0)
                   for s in proximity_specs):
                match = cl
                break
        if match is None:
            match = {
                "id": f"c{len(clusters) + 1}",
                "code": f"RC-{len(clusters) + 1}",
                "description": threshold_desc,
                "representative": dict(feats),
                "partition_key": part_key,
            }
            if machine_by_key is not None:
                match["machine"] = machine
            clusters.append(match)
        assignment[key] = match["id"]
    return assignment


# --------------------------------------------------------------------------
# End-to-end per-fault run
# --------------------------------------------------------------------------

def run_fault(plc: pd.DataFrame, ts_col: str, versions: list[dict],
              max_gap_seconds: float, min_duration_seconds: float,
              ground_truth: pd.DataFrame, tolerance_seconds: float, bypasses: dict | None = None,
              keep_from=None) -> dict:
    """keep_from: when a date range is evaluated, the PLC data passed in starts a little earlier (a warm-up, so
    timers already running at the start are counted correctly); predicted intervals that end before keep_from
    belong to that warm-up and are dropped."""
    mask = evaluate_versions(plc, ts_col, versions, bypasses)
    intervals = mask_to_intervals(plc[ts_col], mask, max_gap_seconds)
    intervals = filter_min_duration(intervals, min_duration_seconds)
    if keep_from is not None and len(intervals):
        intervals = intervals.loc[intervals["end"] >= keep_from].reset_index(drop=True)
    plc_times = plc[ts_col].to_numpy()
    result = match_events(intervals, ground_truth, tolerance_seconds, plc_times=plc_times)
    result["intervals"] = intervals
    return result
