"""
crane_status.py
===============
Live status of all cranes.  Works while the launcher runs as a Windows service
(no window), because it reads the status files the collectors write.

    python crane_status.py          # refreshes every 5 s, Ctrl+C to close
    python crane_status.py --once   # print once and exit
"""
import json
import os
import sys
import time
from datetime import datetime

import collector_settings as S

if os.name == "nt":
    os.system("")                       # enable colours in the Windows console

GREEN, YELLOW, RED, GREY, BOLD, END = ("\033[92m", "\033[93m", "\033[91m",
                                        "\033[90m", "\033[1m", "\033[0m")


def _load(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _age(t, now):
    if not t:
        return "never"
    s = int(now - t)
    return f"{s}s ago" if s < 120 else f"{s // 60}m ago" if s < 7200 else f"{s // 3600}h ago"


def crane_state(st, running, now):
    """Return (state, colour, note) for one crane."""
    if st is None:
        return ("STARTING", YELLOW, "") if running else ("DOWN", RED, "collector not running")
    if now - st["updated"] > S.STALE_AFTER_SEC or not running:
        return "DOWN", RED, st.get("last_error") or "collector not running"
    if len(st.get("sources_60s", [])) > 1:
        return "2+ SOURCES", RED, "several PLCs send to this port: " + ", ".join(st["sources_60s"])
    if not st["last_packet_time"] or now - st["last_packet_time"] > S.NO_DATA_AFTER_SEC:
        return "NO DATA", YELLOW, "no UDP packets - crane off / PLC / network?"
    if st["last_size"] != st["expected_size"]:
        return "WRONG SIZE", RED, (f"got {st['last_size']} bytes, v{st['version']} expects "
                                   f"{st['expected_size']} - check Collector Version")
    if st.get("last_write_ok") is False:
        return "INFLUX ERR", RED, (st.get("last_error") or "")[:60]
    return "OK", GREEN, ""


def show(clear=False, footer=""):
    now = time.time()
    launcher = _load(S.STATUS_DIR / "launcher.json")
    lines = []
    if clear:
        os.system("cls" if os.name == "nt" else "clear")
    lines.append(f"{BOLD}TERMINAL 2 CRANE COLLECTORS   {datetime.now():%Y-%m-%d %H:%M:%S}{END}")

    if launcher is None:
        lines.append(f"{RED}Launcher has never run (no status/launcher.json).{END}")
        print("\n".join(lines))
        return
    if now - launcher["updated"] > S.STALE_AFTER_SEC:
        lines.append(f"{RED}LAUNCHER IS NOT RUNNING (last seen {_age(launcher['updated'], now)}). "
                     f"Start the service / launch_cranes.py{END}")
    else:
        lines.append(f"Launcher OK (pid {launcher['pid']})")
    lines.append("")
    lines.append(f"{'CRANE':<6}{'PORT':>6} {'VER':<4}{'STATE':<12}{'PKT/min':>8}  "
                 f"{'LAST PACKET':<12}{'SIZE':>5} {'FROM':<16}{'WRITTEN':>9}{'RESTARTS':>9}  NOTE")

    counts = {}
    for c in launcher["cranes"]:
        st = _load(S.STATUS_DIR / f"{c['crane']}.json")
        state, colour, note = crane_state(st, c["running"], now)
        counts[state] = counts.get(state, 0) + 1
        st = st or {}
        lines.append(
            f"{c['crane']:<6}{c['port']:>6} {c['version']:<4}{colour}{state:<12}{END}"
            f"{st.get('packets_last_60s', 0):>8}  {_age(st.get('last_packet_time'), now):<12}"
            f"{str(st.get('last_size') or '-'):>5} {str(st.get('last_source') or '-'):<16}"
            f"{st.get('packets_written', 0):>9}{c['restarts']:>9}  {GREY}{note}{END}"
        )
    for s in launcher.get("skipped", []):
        lines.append(f"{s['crane']:<6}{'':>6} {'':<4}{GREY}{'NOT STARTED':<12}{END}"
                     f"{'':>8}  {'':<12}{'':>5} {'':<16}{'':>9}{'':>9}  {GREY}{s['reason']}{END}")
    lines.append("")
    lines.append("Summary: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())))
    if footer:
        lines.append(footer)
    print("\n".join(lines), flush=True)


def main():
    if "--once" in sys.argv:
        show()
        return
    try:
        while True:
            show(clear=True, footer="Refreshing every 5 s - Ctrl+C to close (cranes keep running)")
            time.sleep(5)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
