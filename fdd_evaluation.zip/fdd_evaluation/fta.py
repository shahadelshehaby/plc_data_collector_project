"""Fault Tree Analysis tab (Root Cause program).

Draws the rule logic saved in the Evaluation program as a fault tree: the fault is the top event, AND / OR gates sit
below it, and every condition (a PLC column compared with a value) is a box at the bottom. It only READS the
Evaluation program's settings (programs.json and programs/<key>/fdd_settings.json); nothing is written.

How the gates are built: the Evaluation engine combines a rule's conditions strictly from top to bottom
(((c1 <joiner2> c2) <joiner3> c3) ...), with no AND-before-OR precedence; a sub-logic (brackets) is combined first
and becomes its own gate. The tree follows exactly that, so what
is drawn is what Evaluate computes. A run of the same joiner becomes ONE gate with several inputs.
"""
from flask import jsonify, request

from rc_common import load_registry, program_label, read_json, ws_paths

_OP = {">=": "≥", "<=": "≤", "!=": "≠", "==": "=", ">": ">", "<": "<", "in": "∈", "not_in": "∉"}


def _fmt(v):
    try:
        f = float(v)
        return str(int(f)) if f == int(f) else f"{f:g}"
    except (TypeError, ValueError):
        return str(v)


def _leaf(c: dict, bypasses=None) -> dict:
    mode, mv = c.get("mode") or "none", c.get("mode_value") or 0
    extras = []
    if mode == "timer" and mv:
        extras.append(f"true for ≥ {_fmt(mv)} s")
    value = _fmt(c.get("value"))
    if c.get("op") in ("in", "not_in"):
        bp = (bypasses or {}).get(c.get("bypass"))
        value = bp.get("name") or "(no name)" if bp else "(missing bypass)"
        if bp and bp.get("versions"):
            latest = sorted(bp["versions"], key=lambda v: str(v.get("effective_from") or ""))[-1]
            rng = ", ".join(f"{_fmt(r.get('from'))}–{_fmt(r.get('to'))}" for r in latest.get("ranges") or [])
            extras.append(f"ranges {rng or 'none'}" + (f" (latest of {len(bp['versions'])} versions)" if len(bp["versions"]) > 1 else ""))
        if mode == "tolerance" and mv:
            extras.append(f"ranges widened ± {_fmt(mv)}")
    elif mode == "tolerance" and mv:
        extras.append(f"tolerance ± {_fmt(mv)}")
    return {"t": "leaf", "column": str(c.get("column", "?")), "op": _OP.get(c.get("op"), c.get("op", "?")),
            "value": value, "extra": " · ".join(extras)}


def _text(n: dict) -> str:
    if n["t"] == "leaf":
        return f"{n['column']} {n['op']} {n['value']}"
    if n["t"] == "tag":
        return f"[{n['label']}] {_text(n['children'][0])}"
    inner = f" {n['gate']} ".join(_text(c) for c in n["children"])
    return f"({inner})"


def build_conditions_tree(conditions: list, bypasses=None):
    """Left-to-right fold of the conditions, exactly like the Evaluation engine. Returns a node or None.
    A sub-logic {"type": "group", ...} is built on its own first (like brackets) and joined as ONE input, so it
    becomes its own gate; a sub-logic with a timer is drawn as a labelled box above that gate."""
    acc = None
    for i, c in enumerate(conditions or []):
        if c.get("type") == "group":
            leaf = build_conditions_tree(c.get("conditions"), bypasses)
            if leaf is None:
                continue                      # an empty sub-logic is ignored by the engine too
            leaf.pop("fold", None)            # never merge a bracket into the gate around it
            if c.get("mode") == "timer" and c.get("mode_value"):
                leaf = {"t": "tag", "label": f"true for ≥ {_fmt(c.get('mode_value'))} s", "children": [leaf]}
        else:
            leaf = _leaf(c, bypasses)
        if acc is None:
            acc = leaf
            continue
        j = "OR" if c.get("joiner") == "OR" else "AND"
        if acc["t"] == "gate" and acc["gate"] == j and acc.get("fold"):
            acc["children"].append(leaf)
        else:
            acc = {"t": "gate", "gate": j, "children": [acc, leaf], "fold": True}
    return acc


def _clean(n):
    if isinstance(n, dict):
        n.pop("fold", None)
        for c in n.get("children", []):
            _clean(c)
    return n


def build_fault_tree(name: str, rule: dict, bypasses=None) -> dict:
    versions = sorted(rule.get("versions") or [], key=lambda v: (v.get("effective_from") is not None, str(v.get("effective_from") or "")))
    branches = []
    for v in versions:
        t = build_conditions_tree(v.get("conditions"), bypasses)
        if t is None:
            continue
        branches.append((v.get("effective_from"), t))
    if not branches:
        return {"name": name, "tree": None, "expression": "", "versions": 0}
    if len(branches) == 1:
        child = branches[0][1]
        expr = _text(child)
    else:
        kids = []
        for eff, t in branches:
            label = "Logic from " + (str(eff)[:10] if eff else "the start")
            kids.append({"t": "tag", "label": label, "children": [t]})
        child = {"t": "gate", "gate": "OR", "note": "the logic version in force", "children": kids}
        expr = "  |  ".join(f"[{k['label']}] {_text(k['children'][0])}" for k in kids)
    tree = {"t": "top", "label": name, "children": [child]}
    return {"name": name, "tree": _clean(tree), "expression": expr, "versions": len(branches)}


def _program_info(prog: dict):
    key = prog["key"]
    st = read_json(ws_paths(key).settings, {}) or {}
    rules = st.get("rules") or {}
    faults = [{"name": n, "has_logic": any((v.get("conditions") for v in (r.get("versions") or [])))}
              for n, r in sorted(rules.items(), key=lambda kv: kv[0].lower())]
    m = st.get("mapping") or {}
    return {"key": key, "label": program_label(prog), "terminal": prog.get("terminal"), "type": prog.get("type"),
            "faults": faults,
            "min_duration_seconds": m.get("min_duration_seconds") or 0}


def register(app):
    @app.route("/api/fta/programs")
    def fta_programs():
        progs = [_program_info(p) for p in load_registry()["programs"]]
        progs.sort(key=lambda p: (str(p["terminal"]), str(p["type"]).lower()))
        return jsonify(ok=True, programs=progs)

    @app.route("/api/fta/trees", methods=["POST"])
    def fta_trees():
        b = request.get_json(force=True) or {}
        key, names = b.get("program"), b.get("faults") or []
        prog = next((p for p in load_registry()["programs"] if p["key"] == key), None)
        if not prog:
            return jsonify(ok=False, error="That program was not found in the Evaluation program."), 404
        st = read_json(ws_paths(key).settings, {}) or {}
        rules = st.get("rules") or {}
        info = _program_info(prog)
        out = []
        for n in names:
            r = rules.get(n)
            out.append(build_fault_tree(n, r, st.get("bypasses")) if r is not None else {"name": n, "tree": None, "expression": "", "versions": 0})
        return jsonify(ok=True, program_label=info["label"], min_duration_seconds=info["min_duration_seconds"], trees=out)
