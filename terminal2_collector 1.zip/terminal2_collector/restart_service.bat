@echo off
REM Run as administrator after you change the Excel file or the scripts.
cd /d "%~dp0"
python launch_cranes.py --check
if errorlevel 1 ( pause & exit /b 1 )
"%~dp0nssm.exe" restart CraneCollectorT2
pause
