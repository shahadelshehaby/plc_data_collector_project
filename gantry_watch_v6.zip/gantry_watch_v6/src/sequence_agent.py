"""
sequence_agent.py
==================
Evaluation 1 - Step Sequence (see reference doc Section 3).

Row-by-row evaluation of the Step transitions within a single MoveType=3
phase. Runs completely independently of the performance and necessity
agents - it only needs the phase's own rows plus config thresholds.
"""
from dataclasses import dataclass, field
from typing import List, Optional
from columns import step_name, resolve_all_axis_columns


@dataclass
class StepEvent:
    step: int
    kind: str          # 'normal' | 'minor_waste' | 'abnormal'
    note: str
    time: str
    duration_s: float

    @property
    def symbol(self):
        return {"normal": "\u2713", "minor_waste": "\u26a0",
                "abnormal": "\u2717", "manual_intervention": "\u26a0"}[self.kind]

    def to_dict(self):
        return {
            "step": self.step,
            "step_name": step_name(self.step),
            "kind": self.kind,
            "note": self.note,
            "time": self.time,
            "duration_s": self.duration_s,
        }


@dataclass
class SequenceResult:
    dominant_axis: str
    hoist_start: float
    events: List[StepEvent] = field(default_factory=list)
    step_sequence: str = ""

    @property
    def has_abnormal(self):
        return any(e.kind == "abnormal" for e in self.events)

    @property
    def has_minor_waste(self):
        return any(e.kind == "minor_waste" for e in self.events)

    @property
    def has_manual_intervention(self):
        return any(e.kind == "manual_intervention" for e in self.events)

    def to_dict(self):
        return {
            "dominant_axis": self.dominant_axis,
            "hoist_start": self.hoist_start,
            "step_sequence": self.step_sequence,
            "events": [e.to_dict() for e in self.events],
            "has_abnormal": self.has_abnormal,
            "has_minor_waste": self.has_minor_waste,
            "has_manual_intervention": self.has_manual_intervention,
        }


def _detect_dominant_axis(phase_df, axis_cols, movement_steps=(5, 6)):
    """
    Whichever axis's ACTUAL position changes the most during the movement
    steps (Settings > Step sequence rules; 5 and 6 by default) is the
    dominant (moving) axis - i.e. whichever axis really travels, not
    whichever axis merely has a big reference-vs-actual gap at one snapshot
    row. Measuring actual movement range directly answers "which axis moved."
    """
    move_rows = phase_df[phase_df["Step"].isin(list(movement_steps))]
    probe_rows = move_rows if not move_rows.empty else phase_df

    best_axis, best_range = "gantry", -1.0
    for axis, cols in axis_cols.items():
        try:
            vals = probe_rows[cols["actual"]].astype(float)
            axis_range = float(vals.max() - vals.min())
        except (KeyError, ValueError, TypeError):
            axis_range = -1.0
        if axis_range > best_range:
            best_range = axis_range
            best_axis = axis
    return best_axis


def _row_transitions(phase_df):
    """Collapses consecutive identical Step values into transition events
    (start row index, step value)."""
    step = phase_df["Step"].astype(float).astype(int)
    changed = step != step.shift()
    return list(phase_df.index[changed.to_numpy()])


def _lift_event(kind, step, axis, safe_height, ts, dur):
    notes = {
        "minor_waste": f"{axis.title()} is above {safe_height:.1f} so Step {step} is minor waste of time",
        "abnormal": f"Step {step} out of sequence and {axis} already \u2265 {safe_height:.1f}m",
        "normal": f"step is normal ({step_name(step)}; {axis} already at or above {safe_height:.1f}m)",
    }
    return StepEvent(step=step, kind=kind, note=notes[kind], time=ts, duration_s=dur)


def evaluate_sequence(phase_df, config, hoist_col=None) -> SequenceResult:
    """Checks one reposition's steps against the rules (rules.py):
    expected_order, lift_step / height_axis / safe height, movement_steps,
    end-position check, manual-intervention step, resume after interruption."""
    rules = config.rules
    axis_cols = resolve_all_axis_columns(phase_df, config.columns)
    if hoist_col is None:
        hoist_col = axis_cols[rules.height_axis]["actual"]
    dominant_axis = _detect_dominant_axis(phase_df, axis_cols, rules.movement_steps)
    hoist_start = float(phase_df[hoist_col].iat[0])
    safe_height = config.thresholds.hoist_safe_height_m
    tol = config.thresholds.step_match_tolerance_m

    expected_sequence = list(rules.expected_order)
    lift_step, mi_step = rules.lift_step, rules.mi_step
    movement_steps = set(rules.movement_steps)
    ptr = 0  # index into expected_sequence of the next step we expect
    last_good_step = None
    grace_available = False

    events: List[StepEvent] = []
    transition_idxs = _row_transitions(phase_df)
    n = len(phase_df)

    def duration_for(pos):
        start_time = phase_df.iloc[transition_idxs[pos]]["_ts"]
        # end time = first row of NEXT event, or last row of phase if final event
        if pos + 1 < len(transition_idxs):
            end_time = phase_df.iloc[transition_idxs[pos + 1]]["_ts"]
        else:
            end_time = phase_df["_ts"].iat[-1]
        return start_time, end_time

    def expected_text():
        if ptr < len(expected_sequence):
            return f"{expected_sequence[ptr]}({step_name(expected_sequence[ptr])})"
        return "none"

    i = 0
    while i < len(transition_idxs):
        idx = transition_idxs[i]
        step = int(phase_df["Step"].iat[idx])
        start_time, end_time = duration_for(i)
        dur = (end_time - start_time).total_seconds()
        ts_str = str(phase_df["_ts"].iat[idx])

        if mi_step is not None and step == mi_step:
            # One manual-intervention event: this step, plus the configured
            # step right after it (step 3 by default), if it comes next.
            mi_steps = [mi_step]
            j = i + 1
            block_end_time = end_time
            if (rules.mi_absorbs_step is not None and j < len(transition_idxs)
                    and int(phase_df.iloc[transition_idxs[j]]["Step"]) == rules.mi_absorbs_step):
                _, block_end_time = duration_for(j)
                mi_steps.append(rules.mi_absorbs_step)
                j += 1
            total_dur = (block_end_time - start_time).total_seconds()
            seq_desc = " \u2192 ".join(f"{s}({step_name(s)})" for s in mi_steps)
            events.append(StepEvent(step=mi_step, kind="manual_intervention",
                                    note=f"MI sequence: {seq_desc}", time=ts_str, duration_s=total_dur))
            grace_available = rules.resume_after_interruption
            i = j
            continue

        matched_pos = None
        for p in range(ptr, len(expected_sequence)):
            if expected_sequence[p] == step:
                matched_pos = p
                break

        if grace_available and last_good_step is not None and step == last_good_step:
            events.append(StepEvent(
                step=step, kind="normal",
                note=(f"resume after interruption \u2014 next expected: {expected_text()}"
                      if ptr < len(expected_sequence) else "resume after interruption"),
                time=ts_str, duration_s=dur,
            ))
            grace_available = False
            i += 1
            continue

        grace_available = False

        if matched_pos is not None:
            if lift_step is not None and step == lift_step:
                high = hoist_start >= safe_height
                if matched_pos == ptr and high:
                    events.append(_lift_event(rules.lift_when_high, step, rules.height_axis,
                                              safe_height, ts_str, dur))
                elif matched_pos != ptr and high:
                    events.append(_lift_event(rules.lift_out_of_order_when_high, step, rules.height_axis,
                                              safe_height, ts_str, dur))
                else:
                    events.append(StepEvent(
                        step=step, kind="normal",
                        note=f"step is normal (lifting {rules.height_axis} to safe travel height)",
                        time=ts_str, duration_s=dur,
                    ))
            elif step in movement_steps:
                # movement step: converging check using the dominant axis
                cols = axis_cols[dominant_axis]
                is_last_row_of_phase = (i == len(transition_idxs) - 1)
                if is_last_row_of_phase and rules.check_end_position:
                    last_row = phase_df.iloc[-1]
                    end_gap = abs(float(last_row[cols["ref"]]) - float(last_row[cols["actual"]]))
                    if end_gap <= tol:
                        note = f"step is normal ({dominant_axis} reference matching {dominant_axis} actual position)"
                        kind = "normal"
                    else:
                        note = (f"{dominant_axis} reference/actual gap ({end_gap:.2f}m) exceeds "
                                f"tolerance ({tol:.1f}m) at end of phase")
                        kind = "abnormal"
                else:
                    note = f"step is normal ({dominant_axis} reference moving towards {dominant_axis} actual position)"
                    kind = "normal"
                events.append(StepEvent(step=step, kind=kind, note=note, time=ts_str, duration_s=dur))
            else:
                events.append(StepEvent(step=step, kind="normal", note=f"step is normal ({step_name(step)})",
                                        time=ts_str, duration_s=dur))

            ptr = matched_pos + 1
            last_good_step = step
        else:
            events.append(StepEvent(
                step=step, kind="abnormal",
                note=f"Step {step}({step_name(step)}) out of sequence \u2014 next expected: {expected_text()}",
                time=ts_str, duration_s=dur,
            ))
            grace_available = rules.resume_after_interruption

        i += 1

    step_sequence_str = " \u2192 ".join(f"{e.step}({step_name(e.step)})" for e in events)
    return SequenceResult(
        dominant_axis=dominant_axis,
        hoist_start=hoist_start,
        events=events,
        step_sequence=step_sequence_str,
    )
