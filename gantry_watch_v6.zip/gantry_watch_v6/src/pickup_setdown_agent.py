"""
pickup_setdown_agent.py
========================
Necessity evaluation for MoveType=1 (pickup) / MoveType=2 (setdown)
workorders - the counterpart to necessity_agent.py, which only covers
MoveType=3 ("move-only") phases.

Rule, exactly as specified:

  - NECESSARY: the workorder contains BOTH a MoveType=1 (pickup) phase and
    a MoveType=2 (setdown) phase, with the pickup occurring before the
    setdown - i.e. a completed pickup+setdown cycle within the same
    workorder.

  - UNNECESSARY: the workorder has ONLY a MoveType=1 phase (no MoveType=2
    phase anywhere after it in the SAME workorder), and the very next
    workorder in the file is ALSO a pickup (MoveType=1) at a different
    gantry location - i.e. whatever was picked up was never set down in
    this workorder before the crane went and picked up again elsewhere.
    This workorder's pickup achieved nothing on its own.

  - Pickup-only workorder, next workorder is something OTHER than another
    pickup (not the missing setdown, since MoveType=2 by definition shares
    the SAME WorkorderIdent as its pickup - see the doc's "Workorder
    structure" rule): still flagged unnecessary, since the required
    same-workorder setdown never happened - but worded differently so it's
    clear this isn't the specific "picked up again elsewhere" pattern.

  - UNKNOWN: the workorder has only a MoveType=1 phase and there is no
    following workorder in the file to check against at all (typically the
    very last workorder of the day) - nothing to confirm either way.

The gantry position gap between this workorder's end and the next
workorder's start is reported as descriptive context only. It does NOT
drive the necessary/unnecessary verdict here - that is driven entirely by
which MoveType phases are present, per the rule above.
"""
from dataclasses import dataclass
from typing import Optional

from columns import resolve_all_axis_columns, movetype_name


@dataclass
class PickupSetdownResult:
    has_pickup: bool
    has_setdown: bool
    necessary: bool
    unknown: bool
    next_workorder: Optional[int]
    next_move_type: Optional[int]
    gantry_gap_m: Optional[float]
    lines: list = None  # list of (symbol, text) tuples for the report
    # Distance actually covered during this workorder (pickup phase alone,
    # or pickup+setdown together when both are present) - same convention
    # as MoveType=3's performance.distance_m: the NET displacement (last
    # row minus first row) of whichever axis moved the most, not a
    # point-to-point path length. dominant_axis records which axis that
    # was (gantry/trolley/hoist) since, unlike MoveType=3, a pickup/
    # setdown can genuinely move more than one axis and there's no
    # step-based way to isolate "the" move - see _dominant_axis_and_distance().
    distance_m: Optional[float] = None
    dominant_axis: Optional[str] = None
    # Raw start/end actual positions of the dominant axis - kept alongside
    # the unsigned distance_m so callers that want a SIGNED figure (e.g.
    # the case illustration's arrow labels, matching the convention
    # MoveType=3 moves already use) can compute position_end - position_start
    # themselves. See operation_chart._signed_distance_label().
    position_start: Optional[float] = None
    position_end: Optional[float] = None

    def to_dict(self):
        return {
            "has_pickup": self.has_pickup,
            "has_setdown": self.has_setdown,
            "necessary": self.necessary,
            "unknown": self.unknown,
            "next_workorder": self.next_workorder,
            "next_move_type": self.next_move_type,
            "gantry_gap_m": round(self.gantry_gap_m, 2) if self.gantry_gap_m is not None else None,
            "distance_m": round(self.distance_m, 2) if self.distance_m is not None else None,
            "dominant_axis": self.dominant_axis,
            "position_start": round(self.position_start, 2) if self.position_start is not None else None,
            "position_end": round(self.position_end, 2) if self.position_end is not None else None,
            "lines": self.lines,
        }


def _dominant_axis_and_distance(rows, config):
    """Whichever axis' ACTUAL position RANGE (max-min) is largest across
    this workorder's rows is treated as the axis that actually moved
    during this pickup/setdown - could be trolley/hoist alignment, not
    necessarily gantry (unlike MoveType=3, more than one axis can
    legitimately move here, and there's no step-based way to isolate
    "the" move). Once that axis is picked, the reported distance is its
    NET displacement (last row - first row) - the same convention as
    MoveType=3's performance.distance_m (see performance_agent.py /
    MoveType3 project reference doc, Section 4.3), so the two numbers mean
    the same thing and are directly comparable in the reports.
    Returns (axis_name, distance_m, position_start, position_end) or
    (None, None, None, None) if it can't be determined (columns missing,
    empty rows, etc.)."""
    try:
        axis_cols = resolve_all_axis_columns(rows, config.columns)
    except Exception:
        return None, None, None, None

    best_axis, best_range = None, -1.0
    best_start, best_end = None, None
    for axis, cols in axis_cols.items():
        actual_col = cols.get("actual")
        if not actual_col or actual_col not in rows.columns:
            continue
        try:
            series = rows[actual_col].astype(float)
        except Exception:
            continue
        if series.empty:
            continue
        rng = float(series.max() - series.min())
        if rng > best_range:
            best_range = rng
            best_axis = axis
            best_start = float(series.iloc[0])
            best_end = float(series.iloc[-1])

    if best_axis is None:
        return None, None, None, None
    return best_axis, abs(best_end - best_start), best_start, best_end


def _gantry_gap(workorder, next_workorder, config) -> Optional[float]:
    try:
        axis_cols = resolve_all_axis_columns(workorder.rows, config.columns)
        gantry_actual = axis_cols["gantry"]["actual"]
        this_pos = float(workorder.rows[gantry_actual].iat[-1])
        next_pos = float(next_workorder.rows[gantry_actual].iat[0])
        return abs(this_pos - next_pos)
    except Exception:
        return None


def evaluate_pickup_setdown(workorder, next_workorder, config) -> Optional[PickupSetdownResult]:
    """
    workorder: a data_loader.Workorder whose first phase is MoveType=1
    (pickup) - see data_loader.find_pickup_workorders_with_context().
    next_workorder: the very next Workorder in the file (in time
    order), or None if this is the last one in the file.

    Returns None if `workorder` doesn't actually contain a pickup phase
    (shouldn't happen given the intended caller, but guards misuse).
    """
    rules = config.rules
    P, S = rules.pickup_type, rules.setdown_type
    move_types = [p.move_type for p in workorder.phases]
    if P not in move_types:
        return None

    idx1 = move_types.index(P)
    has_setdown = S in move_types[idx1 + 1:]

    # --- Completed pickup+setdown cycle: necessary ---
    if has_setdown:
        axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)
        return PickupSetdownResult(
            has_pickup=True, has_setdown=True, necessary=True, unknown=False,
            next_workorder=next_workorder.workorder if next_workorder else None,
            next_move_type=None, gantry_gap_m=None,
            distance_m=dist, dominant_axis=axis,
            position_start=pos_start, position_end=pos_end,
            lines=[("\u2713", f"workorder contains both pickup ({P}) and setdown ({S}) phases "
                              "\u2014 completed pickup+setdown cycle")],
        )

    # --- Pickup only, no setdown in this workorder ---
    if next_workorder is None or next_workorder.rows.empty or not next_workorder.phases:
        axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)
        return PickupSetdownResult(
            has_pickup=True, has_setdown=False, necessary=False, unknown=True,
            next_workorder=None, next_move_type=None, gantry_gap_m=None,
            distance_m=dist, dominant_axis=axis,
            position_start=pos_start, position_end=pos_end,
            lines=[("\u2013", f"pickup ({P}) with no setdown ({S}) in this workorder, and no "
                              "following workorder in this file to check against")],
        )

    next_move_type = int(next_workorder.phases[0].move_type)
    gap = _gantry_gap(workorder, next_workorder, config)
    gap_txt = f", gantry gap: {gap:.2f}m" if gap is not None else ""
    axis, dist, pos_start, pos_end = _dominant_axis_and_distance(workorder.rows, config)
    unknown = False

    if next_move_type == P:
        same = gap is not None and gap <= config.thresholds.necessity_tolerance_m
        where = "at the same gantry position" if same else "at a different location"
        lines = [("\u2717", f"pickup ({P}) with no setdown ({S}) in this workorder, and the "
                             f"next workorder ({next_workorder.workorder}) is ALSO a pickup "
                             f"({P}) {where}{gap_txt} \u2014 this pickup "
                             f"achieved nothing")]
    elif rules.pickup_only_rule == "next_is_pickup":
        # Settings: only "picked up again elsewhere" counts as unnecessary.
        unknown = True
        lines = [("\u2013", f"pickup ({P}) with no setdown ({S}) in this workorder; next "
                             f"workorder ({next_workorder.workorder}) is job type {next_move_type} "
                             f"({movetype_name(next_move_type)}), not another pickup \u2014 not judged "
                             f"(rule: unnecessary only when the next job is another pickup){gap_txt}")]
    else:
        lines = [("\u2717", f"pickup ({P}) with no setdown ({S}) in this workorder \u2014 next "
                             f"workorder ({next_workorder.workorder}) is MoveType "
                             f"{next_move_type} ({movetype_name(next_move_type)}), not the "
                             f"expected same-workorder setdown{gap_txt}")]

    return PickupSetdownResult(
        has_pickup=True, has_setdown=False, necessary=False, unknown=unknown,
        next_workorder=next_workorder.workorder, next_move_type=next_move_type,
        gantry_gap_m=gap, distance_m=dist, dominant_axis=axis,
        position_start=pos_start, position_end=pos_end, lines=lines,
    )


# ===========================================================================
# Pickup chains (Settings > Necessity rules: pickups; the default rule)
# ===========================================================================
def _pickup_gantry_position(workorder, config):
    """Gantry actual position where this job picked up: the last row of its
    pickup phase. None if the gantry column isn't in the file."""
    from columns import resolve_axis_column
    P = config.rules.pickup_type
    phase = next((p for p in workorder.phases if p.move_type == P), None)
    rows = phase.rows if phase is not None else workorder.rows
    try:
        col = resolve_axis_column(rows, "gantry", config.columns.actual_candidates["gantry"])
        return float(rows[col].iat[-1])
    except (KeyError, ValueError, TypeError, IndexError):
        return None


def apply_pickup_chains(workorders, ps_results, config):
    """Re-judges pickup jobs as chains: consecutive pickup jobs (idle-only
    jobs ignored) up to a setdown - in the last pickup's own workorder or in
    a separate setdown workorder.

      - Chain ends at a setdown: the unbroken run of pickups at the same gantry
        position as the LAST pickup (within the necessity tolerance) is
        necessary; every earlier pickup is unnecessary.
            300, 400, 400, setdown      -> 300 unnecessary, 400s necessary
            300, 400, 300, setdown      -> only the last 300 is necessary
      - Chain ends at another job type (e.g. a reposition): all unnecessary.
      - Data ends before a setdown: all unknown.

    ps_results: the PickupSetdownWorkorderResult list (edited in place).
    The last pickup of a completed chain closes the Operation report case."""
    rules = config.rules
    P, S = rules.pickup_type, rules.setdown_type
    tol = config.thresholds.necessity_tolerance_m
    # Keyed by id AND start time: the same workorder id can occur twice.
    by_wo = {(r.workorder, r.time_start): r for r in ps_results}
    chain = []

    def fmt(x):
        return f"{x:.1f} m" if x is not None else "unknown position"

    def set_result(wo, necessary, unknown, text, symbol, closes):
        r = by_wo.get((wo.workorder, str(wo.rows["_ts"].iat[0])))
        if r is None:
            return
        p = r.pickup_setdown
        p.necessary, p.unknown = necessary, unknown
        p.lines = [(symbol, text)]
        r.counts_as_waste = (not necessary) and (not unknown or rules.waste_moves == "unnecessary_or_unknown")
        r.closes_case = closes

    def resolve(chain, outcome, closer):
        pos = [_pickup_gantry_position(w, config) for w in chain]
        last = len(chain) - 1
        if outcome == "setdown":
            final = pos[last]
            start = last  # first index of the unbroken same-position run at the end
            while start > 0 and final is not None and pos[start - 1] is not None \
                    and abs(pos[start - 1] - final) <= tol:
                start -= 1
            where = ("in this workorder" if closer is chain[last]
                     else f"in workorder {closer.workorder}")
            for i, w in enumerate(chain):
                if i == last:
                    set_result(w, True, False,
                               f"pickup ({P}) at gantry {fmt(pos[i])}, set down ({S}) {where} "
                               f"— completed", "✓", True)
                elif i >= start:
                    set_result(w, True, False,
                               f"pickup ({P}) at gantry {fmt(pos[i])}: same gantry position as the final "
                               f"pickup (workorder {chain[last].workorder}, {fmt(final)}) before the setdown "
                               f"— necessary", "✓", False)
                else:
                    set_result(w, False, False,
                               f"pickup ({P}) at gantry {fmt(pos[i])}: the container was set down after a "
                               f"later pickup at {fmt(final)} (workorder {chain[last].workorder}), not after "
                               f"this one — this pickup achieved nothing", "✗", False)
        elif outcome == "no_setdown":
            nxt = closer.phases[0].move_type
            for i, w in enumerate(chain):
                set_result(w, False, False,
                           f"pickup ({P}) at gantry {fmt(pos[i])}: the pickups ended without a setdown ({S}) "
                           f"— next job {closer.workorder} is type {nxt} ({movetype_name(nxt)})",
                           "✗", False)
        else:  # data ends
            for i, w in enumerate(chain):
                set_result(w, False, True,
                           f"pickup ({P}) at gantry {fmt(pos[i])}: the data ends before a setdown — "
                           f"not judged", "–", False)

    for w in workorders:
        if not w.phases:
            continue  # idle-only job: not part of the sequence
        types = [p.move_type for p in w.phases]
        first = types[0]
        if first == P:
            chain.append(w)
            if S in types[types.index(P) + 1:]:
                resolve(chain, "setdown", w)
                chain = []
        elif first == S:
            if chain:
                resolve(chain, "setdown", w)
                chain = []
        elif first in rules.idle_types:
            continue
        else:
            if chain:
                resolve(chain, "no_setdown", w)
                chain = []
    if chain:
        resolve(chain, "end", None)
