"""
collector_settings.py
=====================
Shared settings for the Terminal 2 crane collectors.
Edit this file (not the other scripts) when something general changes.
"""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# ── Crane list (the Excel file is the single source of truth) ────────────────
# Every sheet is read. Columns used: "Crane", "Port", "Collector Version".
# Rows whose version is blank or NA are skipped.
CRANE_LIST_FILE = BASE_DIR / "collector_updated_cranes_list.xlsx"

# ── Collector versions: expected UDP packet size in bytes ────────────────────
PACKET_SIZE = {
    "2":   344,   # 86 x 4 bytes
    "2.1": 364,   # 91 x 4 bytes
}

# ── InfluxDB ─────────────────────────────────────────────────────────────────
INFLUX_URL    = "http://192.168.100.218:8089/"
INFLUX_ORG    = "dpw"
INFLUX_BUCKET = "Crane_Telemetry"
INFLUX_TIMEOUT_MS = 5000
# The token is NOT stored in code. Put it in a file called influx_token.txt
# next to these scripts (one line), or set the INFLUX_TOKEN environment variable.
INFLUX_TOKEN_FILE = BASE_DIR / "influx_token.txt"

# ── Network ──────────────────────────────────────────────────────────────────
LISTEN_ADDRESS = "0.0.0.0"
BUFFER_SIZE    = 1024

# ── Folders ──────────────────────────────────────────────────────────────────
LOG_DIR    = BASE_DIR / "logs"
STATUS_DIR = BASE_DIR / "status"
RUN_DIR    = BASE_DIR / "run"

# ── Logging ──────────────────────────────────────────────────────────────────
LOG_EVERY_PACKET   = False          # True = one log line per packet (old behaviour)
SUMMARY_EVERY_SEC  = 60             # one summary line per crane every N seconds
LOG_MAX_BYTES      = 5 * 1024 * 1024
LOG_BACKUP_COUNT   = 5              # keeps at most 6 files x 5 MB per crane

# ── Health thresholds used by the status screen ──────────────────────────────
NO_DATA_AFTER_SEC = 10              # no packet for this long -> "NO DATA"
STALE_AFTER_SEC   = 15              # status file not updated -> "DOWN"
