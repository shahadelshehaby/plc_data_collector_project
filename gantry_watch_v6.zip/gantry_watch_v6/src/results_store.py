"""
results_store.py
=================
The analysis results the analysis tabs show, kept in one small SQLite
database (analyzer_data/results.db), so the tabs can filter and group any
date range or crane instantly, without re-reading the PLC files.

Filled by library.py every time a file is analysed (after an upload or a
NAS sync). Three kinds of rows:

  events   one row per analysed job: a reposition (MoveType 3) or a
           pickup(/setdown) workorder - verdict, time, distance, energy,
           performance, sequence.
  cases    the Operation cases: per crane, events in time order up to and
           including the one that closes the case (operation_agent.py
           rules). Built across files, so a case can continue past
           midnight. Successful cases are included too.
  quality  per file: what in the data itself could make results look wrong
           (repeated seconds, job id blips, gaps, ids that come back).

Each crane is separate: events of one crane never end up in another crane's
case. A case's id is "<crane>|<time of its first event>", so re-analysing a
file updates the same case instead of adding another one.

The full results (speed curves etc.) stay in the per-file cache that the
PDF reports use; this database holds only what the tabs need.
"""
import json
import os
import sqlite3
import threading
import time

from operation_agent import (event_closes_case, event_is_necessary_confirmed, event_is_unknown,
                             event_distance_m)

SCHEMA_VERSION = "1"

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS files (fid TEXT PRIMARY KEY, machine TEXT, name TEXT, key TEXT,
    dates TEXT, stored_at REAL);
CREATE TABLE IF NOT EXISTS events (
    eid TEXT PRIMARY KEY, fid TEXT, machine TEXT, date TEXT, t_start TEXT, t_end TEXT,
    kind TEXT, workorder TEXT, verdict TEXT, closes INTEGER, waste INTEGER,
    duration_s REAL, distance_m REAL, axis TEXT,
    energy_kwh REAL, used_kwh REAL, fed_kwh REAL, wasted_kwh REAL,
    perf TEXT, perf_msg TEXT, expected_s REAL, actual_s REAL, completion REAL, reached_ref INTEGER,
    seq_abnormal INTEGER, seq_minor INTEGER, seq_steps TEXT, flag TEXT,
    reason TEXT, warnings TEXT, has_setdown INTEGER, case_id TEXT);
CREATE INDEX IF NOT EXISTS ev_machine_time ON events (machine, t_start);
CREATE INDEX IF NOT EXISTS ev_fid ON events (fid);
CREATE INDEX IF NOT EXISTS ev_date ON events (date);
CREATE INDEX IF NOT EXISTS ev_case ON events (case_id);
CREATE TABLE IF NOT EXISTS cases (
    case_id TEXT PRIMARY KEY, machine TEXT, date TEXT, t_start TEXT, t_end TEXT,
    n_moves INTEGER, n_unnecessary INTEGER, n_necessary INTEGER, n_unknown INTEGER,
    closed INTEGER, outcome TEXT, duration_s REAL, distance_m REAL,
    energy_kwh REAL, wasted_kwh REAL, wasted_s REAL, workorders TEXT, kinds TEXT);
CREATE INDEX IF NOT EXISTS cs_machine_time ON cases (machine, t_start);
CREATE INDEX IF NOT EXISTS cs_date ON cases (date);
CREATE TABLE IF NOT EXISTS quality (
    fid TEXT PRIMARY KEY, machine TEXT, name TEXT, dates TEXT, date_first TEXT, date_last TEXT,
    rows INTEGER, first TEXT, last TEXT, repeated INTEGER, blip_count INTEGER, blips TEXT,
    gaps INTEGER, gap_seconds INTEGER, longest_gap INTEGER, empty_ids INTEGER, ids_back INTEGER,
    jobs INTEGER, analyzed_at REAL);
"""

# Case outcomes shown in the Cases tab.
OUTCOMES = ("successful", "unnecessary", "open")


def _num(v):
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


def _lines_text(lines):
    """Necessity/pickup explanation lines [(symbol, text), ...] -> one string."""
    out = []
    for item in lines or []:
        text = item[1] if isinstance(item, (list, tuple)) and len(item) > 1 else item
        out.append(str(text))
    return " ".join(out)


def _verdict(e):
    if event_is_unknown(e):
        return "unknown"
    return "necessary" if event_is_necessary_confirmed(e) else "unnecessary"


def _energy(e):
    pw = getattr(e, "power", None)
    if pw is None or not pw.has_any_data:
        return None, None, None
    return pw.total_energy_kwh, getattr(pw, "consumed_kwh", None), getattr(pw, "regenerated_kwh", None)


def event_row(fid, e):
    """One analysed job -> an events row (dict)."""
    is_ps = hasattr(e, "pickup_setdown")
    energy, used, fed = _energy(e)
    waste = e.counts_as_waste if getattr(e, "counts_as_waste", None) is not None else e.is_unnecessary
    row = dict(
        fid=fid, machine=e.machine, date=e.date, t_start=e.time_start, t_end=e.time_end,
        kind="pickup" if is_ps else "reposition", workorder=str(e.workorder), verdict=_verdict(e),
        closes=int(bool(event_closes_case(e))), waste=int(bool(waste)),
        duration_s=_num(e.duration_s), distance_m=_num(event_distance_m(e)),
        energy_kwh=energy, used_kwh=used, fed_kwh=fed, wasted_kwh=_num(e.wasted_energy_kwh),
        perf=None, perf_msg=None, expected_s=None, actual_s=None, completion=None, reached_ref=None,
        seq_abnormal=None, seq_minor=None, seq_steps=None, flag=None, reason=None,
        warnings=json.dumps(list(getattr(e, "workorder_warnings", None) or [])), has_setdown=None,
    )
    if is_ps:
        ps = e.pickup_setdown
        row.update(axis=getattr(ps, "dominant_axis", None), reason=_lines_text(ps.lines),
                   has_setdown=int(bool(ps.has_setdown)))
    else:
        p, s, n = e.performance, e.sequence, e.necessity
        row.update(axis=p.axis, perf=p.verdict, perf_msg=p.message, expected_s=_num(p.expected_time_s),
                   actual_s=_num(p.actual_time_s), completion=_num(p.completion_pct),
                   reached_ref=None if p.reached_reference is None else int(bool(p.reached_reference)),
                   seq_abnormal=int(bool(s.has_abnormal)), seq_minor=int(bool(s.has_minor_waste)),
                   seq_steps=s.step_sequence, flag=e.flag, reason=_lines_text(n.lines))
    row["eid"] = f"{fid}|{row['kind']}|{row['t_start']}|{row['workorder']}"
    return row


EVENT_COLS = ("eid", "fid", "machine", "date", "t_start", "t_end", "kind", "workorder", "verdict", "closes",
              "waste", "duration_s", "distance_m", "axis", "energy_kwh", "used_kwh", "fed_kwh", "wasted_kwh",
              "perf", "perf_msg", "expected_s", "actual_s", "completion", "reached_ref", "seq_abnormal",
              "seq_minor", "seq_steps", "flag", "reason", "warnings", "has_setdown")


class ResultsStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        with self.lock:
            self.db.execute("PRAGMA journal_mode=WAL")
            version = None
            try:
                r = self.db.execute("SELECT v FROM meta WHERE k='schema'").fetchone()
                version = r[0] if r else None
            except sqlite3.DatabaseError:
                pass
            if version not in (None, SCHEMA_VERSION):
                for t in ("meta", "files", "events", "cases", "quality"):
                    self.db.execute(f"DROP TABLE IF EXISTS {t}")
            self.db.executescript(SCHEMA)
            self.db.execute("INSERT OR REPLACE INTO meta VALUES ('schema', ?)", (SCHEMA_VERSION,))
            self.db.commit()
        self.revision = int(time.time() * 1000)  # changes whenever the results change

    def _touch(self):
        self.revision = max(self.revision + 1, int(time.time() * 1000))

    # ---------------------------------------------------------------- writes
    def stored_keys(self):
        with self.lock:
            return {r["fid"]: r["key"] for r in self.db.execute("SELECT fid, key FROM files")}

    def replace_file(self, fid, machine, name, key, results, ps_results, quality=None, dates=()):
        """Stores one analysed file's results (replacing what it had) and
        re-groups that crane's cases from the first changed job onwards."""
        rows = [event_row(fid, e) for e in list(results) + list(ps_results)]
        with self.lock:
            cur = self.db
            old = cur.execute("SELECT MIN(t_start), MAX(machine) FROM events WHERE fid=?", (fid,)).fetchone()
            old_machine = old[1]
            starts = [r["t_start"] for r in rows] + ([old[0]] if old[0] else [])
            cur.execute("DELETE FROM events WHERE fid=?", (fid,))
            cur.executemany(f"INSERT OR REPLACE INTO events ({','.join(EVENT_COLS)}) VALUES "
                            f"({','.join('?' * len(EVENT_COLS))})",
                            [tuple(r.get(c) for c in EVENT_COLS) for r in rows])
            cur.execute("INSERT OR REPLACE INTO files VALUES (?,?,?,?,?,?)",
                        (fid, machine, name, key, json.dumps(sorted(dates)), time.time()))
            if quality is not None:
                self._store_quality(fid, machine, name, dates, quality)
            if starts:
                self._regroup(machine, min(starts))
            if old_machine and old_machine != machine:
                self._regroup(old_machine, old[0])
            cur.commit()
            self._touch()

    def _store_quality(self, fid, machine, name, dates, q):
        dates = sorted(dates)
        blips = q.get("blips") or []
        self.db.execute("INSERT OR REPLACE INTO quality VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
            fid, machine, name, json.dumps(dates), dates[0] if dates else None, dates[-1] if dates else None,
            q.get("rows"), q.get("first"), q.get("last"), q.get("repeated_seconds", 0), len(blips),
            json.dumps(blips[:200]), q.get("gaps", 0), q.get("gap_seconds", 0), q.get("longest_gap_s", 0),
            q.get("empty_ids", 0), q.get("ids_back", 0), q.get("jobs", 0), time.time()))

    def remove_file(self, fid):
        with self.lock:
            r = self.db.execute("SELECT MIN(t_start), MAX(machine) FROM events WHERE fid=?", (fid,)).fetchone()
            for t in ("events", "files", "quality"):
                self.db.execute(f"DELETE FROM {t} WHERE fid=?", (fid,))
            if r[0]:
                self._regroup(r[1], r[0])
            self.db.commit()
            self._touch()

    def rename_machine(self, fids, machine):
        with self.lock:
            olds = set()
            for fid in fids:
                r = self.db.execute("SELECT MAX(machine) FROM events WHERE fid=?", (fid,)).fetchone()
                if r[0]:
                    olds.add(r[0])
                for t in ("events", "files", "quality"):
                    self.db.execute(f"UPDATE {t} SET machine=? WHERE fid=?", (machine, fid))
            for m in olds | {machine}:
                self._regroup(m, "")
            self.db.commit()
            self._touch()

    def _regroup(self, machine, changed_from):
        """Rebuilds the crane's cases from the case that contains the first
        changed job onwards. Earlier cases can't change: they ended at a
        closing job before it."""
        db = self.db
        r = db.execute("SELECT MAX(t_start) FROM events WHERE machine=? AND closes=1 AND t_start<?",
                       (machine, changed_from)).fetchone()
        boundary = r[0]
        if boundary is None:
            db.execute("DELETE FROM cases WHERE machine=?", (machine,))
            events = db.execute("SELECT * FROM events WHERE machine=? ORDER BY t_start, kind DESC", (machine,)).fetchall()
        else:
            db.execute("DELETE FROM cases WHERE machine=? AND t_start>?", (machine, boundary))
            events = db.execute("SELECT * FROM events WHERE machine=? AND t_start>? ORDER BY t_start, kind DESC",
                                (machine, boundary)).fetchall()
        current, cases, links = [], [], []

        def close(evs, closed):
            cid = f"{machine}|{evs[0]['t_start']}"
            n_unnec = sum(1 for e in evs if e["verdict"] == "unnecessary")
            outcome = "unnecessary" if n_unnec else ("successful" if closed else "open")
            cases.append((cid, machine, evs[0]["date"], evs[0]["t_start"], evs[-1]["t_end"], len(evs), n_unnec,
                          sum(1 for e in evs if e["verdict"] == "necessary"),
                          sum(1 for e in evs if e["verdict"] == "unknown"), int(closed), outcome,
                          sum(e["duration_s"] or 0 for e in evs), sum(e["distance_m"] or 0 for e in evs),
                          sum(e["energy_kwh"] or 0 for e in evs), sum(e["wasted_kwh"] or 0 for e in evs),
                          sum(e["duration_s"] or 0 for e in evs if e["waste"]),
                          json.dumps([e["workorder"] for e in evs]), json.dumps([e["kind"] for e in evs])))
            links.extend((cid, e["eid"]) for e in evs)

        for e in events:
            current.append(e)
            if e["closes"]:
                close(current, True)
                current = []
        if current:
            close(current, False)
        db.executemany("INSERT OR REPLACE INTO cases VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", cases)
        db.executemany("UPDATE events SET case_id=? WHERE eid=?", links)

    # ----------------------------------------------------------------- reads
    @staticmethod
    def _where(flt, date_col="date", machine_col="machine"):
        sql, args = [], []
        if flt.get("date_from"):
            sql.append(f"{date_col}>=?")
            args.append(flt["date_from"])
        if flt.get("date_to"):
            sql.append(f"{date_col}<=?")
            args.append(flt["date_to"])
        machines = flt.get("machines")
        if machines is not None:
            if not machines:
                sql.append("0")
            else:
                sql.append(f"{machine_col} IN ({','.join('?' * len(machines))})")
                args.extend(machines)
        return (" AND ".join(sql) or "1"), args

    def _rows(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.db.execute(sql, args).fetchall()]

    def machines_and_dates(self):
        return self._rows("SELECT machine, date, COUNT(*) AS n FROM events GROUP BY machine, date")

    def cases(self, flt, outcome=None, sort="time", desc=True, limit=200, offset=0):
        where, args = self._where(flt)
        totals = self._rows(f"""SELECT outcome, COUNT(*) AS cases, SUM(n_moves) AS moves,
                SUM(n_unnecessary) AS unnecessary, SUM(wasted_s) AS wasted_s, SUM(wasted_kwh) AS wasted_kwh,
                SUM(duration_s) AS duration_s, SUM(distance_m) AS distance_m
                FROM cases WHERE {where} GROUP BY outcome""", args)
        by_machine = self._rows(f"""SELECT machine, COUNT(*) AS cases,
                SUM(outcome='successful') AS successful, SUM(outcome='unnecessary') AS unnecessary_cases,
                SUM(outcome='open') AS open, SUM(n_moves) AS moves, SUM(n_unnecessary) AS unnecessary,
                SUM(wasted_s) AS wasted_s, SUM(wasted_kwh) AS wasted_kwh
                FROM cases WHERE {where} GROUP BY machine ORDER BY machine""", args)
        if outcome in OUTCOMES:
            where += " AND outcome=?"
            args = args + [outcome]
        order = {"time": "t_start", "unnecessary": "n_unnecessary", "moves": "n_moves", "wasted": "wasted_s",
                 "energy": "wasted_kwh", "crane": "machine"}.get(sort, "t_start")
        direction = "DESC" if desc else "ASC"
        n = self._rows(f"SELECT COUNT(*) AS n FROM cases WHERE {where}", args)[0]["n"]
        rows = self._rows(f"SELECT * FROM cases WHERE {where} ORDER BY {order} {direction}, t_start {direction} "
                          f"LIMIT ? OFFSET ?", args + [int(limit), int(offset)])
        for r in rows:
            r["workorders"] = json.loads(r["workorders"] or "[]")
            r["kinds"] = json.loads(r["kinds"] or "[]")
        return {"totals": totals, "by_machine": by_machine, "count": n, "rows": rows}

    def case(self, case_id):
        c = self._rows("SELECT * FROM cases WHERE case_id=?", (case_id,))
        if not c:
            return None
        c = c[0]
        c["workorders"] = json.loads(c["workorders"] or "[]")
        c["kinds"] = json.loads(c["kinds"] or "[]")
        c["events"] = self.events_of_case(case_id)
        # Number of the case within its crane's day (1 = first case that day).
        c["case_num"] = self._rows("SELECT COUNT(*) AS n FROM cases WHERE machine=? AND date=? AND t_start<=?",
                                   (c["machine"], c["date"], c["t_start"]))[0]["n"]
        return c

    def events_of_case(self, case_id):
        rows = self._rows("SELECT * FROM events WHERE case_id=? ORDER BY t_start, kind DESC", (case_id,))
        for r in rows:
            r["warnings"] = json.loads(r["warnings"] or "[]")
        return rows

    def events(self, flt, kind=None, extra="1", extra_args=(), limit=300, offset=0, order="t_start DESC"):
        where, args = self._where(flt)
        if kind:
            where += " AND kind=?"
            args.append(kind)
        where += f" AND ({extra})"
        args.extend(extra_args)
        n = self._rows(f"SELECT COUNT(*) AS n FROM events WHERE {where}", args)[0]["n"]
        rows = self._rows(f"SELECT * FROM events WHERE {where} ORDER BY {order} LIMIT ? OFFSET ?",
                          args + [int(limit), int(offset)])
        for r in rows:
            r["warnings"] = json.loads(r["warnings"] or "[]")
        return n, rows

    def summary(self, flt, select, group_by, kind=None, extra="1"):
        where, args = self._where(flt)
        if kind:
            where += " AND kind=?"
            args.append(kind)
        return self._rows(f"SELECT {group_by} AS grp, {select} FROM events WHERE {where} AND ({extra}) "
                          f"GROUP BY {group_by} ORDER BY {group_by}", args)

    def quality(self, flt):
        where, args = [], []
        if flt.get("date_from"):
            where.append("date_last>=?")
            args.append(flt["date_from"])
        if flt.get("date_to"):
            where.append("date_first<=?")
            args.append(flt["date_to"])
        machines = flt.get("machines")
        if machines is not None:
            where.append(f"machine IN ({','.join('?' * len(machines))})" if machines else "0")
            args.extend(machines or [])
        rows = self._rows(f"SELECT * FROM quality WHERE {' AND '.join(where) or '1'} "
                          f"ORDER BY date_first DESC, machine", args)
        for r in rows:
            r["blips"] = json.loads(r["blips"] or "[]")
            r["dates"] = json.loads(r["dates"] or "[]")
        return rows

    def close(self):
        with self.lock:
            self.db.close()


def open_store(data_dir):
    return ResultsStore(os.path.join(data_dir, "results.db"))
