"""
NAS SYNC — pulls PLC rows from InfluxDB v2 (Synology NAS) into each terminal/type program's PLC store.

What it does, every N minutes (Settings; default 30):
  1. asks InfluxDB for machines it has not seen yet (they appear in the machine table, unmapped);
  2. for every machine that has a PLC type in the machine table, pulls ONLY the rows newer than the last pull
     (re-reading a short overlap so rows the collector delivered late are caught) in small time chunks;
  3. converts the UTC time stored by InfluxDB to Dubai time (the same clock as the fault history's "PLC time");
  4. gives each row the PLC type that applies to that machine AT THAT TIME (a machine can switch from type A to B
     on a date) and merges it into that program's plc_data_store.csv. The existing (machine, timestamp) check
     skips rows already stored, so the overlap never creates duplicates;
  5. optionally runs Evaluation (never Root Cause) for the programs that received new rows.

Read-only: the app only QUERIES InfluxDB. Use a read-only token.
Every error is caught and shown in the Settings tab; nothing here can stop the rest of the app.
"""
from __future__ import annotations

import io
import json
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import pandas as pd

import building_status as bs
import fdd_core as core
from fdd_common import APP_DIR, atomic_write_json, create_program, program_key, read_json, ws_paths

CONFIG_PATH = APP_DIR / "nas_config.json"
STATE_PATH = APP_DIR / "nas_state.json"

DEFAULT_CONFIG = {
    "enabled": True,
    "url": "", "org": "", "bucket": "", "token": "",
    "measurement": "",           # blank = every measurement in the bucket
    "machine_tag": "crane_id",   # the InfluxDB tag that holds the machine (crane) name
    "timezone": "Asia/Dubai",    # InfluxDB stores UTC; rows are converted to this clock
    "interval_minutes": 30,
    "overlap_minutes": 10,       # re-read this much before the last pull so late rows are caught
    "chunk_hours": 6,            # size of each query (the first load is copied chunk by chunk)
    "history_start": "",         # first load starts here (YYYY-MM-DD, Dubai date); blank = 7 days back
    "time_field": "PLCTime",    # the PLC's own time field (local Dubai time). Blank = use InfluxDB's time converted from UTC
    "ts_col": "Timestamp",       # column names used for a program that has none saved yet
    "machine_col": "Machine",
    "auto_evaluate": True,
    "machines": {},              # name -> {"terminal": "" (blank = 2nd character of the name), "timeline": [{"from": "", "type": "A"}]}
}

_cfg_lock = threading.Lock()
_run_lock = threading.Lock()
STATUS = {"running": False, "step": "", "done": 0, "total": 0, "trigger": None,
          "last_attempt": None, "last_ok": None, "last_error": None, "last_result": None}


# ------------------------------------------------------------------ configuration
def load_config() -> dict:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    saved = read_json(CONFIG_PATH, {}) or {}
    cfg.update({k: v for k, v in saved.items() if k in cfg})
    return cfg


def save_config(cfg: dict) -> None:
    with _cfg_lock:
        atomic_write_json(CONFIG_PATH, cfg)


def public_config(cfg: dict) -> dict:
    out = json.loads(json.dumps(cfg))
    out["has_token"] = bool(out.get("token"))
    out["token"] = ""
    return out


def load_state() -> dict:
    st = read_json(STATE_PATH, {}) or {}
    st.setdefault("machines", {})
    return st


def _int(v, default, lo, hi):
    try:
        return max(lo, min(hi, int(float(v))))
    except (TypeError, ValueError):
        return default


def normalize_machines(raw) -> dict:
    out = {}
    for name, spec in (raw or {}).items():
        name = str(name).strip()
        if not name:
            continue
        spec = spec or {}
        tl = []
        for e in spec.get("timeline") or []:
            t = str(e.get("type") or "").strip()
            if t:
                tl.append({"from": str(e.get("from") or "").strip()[:10], "type": t[:30]})
        tl.sort(key=lambda e: e["from"])       # blank dates (= from the start) sort first
        out[name] = {"terminal": str(spec.get("terminal") or "").strip()[:20], "timeline": tl}
    return out


def terminal_of(machine: str, override: str = "") -> str:
    """Terminal = the 2nd character of the machine name (Y2893w58 -> 2), unless a terminal is typed in the table."""
    if override:
        return override
    return machine[1] if len(machine) > 1 and machine[1].isdigit() else "unknown"


def configured(cfg: dict) -> bool:
    return bool(cfg.get("url") and cfg.get("org") and cfg.get("bucket") and cfg.get("token"))


# ------------------------------------------------------------------ InfluxDB (HTTP API, read only)
def _esc(s) -> str:
    return str(s).replace("\\", "\\\\").replace('"', '\\"')


def _rfc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def influx_query(cfg: dict, flux: str, timeout: int = 300) -> pd.DataFrame:
    url = cfg["url"].rstrip("/") + "/api/v2/query?org=" + urllib.parse.quote(cfg["org"])
    req = urllib.request.Request(url, data=flux.encode("utf-8"), method="POST", headers={
        "Authorization": "Token " + cfg["token"], "Content-Type": "application/vnd.flux", "Accept": "application/csv"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            text = r.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        try:
            body = json.loads(body).get("message", body)
        except Exception:  # noqa: BLE001
            pass
        hint = " (check the token and organisation)" if e.code in (401, 403) else ""
        raise RuntimeError(f"InfluxDB answered {e.code}: {str(body)[:300]}{hint}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach InfluxDB at {cfg['url']}: {e.reason}")
    return _parse_csv(text)


def _parse_csv(text: str) -> pd.DataFrame:
    """InfluxDB's annotated CSV may hold several tables, each with its own header, separated by blank lines.
    Every value is read as text first, so a column that is a whole number in one table and a decimal in another
    can never clash; numbers are converted afterwards."""
    frames = []
    for block in text.replace("\r\n", "\n").split("\n\n"):
        lines = [ln for ln in block.split("\n") if ln.strip() and not ln.startswith("#")]
        if len(lines) < 2:
            continue
        frames.append(pd.read_csv(io.StringIO("\n".join(lines)), dtype=str, keep_default_na=False, na_values=[""]))
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]
    return df.drop(columns=[c for c in ("Unnamed: 0", "result", "table") if c in df.columns])


def test_connection(cfg: dict) -> str:
    if not configured(cfg):
        raise RuntimeError("Fill in the URL, organisation, bucket and token first.")
    influx_query(cfg, f'from(bucket: "{_esc(cfg["bucket"])}") |> range(start: -1h) |> limit(n: 1)', timeout=30)
    return "Connected — the token can read this bucket."


def discover_machines(cfg: dict) -> list:
    start = (cfg.get("history_start") or "").strip()
    start_expr = f"{start}T00:00:00Z" if start else "-365d"
    pred = f', predicate: (r) => r._measurement == "{_esc(cfg["measurement"])}"' if cfg.get("measurement") else ""
    flux = ('import "influxdata/influxdb/schema"\n'
            f'schema.tagValues(bucket: "{_esc(cfg["bucket"])}", tag: "{_esc(cfg["machine_tag"])}", start: {start_expr}{pred})')
    df = influx_query(cfg, flux, timeout=60)
    if df.empty or "_value" not in df.columns:
        return []
    return sorted({str(v).strip() for v in df["_value"].dropna() if str(v).strip()})


def _chunk_query(cfg: dict, machine: str, a: datetime, b: datetime, long_format: bool = False) -> str:
    parts = [f'from(bucket: "{_esc(cfg["bucket"])}")', f"|> range(start: {_rfc(a)}, stop: {_rfc(b)})"]
    if cfg.get("measurement"):
        parts.append(f'|> filter(fn: (r) => r._measurement == "{_esc(cfg["measurement"])}")')
    parts += [f'|> filter(fn: (r) => r["{_esc(cfg["machine_tag"])}"] == "{_esc(machine)}")',
              '|> keep(columns: ["_time", "_field", "_value"])']
    if not long_format:
        parts += ['|> map(fn: (r) => ({r with _value: string(v: r._value)}))',
                  "|> group()",
                  '|> pivot(rowKey: ["_time"], columnKey: ["_field"], valueColumn: "_value")',
                  '|> sort(columns: ["_time"])']
    return "\n".join(parts)


def fetch_chunk(cfg: dict, machine: str, a: datetime, b: datetime) -> pd.DataFrame:
    """One machine, one time slice, as a wide table (_time + one column per field)."""
    try:
        return influx_query(cfg, _chunk_query(cfg, machine, a, b))
    except RuntimeError as e:
        if "collision" not in str(e) and "runtime error" not in str(e):
            raise
    # Fallback: ask for the plain list (_time, _field, _value) and pivot it here instead of in InfluxDB.
    long = influx_query(cfg, _chunk_query(cfg, machine, a, b, long_format=True))
    if long.empty or not {"_time", "_field", "_value"} <= set(long.columns):
        return pd.DataFrame()
    wide = long.pivot_table(index="_time", columns="_field", values="_value", aggfunc="last").reset_index()
    wide.columns.name = None
    return wide


# ------------------------------------------------------------------ converting and splitting rows
def _tz(name: str):
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(name)
    except Exception:  # noqa: BLE001  (no tz database on this PC: Dubai has no daylight saving, so +4 h is exact)
        return timezone(timedelta(hours=4)) if name in ("Asia/Dubai", "", None) else timezone.utc


def _numeric(col: pd.Series) -> pd.Series:
    """Text -> numbers where the whole column is numeric (true/false become 1/0); real text (ContainerID) is kept."""
    if pd.api.types.is_bool_dtype(col):
        return col.astype(int)
    if pd.api.types.is_numeric_dtype(col):
        return col
    mapped = col.replace({"true": 1, "false": 0, "True": 1, "False": 0})
    conv = pd.to_numeric(mapped, errors="coerce")
    return conv if conv.notna().sum() >= col.notna().sum() else col


def parse_plc_times(s: pd.Series) -> pd.Series:
    """Reads the PLC's own time text. Each value is read on its own, so a mix such as
    '2026-10-09 04:28:05' and '2026-10-09 04:28:05.250' (or a trailing Z) never breaks the whole batch."""
    s = s.astype(str).str.strip()
    best = None
    for kw in ({"format": "ISO8601"}, {"format": "mixed"}, {"format": "mixed", "dayfirst": True}):
        try:
            p = pd.to_datetime(s, errors="coerce", **kw)
        except Exception:  # noqa: BLE001
            continue
        if getattr(p.dt, "tz", None) is not None:
            p = p.dt.tz_localize(None)
        if best is None or p.notna().sum() > best.notna().sum():
            best = p
        if best.notna().mean() > 0.999:
            break
    return best if best is not None else pd.Series(pd.NaT, index=s.index)


def prepare_rows(df: pd.DataFrame, tz) -> tuple:
    """Returns (rows with a local 'ts' column + field columns, newest UTC time pulled)."""
    t = pd.to_datetime(df["_time"], utc=True, format="ISO8601")   # with or without fractional seconds, row by row
    out = df.drop(columns=["_time"]).apply(_numeric)
    out.insert(0, "ts", t.dt.tz_convert(tz).dt.tz_localize(None).dt.floor("ms"))
    return out, t.max().to_pydatetime()


def types_for(ts: pd.Series, timeline: list) -> pd.Series:
    """The PLC type that applies at each time. The first entry applies from the start of the data; each later
    entry applies from its date (Dubai date, midnight) onward."""
    types = pd.Series(timeline[0]["type"], index=ts.index, dtype=object)
    for e in timeline[1:]:
        if e["from"]:
            types[ts >= pd.Timestamp(e["from"])] = e["type"]
    return types


# ------------------------------------------------------------------ one sync
def _merge_with_retry(path, frame, ts_col, machine_col):
    last = None
    for _ in range(4):           # Windows sometimes holds the file for a moment (antivirus, another program)
        try:
            return core.merge_plc_store(path, frame, ts_col, machine_col)
        except OSError as e:
            last = e
            time.sleep(2)
    raise last


def sync_once(cfg: dict, host: dict, only=None) -> dict:
    t0 = datetime.now(timezone.utc)
    tz = _tz(cfg.get("timezone") or "Asia/Dubai")
    result = {"started": t0.isoformat(timespec="seconds"), "machines": {}, "unmapped": [], "errors": [],
              "added_total": 0, "programs_updated": [], "evaluation": None}

    # 1) new machines show up in the machine table
    try:
        known = cfg["machines"]
        new = [m for m in discover_machines(cfg) if m not in known]
        for m in new:
            known[m] = {"terminal": "", "timeline": []}
        if new:
            save_config(cfg)
        result["new_machines"] = new
    except Exception as e:  # noqa: BLE001
        result["errors"].append(f"Looking for machines: {e}")

    mapped = sorted(m for m, s in cfg["machines"].items() if s.get("timeline") and (not only or m in only))
    result["unmapped"] = sorted(m for m, s in cfg["machines"].items() if not s.get("timeline"))
    state = load_state()
    overlap = timedelta(minutes=_int(cfg["overlap_minutes"], 10, 0, 1440))
    chunk = timedelta(hours=_int(cfg["chunk_hours"], 6, 1, 168))
    hs = (cfg.get("history_start") or "").strip()
    try:
        first_start = (datetime.fromisoformat(hs).replace(tzinfo=tz).astimezone(timezone.utc) if hs
                       else t0 - timedelta(days=7))
    except ValueError:
        first_start = t0 - timedelta(days=7)
    updated = set()
    STATUS["total"], STATUS["done"] = len(mapped), 0

    with bs.job("Syncing PLC data from the NAS", total=len(mapped), process="nas_sync") as job:
        for n, machine in enumerate(mapped, 1):
            STATUS["step"] = f"{machine} ({n}/{len(mapped)})"
            job.progress(done=n - 1, step=f"NAS sync: {machine}")
            info = {"pulled": 0, "added": 0, "skipped": 0, "error": None}
            result["machines"][machine] = info
            try:
                spec = cfg["machines"][machine]
                timeline = spec["timeline"]
                terminal = terminal_of(machine, spec.get("terminal", ""))
                keys = {}                        # type -> program key (created the first time it is needed)
                for ty in {e["type"] for e in timeline}:
                    p, _ = create_program(terminal, ty)
                    keys[ty] = p["key"]
                cur = state["machines"].get(machine, {}).get("cursor")
                start = (datetime.fromisoformat(cur) - overlap) if cur else first_start
                start = start.replace(microsecond=0)
                a, pending, newest = start, [], None
                while a < t0:
                    b = min(a + chunk, t0)
                    if (b - a) < timedelta(milliseconds=5):      # nothing left to ask for
                        break
                    df = fetch_chunk(cfg, machine, a, b)
                    if not df.empty and "_time" in df.columns:
                        rows, mx = prepare_rows(df, tz)
                        pending.append(rows)
                        newest = mx if newest is None else max(newest, mx)
                        info["pulled"] += len(rows)
                    a = b
                    big = sum(len(p) for p in pending) >= 300_000
                    if pending and (big or a >= t0):
                        _flush(cfg, host, machine, terminal, timeline, keys, pd.concat(pending, ignore_index=True), info, updated)
                        pending = []
                        state["machines"][machine] = {"cursor": newest.isoformat(), "updated": _rfc(datetime.now(timezone.utc))}
                        atomic_write_json(STATE_PATH, state)
                if info["pulled"] == 0:
                    info["note"] = ("no new data (the machine has not worked since the last sync)" if cur
                                    else "no data in the period asked for — set an earlier 'first load from' date "
                                         "under More options if this machine worked longer ago")
                if newest is None and cur is None:
                    state["machines"].setdefault(machine, {"cursor": None})
                result["added_total"] += info["added"]
            except Exception as e:  # noqa: BLE001
                traceback.print_exc()
                info["error"] = str(e)
                result["errors"].append(f"{machine}: {e}")
            job.progress(done=n)

    result["programs_updated"] = sorted(updated)
    result["finished"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    return result


def _flush(cfg, host, machine, terminal, timeline, keys, rows, info, updated):
    tys = types_for(rows["ts"], timeline)
    for ty, key in keys.items():
        part = rows[tys == ty]
        if part.empty:
            continue
        ts_col, machine_col = host["program_cols"](key) or (None, None)
        ts_col, machine_col = ts_col or cfg["ts_col"], machine_col or cfg["machine_col"]
        frame = part.copy()
        # The PLC's own clock (e.g. a PLCTime field) can be used instead of InfluxDB's time. It is also used
        # automatically when this program's saved time column has the same name as a field.
        tf = (cfg.get("time_field") or "").strip() or (ts_col if ts_col in frame.columns else "")
        if tf and tf in frame.columns:
            parsed = parse_plc_times(frame[tf])
            if parsed.notna().sum() == 0:
                raise ValueError(f"The time field “{tf}” could not be read as dates.")
            frame["ts"] = parsed.dt.floor("ms")
            frame = frame.drop(columns=[tf]).dropna(subset=["ts"])
        frame = frame.rename(columns={"ts": ts_col}).reset_index(drop=True)
        frame.insert(1, machine_col, machine)
        ws_paths(key).dir.mkdir(parents=True, exist_ok=True)
        with host["lock"]:
            r = _merge_with_retry(ws_paths(key).plc_store, frame, ts_col, machine_col)
        info["added"] += r["added"]
        info["skipped"] += r["skipped_duplicates"]
        if r["added"]:
            updated.add(key)


def run_sync(host: dict, trigger: str = "manual", only=None) -> dict:
    """Runs one full sync (and the Evaluation that follows). Safe to call from any thread; never raises."""
    if not _run_lock.acquire(blocking=False):
        return {"busy": True}
    try:
        cfg = load_config()
        STATUS.update(running=True, trigger=trigger, step="Starting", done=0, total=0, last_error=None,
                      last_attempt=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        if not configured(cfg):
            raise RuntimeError("NAS settings are incomplete (URL, organisation, bucket, token).")
        result = sync_once(cfg, host, only)
        if result["programs_updated"]:
            host["mark_stale"](result["programs_updated"])
            if cfg.get("auto_evaluate"):
                STATUS["step"] = "Running Evaluation"
                try:
                    summary = host["evaluate"](result["programs_updated"])
                    ok = [s for s in summary if not s.get("error")]
                    result["evaluation"] = {"faults": len(ok), "skipped": [f"{s.get('program_label', '')}: {s['error']}" for s in summary if s.get("error")]}
                except Exception as e:  # noqa: BLE001
                    traceback.print_exc()
                    result["errors"].append(f"Evaluation after sync: {e}")
        STATUS["last_result"] = result
        if result["errors"]:
            STATUS["last_error"] = "; ".join(result["errors"])[:600]
            bs.record_error("NAS sync: " + STATUS["last_error"])
        else:
            STATUS["last_ok"] = result["finished"]
        return result
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        STATUS["last_error"] = str(e)
        bs.record_error(f"NAS sync: {e}")
        return {"error": str(e)}
    finally:
        STATUS.update(running=False, step="")
        _run_lock.release()


# ------------------------------------------------------------------ scheduler (starts with the app)
def next_due(cfg: dict):
    if not (cfg.get("enabled") and configured(cfg)):
        return None
    la = STATUS.get("last_attempt")
    if not la:
        return datetime.now(timezone.utc) + timedelta(seconds=15)
    return datetime.fromisoformat(la) + timedelta(minutes=_int(cfg["interval_minutes"], 30, 1, 1440))


def start_scheduler(host: dict) -> None:
    def loop():
        time.sleep(15)
        while True:
            try:
                cfg = load_config()
                due = next_due(cfg)
                if due and datetime.now(timezone.utc) >= due and not STATUS["running"]:
                    run_sync(host, "scheduled")
            except Exception:  # noqa: BLE001
                traceback.print_exc()
            time.sleep(10)
    threading.Thread(target=loop, name="nas-sync", daemon=True).start()


# ------------------------------------------------------------------ web API
def register(app, host: dict) -> None:
    from flask import jsonify, request

    def payload():
        cfg = load_config()
        st = load_state()
        due = next_due(cfg)
        machines = []
        for name in sorted(cfg["machines"]):
            spec = cfg["machines"][name]
            cur = st["machines"].get(name, {}).get("cursor")
            local = None
            if cur:
                local = str(pd.Timestamp(cur).tz_convert(_tz(cfg["timezone"])).tz_localize(None))[:19]
            machines.append({"name": name, "terminal": spec.get("terminal", ""), "terminal_auto": terminal_of(name),
                             "timeline": spec.get("timeline", []), "last_row": local})
        status = dict(STATUS, next_due=due.isoformat(timespec="seconds") if due else None)
        return {"ok": True, "config": public_config(cfg), "machines": machines, "status": status}

    @app.route("/api/nas/config", methods=["GET"])
    def nas_get():
        return jsonify(payload())

    @app.route("/api/nas/config", methods=["POST"])
    def nas_save():
        b = request.get_json(force=True) or {}
        cfg = load_config()
        for k in ("url", "org", "bucket", "measurement", "machine_tag", "timezone", "history_start", "ts_col", "machine_col", "time_field"):
            if k in b:
                cfg[k] = str(b[k] or "").strip()
        if b.get("token"):
            cfg["token"] = str(b["token"]).strip()
        for k in ("enabled", "auto_evaluate"):
            if k in b:
                cfg[k] = bool(b[k])
        cfg["interval_minutes"] = _int(b.get("interval_minutes", cfg["interval_minutes"]), 30, 1, 1440)
        cfg["overlap_minutes"] = _int(b.get("overlap_minutes", cfg["overlap_minutes"]), 10, 0, 1440)
        cfg["chunk_hours"] = _int(b.get("chunk_hours", cfg["chunk_hours"]), 6, 1, 168)
        if "machines" in b:
            cfg["machines"] = normalize_machines(b["machines"])
        try:
            _tz(cfg["timezone"])
            if cfg["history_start"]:
                datetime.fromisoformat(cfg["history_start"])
        except ValueError:
            return jsonify(ok=False, error="'First load from' must be a date like 2026-09-01."), 400
        save_config(cfg)
        return jsonify(payload())

    def _cfg_from_body():
        b = request.get_json(silent=True) or {}
        cfg = load_config()
        for k in ("url", "org", "bucket", "measurement", "machine_tag"):
            if b.get(k) is not None:
                cfg[k] = str(b[k]).strip()
        if b.get("token"):
            cfg["token"] = str(b["token"]).strip()
        return cfg

    @app.route("/api/nas/test", methods=["POST"])
    def nas_test():
        try:
            return jsonify(ok=True, message=test_connection(_cfg_from_body()))
        except Exception as e:  # noqa: BLE001
            return jsonify(ok=False, error=str(e))

    @app.route("/api/nas/discover", methods=["POST"])
    def nas_discover():
        try:
            cfg = load_config()
            found = discover_machines(_cfg_from_body())
            added = [m for m in found if m not in cfg["machines"]]
            for m in added:
                cfg["machines"][m] = {"terminal": "", "timeline": []}
            if added:
                save_config(cfg)
            out = payload()
            out["found"], out["added"] = len(found), len(added)
            return jsonify(out)
        except Exception as e:  # noqa: BLE001
            return jsonify(ok=False, error=str(e))

    @app.route("/api/nas/sync", methods=["POST"])
    def nas_sync_now():
        if STATUS["running"]:
            return jsonify(ok=False, error="A sync is already running.")
        threading.Thread(target=run_sync, args=(host, "manual"), daemon=True).start()
        return jsonify(ok=True)

    @app.route("/api/nas/resync", methods=["POST"])
    def nas_resync():
        """Copy the chosen machines' data from the NAS again — from a date, or from the first-load date.
        Rows already stored are skipped, so nothing is duplicated."""
        b = request.get_json(silent=True) or {}
        cfg = load_config()
        names = [m for m in (b.get("machines") or []) if m in cfg["machines"] and cfg["machines"][m].get("timeline")]
        if not names:
            return jsonify(ok=False, error="Choose at least one machine that has a PLC type.")
        if STATUS["running"]:
            return jsonify(ok=False, error="A sync is already running.")
        since = str(b.get("since") or "").strip()
        st = load_state()
        try:
            for m in names:
                if since:
                    start = datetime.fromisoformat(since).replace(tzinfo=_tz(cfg["timezone"])).astimezone(timezone.utc)
                    st["machines"][m] = {"cursor": (start + timedelta(minutes=_int(cfg["overlap_minutes"], 10, 0, 1440))).isoformat()}
                else:
                    st["machines"].pop(m, None)
        except ValueError:
            return jsonify(ok=False, error="The date must look like 2026-10-01.")
        atomic_write_json(STATE_PATH, st)
        threading.Thread(target=run_sync, args=(host, "manual", set(names)), daemon=True).start()
        return jsonify(ok=True)

    @app.route("/api/nas/reset", methods=["POST"])
    def nas_reset():
        """Forget where a machine was up to, so the next sync copies its history again (stored rows are not duplicated)."""
        m = (request.get_json(silent=True) or {}).get("machine")
        st = load_state()
        st["machines"].pop(m, None)
        atomic_write_json(STATE_PATH, st)
        return jsonify(payload())
