"""Shared helpers for the FDD Root Cause program (standalone project).

THIS PROGRAM ONLY READS the Evaluation program's files. It never writes into the Evaluation folder.

Where things live
  Evaluation project folder (read only)         set in  rootcause_config.json  ->  "evaluation_dir"
      programs.json                             the terminal / type programs
      programs/<key>/fdd_settings.json          rule logic + column mapping
      programs/<key>/plc_data_store.csv         PLC rows (filled from the NAS or from uploads)
      programs/<key>/handoff/                   what Evaluate saved: matched events, predicted intervals, manifest.json
  This project folder (written by this program)
      rootcause_data/<key>/rootcause_state.json pattern groups, the engineer's names / labels, conversions
      rootcause_config.json                     where the Evaluation folder is
      activity/                                 job log read by /building/status
"""
from __future__ import annotations
import sys
if sys.version_info < (3, 9):
    print("This tool needs Python 3.9 or newer. Download it from https://python.org/downloads")
    input("Press Enter to close...")
    sys.exit(1)

import hashlib
import json
import os
import re
import shutil
import threading
import webbrowser
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from fdd_theme import THEME_CSS

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "rootcause_config.json"
DATA_DIR = APP_DIR / "rootcause_data"
PORT_ROOT_CAUSE = 5001   # NOT 5000/5002/5050: those belong to other platforms in the building
RC_KEYS = ("clusters", "event_cluster_map", "event_overrides")


# ---------------------------------------------------------------- files
def atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def atomic_write_json(path: Path, obj) -> None:
    atomic_write_text(path, json.dumps(obj, indent=2, default=str))


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return default


# ---------------------------------------------------------------- where the Evaluation program's data is
def eval_dir() -> Path:
    """Folder of the Evaluation project: environment variable FDD_EVAL_DIR, else rootcause_config.json,
    else a folder called fdd_app next to this one."""
    p = os.environ.get("FDD_EVAL_DIR") or (read_json(CONFIG_PATH, {}) or {}).get("evaluation_dir")
    return Path(p).expanduser() if p else APP_DIR.parent / "fdd_app"


def ensure_config() -> None:
    if not CONFIG_PATH.exists():
        atomic_write_json(CONFIG_PATH, {"evaluation_dir": str(APP_DIR.parent / "fdd_app")})


def load_registry() -> dict:
    """The Evaluation program's list of terminal / type programs (read only)."""
    reg = read_json(eval_dir() / "programs.json", None)
    if not isinstance(reg, dict):
        return {"programs": []}
    reg.setdefault("programs", [])
    return reg


def program_label(p: dict) -> str:
    return f"Terminal {p['terminal']} · Type {p['type']}"


def ws_paths(key: str) -> SimpleNamespace:
    d = eval_dir() / "programs" / key
    return SimpleNamespace(dir=d, settings=d / "fdd_settings.json", plc_store=d / "plc_data_store.csv",
                           handoff=d / "handoff", manifest=d / "handoff" / "manifest.json",
                           rc_state=DATA_DIR / key / "rootcause_state.json")


# ---------------------------------------------------------------- small helpers
def fault_slug(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")[:50] or "fault"
    return f"{base}_{hashlib.md5(name.encode('utf-8')).hexdigest()[:6]}"


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return x


def rule_hash(versions_raw, bypasses=None) -> str:
    """Fingerprint of a fault's rule logic (must match the Evaluation program's). Compared with the one saved at
    Evaluate time to warn that the logic changed since. The ranges of any bypass a
    condition uses are part of the fingerprint, so editing a bypass also counts as a logic change."""
    def one(c):
        joiner = c.get("joiner") if c.get("joiner") == "OR" else "AND"
        if c.get("type") == "group":                    # sub-logic (brackets): fingerprint its contents too
            return {"type": "group", "joiner": joiner, "mode": c.get("mode") or "none",
                    "mode_value": _num(c.get("mode_value") or 0),
                    "conditions": [one(x) for x in c.get("conditions") or []]}
        d = {"column": c.get("column"), "op": c.get("op"), "value": _num(c.get("value")),
             "joiner": joiner, "mode": c.get("mode") or "none", "mode_value": _num(c.get("mode_value") or 0)}
        if c.get("op") in ("in", "not_in"):            # a bypass's ranges are part of the logic too
            bp = (bypasses or {}).get(c.get("bypass")) or {}
            d["bypass"] = {"id": c.get("bypass"), "versions": sorted(
                [{"effective_from": bv.get("effective_from") or None,
                  "ranges": [[_num(r.get("from")), _num(r.get("to"))] for r in bv.get("ranges") or []]}
                 for bv in bp.get("versions") or []],
                key=lambda x: x["effective_from"] or "")}
        return d

    norm = []
    for v in versions_raw or []:
        norm.append({"effective_from": v.get("effective_from") or None,
                     "conditions": [one(c) for c in v.get("conditions", [])]})
    norm.sort(key=lambda v: v["effective_from"] or "")
    return hashlib.md5(json.dumps(norm, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:12]


def normalize_feature_specs(cols):
    out = []
    for c in cols or []:
        if isinstance(c, str):
            out.append({"column": c, "tolerance": 0, "role": "diagnostic"})
        else:
            d = dict(c)
            d.setdefault("role", "diagnostic")
            out.append(d)
    return out


# ---------------------------------------------------------------- root-cause state (this program's own file, per program)
def _fix_cluster(cl: dict) -> dict:
    if "description_versions" in cl:
        versions = cl.pop("description_versions")
        cl["description"] = versions[-1]["description"] if versions else ""
    cl.setdefault("description", "")
    return cl


def rc_state_load(key: str) -> dict:
    """Loads this program's rootcause_state.json. The first time, it imports whatever the combined version of the
    platform saved before the split — pattern groups and labels in the Evaluation folder's
    programs/<key>/rootcause_state.json (or, older still, inside fdd_settings.json) — so nothing already taught is lost."""
    p = ws_paths(key)
    st = read_json(p.rc_state, None)
    if st is None:
        st = read_json(p.dir / "rootcause_state.json", None)
        if st is None:
            st = {"faults": {}}
            old = read_json(p.settings, {}) or {}
            for fault, spec in (old.get("rules") or {}).items():
                moved = {k: spec[k] for k in RC_KEYS if k in spec}
                if moved:
                    moved["clusters"] = [_fix_cluster(c) for c in moved.get("clusters", [])]
                    st["faults"][fault] = moved
        atomic_write_json(p.rc_state, st)
    st.setdefault("faults", {})
    return st


def rc_state_save(key: str, st: dict) -> None:
    atomic_write_json(ws_paths(key).rc_state, st)


# ---------------------------------------------------------------- read what Evaluate saved
def read_manifest(key: str) -> dict:
    return read_json(ws_paths(key).manifest, None) or {}


def read_handoff(key: str, slug: str):
    p = ws_paths(key)
    m = pd.read_csv(p.handoff / f"{slug}.matched.csv")
    iv = pd.read_csv(p.handoff / f"{slug}.intervals.csv")
    for c in ("coming", "going"):
        if c in m.columns:
            m[c] = pd.to_datetime(m[c], errors="coerce")
    for c in ("start", "end"):
        if c in iv.columns:
            iv[c] = pd.to_datetime(iv[c], errors="coerce")
    if "machine" in m.columns:
        m["machine"] = m["machine"].astype(str).str.strip()
    return m, iv.reset_index(drop=True)


# ---------------------------------------------------------------- flask helpers (page, logo)
LOGO_JS = r"""
(function(){
  const img = document.getElementById('logoImg'), add = document.getElementById('logoAdd'),
        file = document.getElementById('logoFile'), wrap = document.getElementById('logoWrap');
  function show(has){ img.hidden = !has; add.hidden = has; wrap.classList.toggle('has-logo', has); }
  img.addEventListener('load', ()=>show(true));
  img.addEventListener('error', ()=>show(false));
  if(img.complete) show(img.naturalWidth > 0);
  add.addEventListener('click', ()=>file.click());
  img.title = 'Double-click to change the logo';
  img.addEventListener('dblclick', ()=>file.click());
  file.addEventListener('change', async ()=>{
    if(!file.files.length) return;
    const fd = new FormData(); fd.append('logo', file.files[0]);
    let r; try{ r = await (await fetch('/api/logo', {method:'POST', body:fd})).json(); } catch(e){ r = {ok:false, error:e.message}; }
    if(r.ok){ const u = '/logo?'+Date.now(); img.src = u; document.querySelectorAll('link[rel=icon]').forEach(l=>l.href = u); }
    else alert(r.error || 'Could not save the logo.');
    file.value = '';
  });
})();
"""


def serve_page(html: str):
    from flask import Response
    return Response(html.replace("/*THEME*/", THEME_CSS).replace("/*LOGOJS*/", LOGO_JS), mimetype="text/html")


def register_logo(app) -> None:
    """GET /logo serves static/logo.(svg|png|jpg|webp); POST /api/logo saves a new one (the 'Add logo' button)."""
    from flask import jsonify, request, send_file

    @app.route("/logo")
    def logo():
        for name in ("logo.svg", "logo.png", "logo.jpg", "logo.jpeg", "logo.webp"):
            p = APP_DIR / "static" / name
            if p.exists():
                r = send_file(p)
                r.headers["Cache-Control"] = "no-cache"
                r.headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox"
                return r
        return ("", 404)

    @app.route("/api/logo", methods=["POST"])
    def upload_logo():
        f = request.files.get("logo")
        if not f or not f.filename:
            return jsonify(ok=False, error="No file received."), 400
        ext = Path(f.filename).suffix.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".svg", ".webp"):
            return jsonify(ok=False, error="Please choose a .png, .jpg, .svg or .webp file."), 400
        data = f.read()
        if len(data) > 2 * 1024 * 1024:
            return jsonify(ok=False, error="That logo is larger than 2 MB."), 400
        d = APP_DIR / "static"
        d.mkdir(exist_ok=True)
        for old in d.glob("logo.*"):
            try:
                old.unlink()
            except OSError:
                pass
        (d / f"logo{ext}").write_bytes(data)
        return jsonify(ok=True)


def run_server(app, port: int, title: str) -> None:
    if "--no-browser" not in sys.argv:
        threading.Timer(1.3, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(f"Starting {title} -> http://127.0.0.1:{port}")
    print(f"Reading the Evaluation data from: {eval_dir()}")
    print("To stop it, close this window or press Ctrl+C.")
    app.run(host="127.0.0.1", port=port, debug=False)
