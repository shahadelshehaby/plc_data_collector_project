"""
data_loader.py
===============
Loads one PLC CSV (one machine, one day) and reconstructs workorders/phases.

Timestamp gotcha (see project reference doc, Section 2.2):
PLCTime looks like "2026-06-18-19:41:12" - hyphens throughout, no space/'T'.
Parse with format="%Y-%m-%d-%H:%M:%S". To grab just the time portion for
display, use rsplit("-", 1)[-1] (splits on the LAST hyphen only) - a naive
split(" ") does nothing useful here.
"""
from dataclasses import dataclass, field
from typing import List, Optional
import pandas as pd

from influx_clean import looks_like_influx, read_raw_file, normalize_plctime
from rules import DEFAULT_RULES

# Internal names the agents use. The real column names come from the rules
# (Settings > Job types and columns) and are renamed to these on load.
JOB_ID, JOB_TYPE, STEP = "WorkorderIdent", "MoveType", "Step"


TIME_FORMAT = "%Y-%m-%d-%H:%M:%S"


def time_only(plctime_str: str) -> str:
    return plctime_str.rsplit("-", 1)[-1]


def date_only(plctime_str: str) -> str:
    return plctime_str.rsplit("-", 1)[0]


@dataclass
class Phase:
    workorder: int
    phase_num: int
    move_type: int
    rows: pd.DataFrame  # rows belonging to this phase (MoveType == move_type)


@dataclass
class Workorder:
    workorder: int
    rows: pd.DataFrame
    phases: List[Phase] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def _peek_rows(path, n=5):
    if path.lower().endswith((".xlsx", ".xls")):
        return pd.read_excel(path, header=None, nrows=n, dtype=object).values.tolist()
    import csv
    with open(path, newline="", encoding="utf-8-sig") as f:
        return [row for _, row in zip(range(n), csv.reader(f))]


def _apply_column_names(df, rules):
    for internal, configured, label in ((JOB_ID, rules.col_job_id, "Job id"),
                                        (JOB_TYPE, rules.col_job_type, "Job type"),
                                        (STEP, rules.col_step, "Step")):
        if configured == internal:
            continue
        if configured not in df.columns:
            raise ValueError(f"Column '{configured}' (the {label.lower()} column set under Settings > Job types "
                             f"and columns) is not in this file.")
        if internal in df.columns:
            df = df.drop(columns=[internal])
        df = df.rename(columns={configured: internal})
    return df


def load_plc_csv(path: str, rules=None, keep_repeats=False, info=None) -> pd.DataFrame:
    """Loads a PLC file (.csv or .xlsx/.xls), drops any manually-added
    'remark' column, de-duplicates repeated column names, and parses time.

    Raw InfluxDB exports are cleaned automatically (annotation rows and the
    result/table columns removed - see influx_clean.py), so they can be
    uploaded exactly as downloaded."""
    peek = _peek_rows(path)
    if peek and looks_like_influx(peek[0], peek[1:]):
        df = read_raw_file(path)
    elif path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path, low_memory=False)

    # Defensive: if the source file has a column name repeated (e.g. PLCTime
    # listed twice in the export), pandas renames the second one PLCTime.1 -
    # drop those duplicates and keep the first occurrence of each name.
    if df.columns.duplicated().any():
        dup_names = df.columns[df.columns.duplicated()].tolist()
        df = df.loc[:, ~df.columns.duplicated()]
        print(f"    WARNING: duplicate column name(s) found and dropped (kept first "
              f"occurrence): {dup_names}")

    if "remark" in df.columns:
        df = df.drop(columns=["remark"])
    df = _apply_column_names(df, rules or DEFAULT_RULES)
    try:
        df["_ts"] = pd.to_datetime(df["PLCTime"], format=TIME_FORMAT)
        if df["_ts"].isna().any():
            raise ValueError("PLCTime blank in places")
    except (KeyError, ValueError, TypeError):
        # PLCTime missing, blank in places, or in another format: rebuild it
        # (from InfluxDB's _time, converted to local time, where needed).
        df = normalize_plctime(df)
        df["_ts"] = pd.to_datetime(df["PLCTime"], format=TIME_FORMAT)
    # Stable sort: rows with the same timestamp keep their original order.
    df = df.sort_values("_ts", kind="mergesort").reset_index(drop=True)
    # The same PLC second more than once (exact repeats, e.g. the same NAS
    # chunk stored twice, or two readings of one second): keep the first.
    repeated = df["_ts"].duplicated()
    if info is not None:
        info["repeated_seconds"] = int(repeated.sum())
    if not keep_repeats:
        if repeated.any():
            df = df[~repeated].reset_index(drop=True)
    # One memory block per column type: makes every later slice much faster.
    return df.copy()


def _absorb_id_blips(df, rules):
    """A job id that changes for a few seconds and comes back (339, 2342, 339)
    is a glitch, not a job: those rows get the surrounding job's id, job type
    and step. Returns a list of (blip id, seconds, timestamp, PLCTime) absorbed."""
    limit = getattr(rules, "job_id_blip_seconds", 0) or 0
    if limit <= 0 or df.empty:
        return []
    ids = df[JOB_ID].astype(object).where(df[JOB_ID].notna(), "missing")
    absorbed = []
    for _ in range(5):  # a blip inside a blip
        run_no = (ids != ids.shift()).cumsum().to_numpy()
        starts = [0] + [i for i in range(1, len(run_no)) if run_no[i] != run_no[i - 1]]
        ends = starts[1:] + [len(run_no)]
        ts = df["_ts"]
        changed = False
        for k in range(1, len(starts) - 1):
            a, b = starts[k], ends[k]
            prev_id, this_id, next_id = ids.iat[starts[k - 1]], ids.iat[a], ids.iat[ends[k]]
            if prev_id != next_id or this_id == prev_id:
                continue
            secs = (ts.iat[b] - ts.iat[a - 1]).total_seconds() - 1  # time the id was different
            if secs > limit:
                continue
            absorbed.append((this_id, int(secs), ts.iat[a], str(df["PLCTime"].iat[a])))
            idx = df.index[a:b]
            ids.iloc[a:b] = prev_id
            df.loc[idx, JOB_ID] = df[JOB_ID].iat[a - 1]
            for col in (JOB_TYPE, STEP):
                if col in df.columns:
                    df.loc[idx, col] = df[col].iat[a - 1]
            changed = True
        if not changed:
            break
    return absorbed


def _job_id(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return str(value)


def split_workorders(df: pd.DataFrame, rules=None, info=None) -> List[Workorder]:
    """Splits one machine's rows (already in PLC-time order) into jobs.

    A job is an unbroken run of rows with the same job id (WorkorderIdent),
    in time order - NOT every row in the file with that id. Workorder ids can
    repeat (on another day, or when the PLC reuses ids), and grouping a whole
    file by id used to merge jobs hours or days apart into one "move" and put
    jobs in the wrong order, so the "next job" used for necessity was wrong.

    Stretches made only of idle rows (Settings > idle job types) are not jobs:
    they never become anyone's "next job". When the same id continues right
    after such an idle stretch, it is still one job."""
    rules = rules or DEFAULT_RULES
    if df.empty:
        return []
    blips = _absorb_id_blips(df, rules)
    if info is not None:
        info["blips"] = [{"id": str(_job_id(b)), "seconds": max(secs, 1), "time": at}
                         for b, secs, _, at in blips]
    ids = df[JOB_ID].astype(object).where(df[JOB_ID].notna(), "missing")
    run_no = (ids != ids.shift()).cumsum()
    idle = df[JOB_TYPE].isin(rules.idle_types)

    jobs = []  # [job id, [row blocks]]
    for _, block in df.groupby(run_no, sort=True):
        if idle.loc[block.index].all():
            continue  # idle-only stretch between jobs
        wo_id = _job_id(ids.loc[block.index[0]])
        if jobs and jobs[-1][0] == wo_id:
            jobs[-1][1].append(block)  # same job, resumed after an idle stretch
        else:
            jobs.append([wo_id, [block]])

    workorders = []
    for wo_id, blocks in jobs:
        wo_rows = pd.concat(blocks).reset_index(drop=True) if len(blocks) > 1 else blocks[0].reset_index(drop=True)
        wo = Workorder(workorder=wo_id, rows=wo_rows)
        for mt in wo_rows[JOB_TYPE].unique():
            if int(mt) in rules.idle_types:
                continue  # idle rows: skipped, not flagged
            if int(mt) in rules.unexpected_types:
                wo.warnings.append(f"Unexpected job type {int(mt)} present in workorder")
        t0, t1 = wo_rows["_ts"].iloc[0], wo_rows["_ts"].iloc[-1]
        for bid, secs, when, at in blips:
            if t0 <= when <= t1:
                wo.warnings.append(f"Job id briefly changed to {_job_id(bid)} for {secs or 1} s at "
                                   f"{time_only(at)} - treated as a glitch, kept in this job")
        wo.phases = split_phases(wo_rows, wo_id, rules)
        workorders.append(wo)
    return workorders


def split_phases(wo_rows: pd.DataFrame, wo_id: int, rules=None) -> List[Phase]:
    """
    Detects phase boundaries by changes in job type. Idle job types
    (Settings > Job types; MoveType 0 by default) are skipped, not flagged.
    """
    rules = rules or DEFAULT_RULES
    active = wo_rows[~wo_rows[JOB_TYPE].isin(rules.idle_types)].reset_index(drop=True)
    if active.empty:
        return []

    mt = active[JOB_TYPE].astype(int)
    starts = [0] + list((mt != mt.shift()).to_numpy().nonzero()[0][1:]) + [len(active)]
    phases = []
    for n, (a, b) in enumerate(zip(starts[:-1], starts[1:]), start=1):
        phases.append(Phase(workorder=wo_id, phase_num=n, move_type=int(mt.iat[a]),
                            rows=active.iloc[a:b].reset_index(drop=True)))
    return phases


def _next_job(workorders, i, rules):
    """The job after workorders[i] in time order (idle-only stretches are
    not jobs - see split_workorders)."""
    for j in range(i + 1, len(workorders)):
        if workorders[j].phases:
            return workorders[j]
    return None


def find_movetype3_phases_with_context(workorders: List[Workorder], rules=None):
    """
    Returns a list of (workorder, phase, next_workorder_or_None) for every
    MoveType=3 phase in the file. next_workorder is the next job in time
    order - used only for the necessity
    check's "did we pre-position for what comes next" comparison.
    """
    rules = rules or DEFAULT_RULES
    results = []
    for i, wo in enumerate(workorders):
        for phase in wo.phases:
            if phase.move_type in rules.reposition_types:
                next_wo = _next_job(workorders, i, rules)
                results.append((wo, phase, next_wo))
    return results


def find_pickup_workorders_with_context(workorders: List[Workorder], rules=None):
    """
    Returns a list of (workorder, next_workorder_or_None) for every workorder
    whose FIRST phase is MoveType=1 (a pickup) - i.e. every workorder that is
    supposed to be a pickup(+setdown) job, per the doc's rule that Phase 1 of
    a two-part (non-MoveType=3) workorder is always MoveType=1.

    next_workorder is the next job in time order - used by pickup_setdown_agent.py to detect a pickup
    that was never followed by a setdown IN THE SAME workorder.
    """
    rules = rules or DEFAULT_RULES
    results = []
    for i, wo in enumerate(workorders):
        if wo.phases and wo.phases[0].move_type == rules.pickup_type:
            next_wo = _next_job(workorders, i, rules)
            results.append((wo, next_wo))
    return results
