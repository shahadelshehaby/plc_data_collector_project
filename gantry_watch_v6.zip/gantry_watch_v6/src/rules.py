"""
rules.py
=========
Every decision the analysis makes, as settings.

Until now these rules were written into the agents' code (step 4 means
"lift", MoveType 3 means "reposition", a reposition is necessary only when
both the position and the next job type match, ...). They now live here as
one list, RULE_FIELDS, which drives everything:

  - the profile XML (<rules> section), read by config_loader.py
  - validation of the Settings form (settings_store.py)
  - the Settings page itself (app.js draws the form from /api/rules-schema)

The defaults reproduce the previous built-in behaviour exactly, so an older
profile without a <rules> section analyses data the same way as before.

Energy settings (method, P_ref per axis, efficiencies, how energy fed back is
counted) are in ENERGY_* below - see power_agent.py for the calculation.
"""
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Dict, List, Optional

AXES = ("gantry", "trolley", "hoist")

# --------------------------------------------------------------------------
# Field types:
#   int        whole number            int_opt   whole number or blank (= off)
#   int_list   "3, 4, 5, 6"            text      a name (e.g. a column)
#   choice     one of options          bool      on/off
#   axis       gantry / trolley / hoist
# --------------------------------------------------------------------------
RULE_GROUPS = [
    ("jobs", "Job types and columns",
     "How the PLC log describes a job. The analysis splits the log into jobs by the job id, "
     "and decides what each job is from its job type."),
    ("sequence", "Step sequence rules",
     "How the steps of a reposition are checked. Steps are matched in the expected order; "
     "a step that comes out of order is abnormal."),
    ("performance", "Performance rules",
     "How the travel time of a move is measured. The time limits themselves are under Thresholds."),
    ("necessity", "Necessity rules: repositions",
     "When a reposition counts as necessary. It is judged against the job that follows it."),
    ("pickups", "Necessity rules: pickups and setdowns",
     "When a pickup counts as necessary."),
    ("cases", "Cases (Operation report)",
     "A case is a run of moves ending at the first one that achieves something."),
    ("flags", "REVIEW flag",
     "Which findings mark a move REVIEW in the reports."),
    ("waste", "Wasted energy",
     "Which moves' energy counts as wasted. How energy fed back by braking counts is under Energy."),
    ("lanes", "Lanes",
     "How the lane is read from the machine name. Used for lane filters and the per-lane tables."),
]

SEVERITY = [("normal", "Normal"), ("minor_waste", "Minor waste"), ("abnormal", "Abnormal")]

RULE_FIELDS = [
    # ---------------------------------------------------------------- jobs
    dict(key="col_job_id", group="jobs", type="text", default="WorkorderIdent", label="Job id column",
         help="Rows with the same value belong to one job (workorder)."),
    dict(key="col_job_type", group="jobs", type="text", default="MoveType", label="Job type column",
         help="The code that says what kind of job it is."),
    dict(key="col_step", group="jobs", type="text", default="Step", label="Step column",
         help="The step the machine is in within a job."),
    dict(key="reposition_types", group="jobs", type="int_list", default=[3], label="Reposition job types",
         help="Jobs checked for step sequence, performance and necessity (MoveType 3, move only)."),
    dict(key="pickup_type", group="jobs", type="int", default=1, label="Pickup job type",
         help="First phase of a pickup-and-setdown job."),
    dict(key="setdown_type", group="jobs", type="int", default=2, label="Setdown job type",
         help="The phase that completes a pickup in the same job."),
    dict(key="idle_types", group="jobs", type="int_list", default=[0], label="Idle job types",
         help="Rows with these codes are ignored when splitting a job into phases."),
    dict(key="job_id_blip_seconds", group="jobs", type="int", default=10, min=0, max=600,
         label="Ignore job id blips up to (s)",
         help="When the job id changes for a few seconds and then returns to the same id (e.g. 339, 2342, 339), "
              "the short change is treated as a glitch and those rows stay in the surrounding job. 0 = off."),
    dict(key="unexpected_types", group="jobs", type="int_list", default=[4, 5], label="Unexpected job types",
         help="Noted as a warning on the job when they appear (park, calibration)."),

    # ------------------------------------------------------------ sequence
    dict(key="expected_order", group="sequence", type="int_list", default=[3, 4, 5, 6], label="Expected step order",
         help="The normal steps of a reposition, in order. A step may be skipped; a step that comes "
              "back out of order is abnormal."),
    dict(key="movement_steps", group="sequence", type="int_list", default=[5, 6], label="Movement steps",
         help="Steps in which the machine travels. Used to find the axis that moved, to time the move, "
              "and for the end-position check."),
    dict(key="lift_step", group="sequence", type="int_opt", default=4, label="Lift step",
         help="Step that lifts to safe travel height. Blank = no lift rule."),
    dict(key="height_axis", group="sequence", type="axis", default="hoist", label="Height axis",
         help="Axis whose start position is compared with the safe height (Thresholds)."),
    dict(key="lift_when_high", group="sequence", type="choice", default="minor_waste", options=SEVERITY,
         label="Lift step when already at safe height",
         help="The lift step in its normal place, but the height axis was already at or above safe height."),
    dict(key="lift_out_of_order_when_high", group="sequence", type="choice", default="abnormal", options=SEVERITY,
         label="Lift step out of order, already high",
         help="The lift step after later steps, with the height axis already at or above safe height."),
    dict(key="check_end_position", group="sequence", type="bool", default=True,
         label="Check the end position",
         help="The last movement step is abnormal if the moving axis ends further from its reference "
              "than the position match tolerance (Thresholds)."),
    dict(key="mi_step", group="sequence", type="int_opt", default=9, label="Manual intervention step",
         help="Step meaning an operator took over. Blank = no manual intervention handling."),
    dict(key="mi_absorbs_step", group="sequence", type="int_opt", default=3, show_if=["mi_step", "*"],
         label="Step merged into a manual intervention",
         help="This step right after a manual intervention is counted as part of it. Blank = none."),
    dict(key="resume_after_interruption", group="sequence", type="bool", default=True,
         label="Allow resuming after an interruption",
         help="After a manual intervention or an out-of-order step, repeating the last good step is "
              "normal (the sequence resumes)."),

    # --------------------------------------------------------- performance
    dict(key="speed_smoothing", group="performance", type="int", default=3, min=1, max=15,
         label="Speed smoothing (samples)",
         help="Moving average over this many samples for the actual speed curve. 1 = no smoothing."),

    # ----------------------------------------------------------- necessity
    dict(key="necessity_rule", group="necessity", type="choice", default="position_and_type",
         options=[("position_and_type", "Position matches and the next job type is expected"),
                  ("position_only", "Position matches the next job's start"),
                  ("type_only", "The next job type is expected")],
         label="A reposition is necessary when",
         help="Position match uses the necessity tolerance (Thresholds), on the axis that moved."),
    dict(key="necessity_axis", group="necessity", type="choice", default="gantry",
         options=[("gantry", "Gantry"), ("trolley", "Trolley"), ("hoist", "Hoist"),
                  ("moved", "The axis that moved the most in the reposition")],
         label="Compare the position on",
         help="Where the reposition ended is compared with the next job's position on this axis, "
              "within the necessity tolerance (Thresholds)."),
    dict(key="expected_next_types", group="necessity", type="int_list", default=[1], label="Expected next job types",
         help="Job types that may follow a necessary reposition, e.g. 1 (pickup), or 1, 2."),

    # ------------------------------------------------------------- pickups
    dict(key="evaluate_pickups", group="pickups", type="bool", default=True, label="Check pickups and setdowns",
         help="Judge pickup jobs and include them in cases, totals and wasted energy."),
    dict(key="pickup_only_rule", group="pickups", type="choice", default="chain",
         options=[("chain", "Judged with the pickups up to the setdown, by gantry position"),
                  ("always", "Always unnecessary"),
                  ("next_is_pickup", "Unnecessary only if the next job is another pickup (otherwise unknown)")],
         label="A pickup without its own setdown is",
         help="By gantry position: consecutive pickups are one chain ending at a setdown. The unbroken run of "
              "pickups at the same gantry position as the last pickup before the setdown is necessary (within the "
              "necessity tolerance); earlier pickups at other positions are unnecessary. A chain that never "
              "reaches a setdown is unnecessary; unknown only if the data ends first. "
              "Example: 300, 400, 400, setdown: 300 is unnecessary, both 400s are necessary."),

    # --------------------------------------------------------------- cases
    dict(key="case_close_on", group="cases", type="choice", default="type",
         options=[("type", "the next job type is expected (position not required)"),
                  ("necessary", "the reposition is necessary")],
         label="A reposition closes a case when",
         help="A completed pickup-and-setdown always closes a case."),
    dict(key="cases_shown", group="cases", type="choice", default="with_unnecessary",
         options=[("with_unnecessary", "Only cases with an unnecessary move"), ("all", "All cases")],
         label="Case details shown in the report"),

    # --------------------------------------------------------------- flags
    dict(key="flag_abnormal", group="flags", type="bool", default=True, label="Abnormal step sequence"),
    dict(key="flag_minor_waste", group="flags", type="bool", default=False, label="Minor waste step"),
    dict(key="flag_mi", group="flags", type="bool", default=False, label="Manual intervention"),
    dict(key="flag_slow", group="flags", type="bool", default=True, label="Slow move (performance issue)"),
    dict(key="flag_aborted", group="flags", type="bool", default=True, label="Aborted move"),
    dict(key="flag_no_movement", group="flags", type="bool", default=False, label="No movement"),
    dict(key="flag_unnecessary", group="flags", type="bool", default=True, label="Unnecessary move"),

    # --------------------------------------------------------------- waste
    dict(key="waste_moves", group="waste", type="choice", default="unnecessary",
         options=[("unnecessary", "Confirmed unnecessary moves"),
                  ("unnecessary_or_unknown", "Unnecessary moves and moves that couldn't be judged")],
         label="Wasted energy comes from",
         help="A move can't be judged when no job follows it (usually the last move of the day)."),

    # --------------------------------------------------------------- lanes
    dict(key="lane_rule", group="lanes", type="choice", default="leading_letters",
         options=[("leading_letters", "The letters at the start (B203 is lane B)"),
                  ("character", "One character at a position (Y2893 with position 2 is lane 2)"),
                  ("regex", "A pattern (advanced)")],
         label="Lane is"),
    dict(key="lane_char", group="lanes", type="int", default=1, min=1, max=20, label="Character position",
         show_if=["lane_rule", "character"],
         help="Used when the lane is one character: 1 is the first character."),
    dict(key="lane_regex", group="lanes", type="text", default="^[A-Za-z]+", label="Pattern",
         show_if=["lane_rule", "regex"],
         help="Used when the lane is a pattern: the first match is the lane, e.g. ^[A-Za-z]+ ."),
]
FIELD_BY_KEY = {f["key"]: f for f in RULE_FIELDS}


# =========================================================================
# Energy
# =========================================================================
ENERGY_METHODS = [("torque_speed", "Torque × speed (drives log torque % and speed %)"),
                  ("voltage_current", "Voltage × current × power factor (drives log real volts and amps)")]
ENERGY_BASIS = [("net", "Net: used minus fed back"), ("consumed", "Only energy used (ignore what is fed back)")]
SPEED_SIGN = [("auto", "Check automatically"), ("signed", "Signed: negative when moving backwards"),
              ("magnitude", "Magnitude only: direction from the position change")]

ENERGY_DEFAULT_AXES = {
    "gantry": {"p_ref_kw": 75.0, "p353_rpm": None, "p354_nm": None,
               "torque_cols": ["GantryTorque1", "GantryTorque2"], "speed_cols": ["GANTRYSPEED1", "GANTRYSPEED2"],
               "invert_direction": False},
    "trolley": {"p_ref_kw": None, "p353_rpm": None, "p354_nm": None,
                "torque_cols": ["TrolleyTorque1", "TrolleyTorque2"], "speed_cols": ["TROLLEYSPEED1", "TROLLEYSPEED2"],
                "invert_direction": False},
    "hoist": {"p_ref_kw": None, "p353_rpm": None, "p354_nm": None,
              "torque_cols": ["HoistTorque1", "HoistTorque2"], "speed_cols": ["HOISTSPEED1", "HOISTSPEED2"],
              "invert_direction": False},
}


@dataclass
class EnergyAxis:
    p_ref_kw: Optional[float] = None
    p353_rpm: Optional[float] = None
    p354_nm: Optional[float] = None
    torque_cols: List[str] = field(default_factory=list)
    speed_cols: List[str] = field(default_factory=list)
    invert_direction: bool = False

    @property
    def p_ref(self) -> Optional[float]:
        """Power of ONE drive at 100 % torque and 100 % speed, in kW:
        P354 [Nm] x P353 [rpm] / 9550 when both are known, else the kW value."""
        if self.p353_rpm and self.p354_nm:
            return self.p354_nm * self.p353_rpm / 9550.0
        return self.p_ref_kw


@dataclass
class EnergyConfig:
    method: str = "torque_speed"
    basis: str = "net"
    motor_efficiency: float = 0.93
    drive_efficiency: float = 0.98
    speed_sign: str = "auto"
    axes: Dict[str, EnergyAxis] = field(default_factory=dict)

    @property
    def efficiency(self) -> float:
        return self.motor_efficiency * self.drive_efficiency


def default_energy() -> EnergyConfig:
    return EnergyConfig(axes={a: EnergyAxis(**{k: (list(v) if isinstance(v, list) else v)
                                               for k, v in d.items()})
                              for a, d in ENERGY_DEFAULT_AXES.items()})


# =========================================================================
# Rules object
# =========================================================================
class Rules:
    """Attribute access to every rule: rules.expected_order, rules.flag_mi, ..."""

    def __init__(self, values=None):
        for f in RULE_FIELDS:
            v = f["default"]
            setattr(self, f["key"], list(v) if isinstance(v, list) else v)
        for k, v in (values or {}).items():
            if k in FIELD_BY_KEY:
                setattr(self, k, v)

    def to_dict(self):
        return {f["key"]: getattr(self, f["key"]) for f in RULE_FIELDS}

    # convenience
    def is_reposition(self, job_type) -> bool:
        return int(job_type) in self.reposition_types

    def severity_label(self, kind):
        return dict(SEVERITY).get(kind, kind)


DEFAULT_RULES = Rules()


# =========================================================================
# Parsing / validation (shared by the XML loader and the Settings form)
# =========================================================================
def _parse_value(f, raw, errors):
    """raw: a string from XML, or a JSON value from the form."""
    t, label = f["type"], f["label"]
    if t == "bool":
        if isinstance(raw, bool):
            return raw
        return str(raw).strip().lower() in ("1", "true", "yes", "on")
    if t in ("text",):
        v = str(raw if raw is not None else "").strip()
        if not v:
            errors.append(f"{label}: enter a value.")
        if f["key"] == "lane_regex" and v:
            try:
                re.compile(v)
            except re.error as e:
                errors.append(f"{label}: not a valid pattern ({e}).")
        return v
    if t == "choice":
        v = str(raw or "").strip()
        valid = [o[0] for o in f["options"]]
        if v not in valid:
            errors.append(f"{label}: choose one of the options.")
            return f["default"]
        return v
    if t == "axis":
        v = str(raw or "").strip().lower()
        if v not in AXES:
            errors.append(f"{label}: choose gantry, trolley or hoist.")
            return f["default"]
        return v
    if t in ("int", "int_opt"):
        if raw is None or str(raw).strip() == "":
            if t == "int_opt":
                return None
            errors.append(f"{label}: enter a whole number.")
            return f["default"]
        try:
            fv = float(str(raw).strip())
            if fv != int(fv):
                raise ValueError
            v = int(fv)
        except ValueError:
            errors.append(f"{label}: must be a whole number.")
            return f["default"]
        if "min" in f and v < f["min"] or "max" in f and v > f["max"]:
            errors.append(f"{label}: must be from {f.get('min')} to {f.get('max')}.")
        return v
    if t == "int_list":
        items = raw if isinstance(raw, list) else re.split(r"[,\s;]+", str(raw or ""))
        out = []
        for it in items:
            s = str(it).strip()
            if not s:
                continue
            try:
                fv = float(s)
                if fv != int(fv):
                    raise ValueError
                out.append(int(fv))
            except ValueError:
                errors.append(f"{label}: '{s}' is not a whole number.")
        if not out and f["key"] not in ("idle_types", "unexpected_types"):
            errors.append(f"{label}: enter at least one code.")
        return out
    raise ValueError(f"unknown field type {t}")


def validate_rules(values: dict, errors: list) -> dict:
    out = {}
    for f in RULE_FIELDS:
        raw = values.get(f["key"], f["default"]) if values else f["default"]
        out[f["key"]] = _parse_value(f, raw, errors)
    # cross-field checks
    if out["lift_step"] is not None and out["lift_step"] not in out["expected_order"]:
        errors.append("Lift step must be one of the steps in the expected step order.")
    if not set(out["movement_steps"]) & set(out["expected_order"]):
        errors.append("At least one movement step must be in the expected step order.")
    if out["pickup_type"] == out["setdown_type"]:
        errors.append("Pickup and setdown job types must be different.")
    if set(out["reposition_types"]) & {out["pickup_type"], out["setdown_type"]}:
        errors.append("A reposition job type can't also be the pickup or setdown type.")
    if set(out["idle_types"]) & (set(out["reposition_types"]) | {out["pickup_type"], out["setdown_type"]}):
        errors.append("An idle job type can't also be a reposition, pickup or setdown type.")
    if out["mi_step"] is not None and out["mi_step"] in out["expected_order"]:
        errors.append("The manual intervention step can't be in the expected step order.")
    return out


def _num_opt(raw, label, errors, lo=None, hi=None, positive=False):
    if raw is None or str(raw).strip() == "":
        return None
    try:
        v = float(str(raw).strip())
    except ValueError:
        errors.append(f"{label} must be a number.")
        return None
    if positive and v <= 0 or lo is not None and v < lo or hi is not None and v > hi:
        rng = f"from {lo} to {hi}" if lo is not None and hi is not None else "greater than 0"
        errors.append(f"{label} must be {rng}.")
    return v


def _names(raw):
    items = raw if isinstance(raw, list) else str(raw or "").split(",")
    return [str(x).strip() for x in items if str(x).strip()]


def validate_energy(values: dict, errors: list) -> dict:
    values = values or {}
    d = energy_to_dict(default_energy())
    out = {}
    for key, opts, label in (("method", ENERGY_METHODS, "Energy method"), ("basis", ENERGY_BASIS, "Energy fed back"),
                             ("speed_sign", SPEED_SIGN, "Speed direction")):
        v = str(values.get(key, d[key]) or "")
        if v not in [o[0] for o in opts]:
            errors.append(f"{label}: choose one of the options.")
            v = d[key]
        out[key] = v
    for key, label in (("motor_efficiency", "Motor efficiency"), ("drive_efficiency", "Drive efficiency")):
        v = _num_opt(values.get(key, d[key]), label, errors, lo=0.5, hi=1.0)
        if v is None:
            errors.append(f"{label} is required (between 0.5 and 1).")
            v = d[key]
        out[key] = v
    out["axes"] = {}
    for axis in AXES:
        src = (values.get("axes") or {}).get(axis) or d["axes"][axis]
        a = {"p_ref_kw": _num_opt(src.get("p_ref_kw"), f"{axis.title()} P_ref", errors, positive=True),
             "p353_rpm": _num_opt(src.get("p353_rpm"), f"{axis.title()} P353", errors, positive=True),
             "p354_nm": _num_opt(src.get("p354_nm"), f"{axis.title()} P354", errors, positive=True),
             "torque_cols": _names(src.get("torque_cols")), "speed_cols": _names(src.get("speed_cols")),
             "invert_direction": bool(src.get("invert_direction"))}
        if bool(a["p353_rpm"]) != bool(a["p354_nm"]):
            errors.append(f"{axis.title()}: enter both P353 and P354, or neither (then P_ref kW is used).")
        if len(a["torque_cols"]) != len(a["speed_cols"]):
            errors.append(f"{axis.title()}: give one speed column for each torque column (same drive order).")
        out["axes"][axis] = a
    return out


# =========================================================================
# XML  <rules> / <energy>
# =========================================================================
def _fmt(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, list):
        return ", ".join(str(x) for x in v)
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    return str(v)


def rules_from_xml(root, legacy_expected_next=None) -> Rules:
    el = root.find("rules")
    values = {}
    if el is not None:
        errors = []
        for f in RULE_FIELDS:
            node = el.find(f["key"])
            if node is not None:
                values[f["key"]] = _parse_value(f, node.text or "", errors)
        if errors:
            raise ValueError("Invalid <rules> in profile: " + "; ".join(errors))
        if el.find("necessity_axis") is None and values.get("pickup_only_rule") == "always":
            # Saved before the pickup chain rule existed, when "always" was the
            # default: use the new default (Settings > Necessity rules: pickups).
            values["pickup_only_rule"] = "chain"
    elif legacy_expected_next is not None:
        values["expected_next_types"] = [legacy_expected_next]
    return Rules(values)


def rules_to_xml(parent, rules_dict):
    el = ET.SubElement(parent, "rules")
    for f in RULE_FIELDS:
        ET.SubElement(el, f["key"]).text = _fmt(rules_dict.get(f["key"], f["default"]))
    return el


def energy_from_xml(root) -> EnergyConfig:
    el = root.find("energy")
    cfg = default_energy()
    if el is None:
        return cfg

    def txt(node, tag):
        n = node.find(tag)
        return (n.text or "").strip() if n is not None and n.text else ""

    cfg.method = txt(el, "method") or cfg.method
    cfg.basis = txt(el, "basis") or cfg.basis
    cfg.speed_sign = txt(el, "speed_sign") or cfg.speed_sign
    if txt(el, "motor_efficiency"):
        cfg.motor_efficiency = float(txt(el, "motor_efficiency"))
    if txt(el, "drive_efficiency"):
        cfg.drive_efficiency = float(txt(el, "drive_efficiency"))
    for ax_el in el.findall("axis"):
        name = ax_el.get("name")
        a = cfg.axes.setdefault(name, EnergyAxis())
        f = lambda tag: float(txt(ax_el, tag)) if txt(ax_el, tag) else None  # noqa: E731
        a.p_ref_kw, a.p353_rpm, a.p354_nm = f("p_ref_kw"), f("p353_rpm"), f("p354_nm")
        a.torque_cols = _names(txt(ax_el, "torque_cols"))
        a.speed_cols = _names(txt(ax_el, "speed_cols"))
        a.invert_direction = txt(ax_el, "invert_direction").lower() == "true"
    return cfg


def energy_to_dict(cfg: EnergyConfig) -> dict:
    return {"method": cfg.method, "basis": cfg.basis, "motor_efficiency": cfg.motor_efficiency,
            "drive_efficiency": cfg.drive_efficiency, "speed_sign": cfg.speed_sign,
            "axes": {a: {"p_ref_kw": x.p_ref_kw, "p353_rpm": x.p353_rpm, "p354_nm": x.p354_nm,
                         "torque_cols": list(x.torque_cols), "speed_cols": list(x.speed_cols),
                         "invert_direction": x.invert_direction}
                     for a, x in cfg.axes.items()}}


def energy_to_xml(parent, d):
    el = ET.SubElement(parent, "energy")
    el.append(ET.Comment(" P_ref per drive [kW] = P354 [Nm] x P353 [rpm] / 9550 when both are set, else p_ref_kw. "))
    for k in ("method", "basis", "motor_efficiency", "drive_efficiency", "speed_sign"):
        ET.SubElement(el, k).text = _fmt(d[k])
    for axis in AXES:
        a = d["axes"][axis]
        ax = ET.SubElement(el, "axis", name=axis)
        for k in ("p_ref_kw", "p353_rpm", "p354_nm", "torque_cols", "speed_cols", "invert_direction"):
            ET.SubElement(ax, k).text = _fmt(a[k])
    return el


# =========================================================================
# The schema the Settings page draws its form from
# =========================================================================
def schema():
    fields = []
    for f in RULE_FIELDS:
        item = {k: v for k, v in f.items() if k != "options"}
        if "options" in f:
            item["options"] = [{"value": v, "label": lbl} for v, lbl in f["options"]]
        fields.append(item)
    return {
        "groups": [{"id": g, "title": t, "intro": i} for g, t, i in RULE_GROUPS],
        "fields": fields,
        "energy": {"methods": [{"value": v, "label": lbl} for v, lbl in ENERGY_METHODS],
                   "basis": [{"value": v, "label": lbl} for v, lbl in ENERGY_BASIS],
                   "speed_sign": [{"value": v, "label": lbl} for v, lbl in SPEED_SIGN]},
    }


# =========================================================================
# Lane rule (used by the library, reports and the NAS machine list)
# =========================================================================
_lane_rule = {"lane_rule": "leading_letters", "lane_char": 1, "lane_regex": "^[A-Za-z]+"}


def set_lane_rule(rules):
    src = rules.to_dict() if isinstance(rules, Rules) else (rules or {})
    for k in _lane_rule:
        if k in src:
            _lane_rule[k] = src[k]


def lane_rule():
    return dict(_lane_rule)


def lane_of(machine, rule=None):
    r = rule or _lane_rule
    name = str(machine or "")
    kind = r.get("lane_rule", "leading_letters")
    if kind == "character":
        i = int(r.get("lane_char") or 1) - 1
        return name[i].upper() if 0 <= i < len(name) else "?"
    if kind == "regex":
        try:
            m = re.search(r.get("lane_regex") or "^[A-Za-z]+", name)
        except re.error:
            m = None
        return m.group(0).upper() if m and m.group(0) else "?"
    m = re.match(r"^[A-Za-z]+", name)
    return m.group(0).upper() if m else "?"
