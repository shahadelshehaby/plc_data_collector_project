# Terminal 2 crane collectors

| File | What it is |
|---|---|
| `collector_updated_cranes_list.xlsx` | **The crane list.** Crane, Port, Collector Version (2 / 2.1). Blank or NA = not started. |
| `launch_cranes.py` | Starts all cranes from the Excel, frees their ports first, restarts any that stop. |
| `crane_collector.py` | One crane: UDP -> InfluxDB. Replaces `typingtensions_updatedv2.py` and `v2.1.py` (same fields). |
| `crane_status.py` / `view_status.bat` | Live status screen. |
| `collector_settings.py` | InfluxDB URL/org/bucket, packet sizes, log settings. |
| `influx_token.txt` | **You create this.** The InfluxDB token on one line (kept out of the code). |
| `install_service.bat` | Installs everything as a Windows service (auto start at boot). |
| `restart_service.bat` | Apply changes after editing the Excel. |
| `run_in_window.bat` | Testing only: run in a window instead of a service. |
| `uninstall_service.bat` | Stop and remove the service. |

## First-time setup
1. Copy this folder to the PC, e.g. `C:\CraneCollector\` (avoid the Desktop for a service).
2. Create `influx_token.txt` with the token.
3. `pip install -r requirements.txt`
4. Stop the old collectors (close their terminals).
5. Test: double-click `run_in_window.bat`, check the table, then Ctrl+C.
6. Download NSSM (https://nssm.cc/download), copy `win64\nssm.exe` into this folder.
7. Right-click `install_service.bat` -> Run as administrator.
8. Double-click `view_status.bat` any time.

## Status meanings
| State | Meaning |
|---|---|
| OK | Packets arriving and written to InfluxDB |
| NO DATA | Collector runs, but no packet for 10 s (crane off, PLC, network, wrong port in PLC) |
| WRONG SIZE | Packet size does not match the version in the Excel (344 = v2, 364 = v2.1) |
| 2+ SOURCES | More than one IP is sending to this port: two PLCs configured with the same port |
| INFLUX ERR | Packets arrive but InfluxDB write fails |
| DOWN | Collector process not running (the launcher restarts it automatically) |
| NOT STARTED | Excel problem: duplicate port/crane, missing port, unknown version |

## Adding a crane
Fill in Port and Collector Version in the Excel, save, run `restart_service.bat` as administrator.

## Logs
`logs\<CRANE>.log` - one summary line per minute, plus every warning/error (5 MB x 6 files max).
`logs\launcher.log` - starts, stops, restarts, ports freed.
Set `LOG_EVERY_PACKET = True` in `collector_settings.py` for one line per packet.
