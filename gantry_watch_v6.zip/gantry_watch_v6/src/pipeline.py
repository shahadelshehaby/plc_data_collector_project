"""
pipeline.py
============
Two steps, shared by the web UI (library.py) and the command line:

  analyze_file()   one PLC file -> MoveType=3 results, pickup/setdown results,
                   and the calendar dates present in the file.
  build_reports()  already-analyzed results (filtered by the caller) ->
                   PDFs, either one set per day ("daily") or one set for the
                   whole date range ("period").

Daily mode writes into <out_dir>/<date>/:
    <crane>_<date>.pdf, Summary_<date>.pdf, Operation_<date>.pdf
Period mode writes into <out_dir>/<from>_to_<to>/:
    Overview_<from>_to_<to>.pdf   (per-day / per-lane / per-crane trend - report_period.py)
    Summary_..., Operation_...    (the same reports, built over the whole period)
    <crane>_... (optional - one detail page per move, so these get long)
"""
import json
import os
from collections import defaultdict

from orchestrator import analyze_machine_day_file
from report_machine import generate_machine_report
from report_summary import generate_summary_report
from report_operation import generate_operation_report
from report_period import generate_period_report
from columns import load_enum_overrides_from_columns_info, set_enum_overrides
from utils import ensure_dir, display_date, set_show_date_in_times


def apply_columns_info(path, log=print):
    """Loads code->description names from a Columns_info file (or falls back
    to the built-in names if there is none)."""
    if path and os.path.isfile(path):
        try:
            set_enum_overrides(load_enum_overrides_from_columns_info(path))
            return
        except Exception as e:
            log(f"WARNING: could not read '{os.path.basename(path)}': {e}. Using built-in names.")
    set_enum_overrides({})


def analyze_file(path, machine, config, quality=None):
    return analyze_machine_day_file(path, machine, config, quality=quality)


def period_label(date_from, date_to):
    return display_date(date_from) if date_from == date_to else \
        f"{display_date(date_from)} to {display_date(date_to)}"


_REPORT_FUNCS = {
    "machine": lambda: generate_machine_report,
    "summary": lambda: generate_summary_report,
    "operation": lambda: generate_operation_report,
    "overview": lambda: generate_period_report,
}


def render_report(kind, args, kwargs, show_date, columns_info, lane_rules):
    """Writes one PDF. Runs in a worker process when reports are built in
    parallel, so it first sets up that process's module settings."""
    from rules import set_lane_rule
    set_show_date_in_times(show_date)
    if columns_info is not None:
        apply_columns_info(columns_info, log=lambda *a: None)
    if lane_rules is not None:
        set_lane_rule(lane_rules)
    _REPORT_FUNCS[kind]()(*args, **kwargs)


def build_reports(by_date, ps_by_date, config, out_dir, mode="daily", date_from=None, date_to=None,
                  include_machine_reports=True, write_json=False, filters_text="", log=print,
                  pool=None, columns_info=None, include_overview=True, include_summary=True,
                  include_operation=True, cases_shown="settings"):
    """
    by_date:    {date: {machine: [MoveType3Result]}}   (already filtered)
    ps_by_date: {date: {machine: [PickupSetdownWorkorderResult]}}
    include_*:  which PDFs to write; cases_shown: which cases the Operation
                report details ("settings", "all", "unnecessary", "successful").
    pool:       optional concurrent.futures executor - the PDFs are then
                written in parallel (columns_info: the Columns_info path the
                workers should load).
    Returns (outputs, failed) where outputs is a list of
    {"group", "group_label", "kind", "machine", "name", "relpath"}.
    """
    outputs, failed = [], []
    dates = sorted(set(by_date) | set(ps_by_date))
    tasks = []  # [group label, output entry, future or None, error]
    show_date = [False]

    def entry(group, group_label, kind, machine, path):
        return {"group": group, "group_label": group_label, "kind": kind, "machine": machine,
                "name": os.path.basename(path),
                "relpath": os.path.relpath(path, out_dir).replace(os.sep, "/")}

    def pdf(group, label, kind, machine, path, args, kwargs):
        item = [label, entry(group, label, kind, machine, path), None, None,
                lambda: _REPORT_FUNCS[kind]()(*args, **kwargs)]
        if pool is not None:
            item[2] = pool.submit(render_report, kind, args, kwargs, show_date[0], columns_info,
                                  getattr(config, "rules", None))
        else:
            try:
                _REPORT_FUNCS[kind]()(*args, **kwargs)
            except Exception as e:  # noqa: BLE001 - reported per file below
                item[3] = e
        tasks.append(item)

    def write_set(group, label, machine_results, ps_results, suffix, period):
        folder = ensure_dir(os.path.join(out_dir, group))
        machines = sorted(set(machine_results) | set(ps_results))
        if include_machine_reports:
            for machine in machines:
                out_pdf = os.path.join(folder, f"{machine}_{suffix}.pdf")
                pdf(group, label, "machine", machine, out_pdf,
                    (machine, label, machine_results.get(machine, []), out_pdf),
                    dict(pickup_setdown_results=ps_results.get(machine, []), config=config))
        if write_json:
            for machine in machines:
                out_json = os.path.join(folder, f"{machine}_{suffix}.json")
                with open(out_json, "w") as f:
                    json.dump({
                        "movetype3": [r.to_dict() for r in machine_results.get(machine, [])],
                        "pickup_setdown": [r.to_dict() for r in ps_results.get(machine, [])],
                    }, f, indent=2, default=str)
                tasks.append([label, entry(group, label, "json", machine, out_json), None, None, None])
        if include_summary:
            summary_pdf = os.path.join(folder, f"Summary_{suffix}.pdf")
            pdf(group, label, "summary", None, summary_pdf, (label, machine_results, summary_pdf),
                dict(pickup_setdown_results=ps_results, config=config, period=period))
        if include_operation:
            operation_pdf = os.path.join(folder, f"Operation_{suffix}.pdf")
            pdf(group, label, "operation", None, operation_pdf, (label, machine_results, operation_pdf),
                dict(pickup_setdown_results=ps_results, config=config, period=period, cases_shown=cases_shown))

    if mode == "period":
        date_from = date_from or (dates[0] if dates else "")
        date_to = date_to or (dates[-1] if dates else "")
        group = date_from if date_from == date_to else f"{date_from}_to_{date_to}"
        label = period_label(date_from, date_to)
        show_date[0] = date_from != date_to
        set_show_date_in_times(show_date[0])
        try:
            if include_overview:
                overview = os.path.join(ensure_dir(os.path.join(out_dir, group)), f"Overview_{group}.pdf")
                pdf(group, label, "overview", None, overview,
                    (label, by_date, ps_by_date, overview, filters_text, config), {})

            merged, merged_ps = defaultdict(list), defaultdict(list)
            for d in dates:
                for m, rs in by_date.get(d, {}).items():
                    merged[m].extend(rs)
                for m, rs in ps_by_date.get(d, {}).items():
                    merged_ps[m].extend(rs)
            for lst in list(merged.values()) + list(merged_ps.values()):
                lst.sort(key=lambda r: r.time_start)
            write_set(group, label, dict(merged), dict(merged_ps), group, period=True)
        except Exception as e:
            log(f"  ERROR generating the period reports: {e}")
            failed.append({"date": label, "error": str(e)})
    else:
        for d in dates:
            try:
                write_set(d, display_date(d), by_date.get(d, {}), ps_by_date.get(d, {}), d, period=False)
            except Exception as e:
                # One bad day must not stop the remaining days.
                log(f"  ERROR generating report(s) for {display_date(d)}: {e}")
                failed.append({"date": display_date(d), "error": str(e)})

    # Collect the PDFs in order (waiting for the parallel ones).
    try:
        failed_labels = {f["date"] for f in failed}
        from concurrent.futures.process import BrokenProcessPool
        for label, item, fut, err, inline in tasks:
            if fut is not None:
                try:
                    fut.result()
                except BrokenProcessPool:
                    try:  # the worker processes stopped: write this one here instead
                        inline()
                    except Exception as e:  # noqa: BLE001
                        err = e
                except Exception as e:  # noqa: BLE001
                    err = e
            if err is not None:
                log(f"  ERROR writing {item['name']}: {err}")
                if label not in failed_labels:
                    failed.append({"date": label, "error": str(err)})
                    failed_labels.add(label)
                continue
            outputs.append(item)
            if item["kind"] != "json":
                log(f"  Wrote {item['name']}")
    finally:
        set_show_date_in_times(False)
    return outputs, failed


def run_pipeline(files, config, out_dir, write_json=False, mode="daily", log=print):
    """Command-line helper: analyze files [(path, machine, name)] and write
    daily (or one period) report set(s) for everything found."""
    by_date = defaultdict(lambda: defaultdict(list))
    ps_by_date = defaultdict(lambda: defaultdict(list))
    for path, machine, fname in files:
        log(f"Analyzing {fname}  (crane {machine}) ...")
        try:
            results, ps_results, _ = analyze_file(path, machine, config)
        except Exception as e:
            log(f"  ERROR analyzing {fname}: {e}")
            continue
        for r in results:
            by_date[r.date][machine].append(r)
        for r in ps_results:
            ps_by_date[r.date][machine].append(r)
        log(f"  -> {len(results)} reposition move(s), {len(ps_results)} pickup workorder(s)")
    outputs, failed = build_reports(by_date, ps_by_date, config, out_dir, mode=mode,
                                    write_json=write_json, log=log)
    log("Done.")
    return outputs, failed
