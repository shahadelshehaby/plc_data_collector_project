"""Pieces shared by the two programs.

  Program 1  app.py            Rule Builder & Backtester  (port 5120)  Files / Settings / Logic / Evaluate
  Program 2  rootcause_app.py  Root Cause Analysis        (port 5001)

PROGRAMS (terminal + type)
  Every terminal/type pair is its own "program" with its own master list, PLC files, column mapping,
  rules and root-cause labels, because each one runs a different PLC program. They live in
  programs/<key>/ ; programs.json lists them. The fault history is ONE file shared by all programs.

Who writes what (so the two programs can never overwrite each other), inside programs/<key>/:
  fdd_settings.json       program 1 only  (paths, column mapping, rule logic)
  plc_data_store.csv      program 1 only  (accumulated PLC data)
  handoff/                program 1 on every Evaluate; program 2 only reads it
  rootcause_state.json    program 2 only  (pattern groups, labels, conversions)
"""
from __future__ import annotations
import sys
if sys.version_info < (3, 9):
    print("=" * 60)
    print(f"This tool needs Python 3.9 or newer. You have {sys.version.split()[0]}.")
    print("Download the latest version from https://python.org/downloads")
    print("and make sure to check 'Add Python to PATH' during install.")
    print("=" * 60)
    input("Press Enter to close...")
    sys.exit(1)

import hashlib
import json
import re
import shutil
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from fdd_theme import THEME_CSS

APP_DIR = Path(__file__).resolve().parent
PROGRAMS_DIR = APP_DIR / "programs"
REGISTRY_PATH = APP_DIR / "programs.json"
PORT_RULE_BUILDER = 5120   # NOT 5000/5002/5050: those belong to other platforms in the building
PORT_ROOT_CAUSE = 5001
DEFAULT_TERMINALS = ["1", "2", "3"]
RC_KEYS = ("clusters", "event_cluster_map", "event_overrides")


# ---------------------------------------------------------------- safe file helpers
def atomic_write_text(path: Path, text: str) -> None:
    """Write via a temp file + rename, so the other program never reads a half-written file."""
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


def atomic_write_json(path: Path, obj) -> None:
    atomic_write_text(path, json.dumps(obj, indent=2, default=str))


def atomic_to_csv(df: pd.DataFrame, path: Path) -> None:
    tmp = path.with_name(path.name + ".tmp")
    df.to_csv(tmp, index=False)
    tmp.replace(path)


def read_json(path: Path, default=None):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return default


# ---------------------------------------------------------------- programs (terminal + type)
def _slug(s) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "", str(s)).upper()


def program_key(terminal, ptype) -> str:
    return f"T{_slug(terminal)}_{_slug(ptype)}"


def program_label(p: dict) -> str:
    return f"Terminal {p['terminal']} · Type {p['type']}"


def ws_paths(key: str) -> SimpleNamespace:
    d = PROGRAMS_DIR / key
    return SimpleNamespace(dir=d, settings=d / "fdd_settings.json", plc_store=d / "plc_data_store.csv",
                           handoff=d / "handoff", manifest=d / "handoff" / "manifest.json", rc_state=d / "rootcause_state.json")


def save_registry(reg: dict) -> None:
    PROGRAMS_DIR.mkdir(exist_ok=True)
    atomic_write_json(REGISTRY_PATH, reg)


def _legacy_move(key: str) -> None:
    """Earlier versions kept one workspace directly in the app folder: move it into the first program."""
    d = ws_paths(key).dir
    d.mkdir(parents=True, exist_ok=True)
    for name in ("fdd_settings.json", "plc_data_store.csv", "rootcause_state.json", "handoff"):
        src = APP_DIR / name
        if src.exists():
            try:
                shutil.move(str(src), str(d / name))
            except Exception:  # noqa: BLE001
                pass


def load_registry() -> dict:
    reg = read_json(REGISTRY_PATH, None)
    if not isinstance(reg, dict) or not reg.get("programs"):
        reg = reg if isinstance(reg, dict) else {}
        key = program_key("1", "A")
        reg["terminals"] = reg.get("terminals") or list(DEFAULT_TERMINALS)
        reg["programs"] = [{"key": key, "terminal": "1", "type": "A"}]
        reg["active"] = key
        _legacy_move(key)
        legacy = read_json(ws_paths(key).settings, {}) or {}
        reg["faults_path"] = (legacy.get("paths") or {}).get("faults")
        ws_paths(key).dir.mkdir(parents=True, exist_ok=True)
        save_registry(reg)
    reg.setdefault("terminals", list(DEFAULT_TERMINALS))
    reg.setdefault("faults_path", None)
    if reg.get("active") not in {p["key"] for p in reg["programs"]}:
        reg["active"] = reg["programs"][0]["key"]
    return reg


def create_program(terminal, ptype):
    terminal = str(terminal or "").strip()
    ptype = re.sub(r"\s+", " ", str(ptype or "").strip())[:30]
    if not _slug(terminal):
        raise ValueError("Choose a terminal.")
    if not _slug(ptype):
        raise ValueError("Type a name for the type (for example A).")
    reg = load_registry()
    key = program_key(terminal, ptype)
    existing = next((p for p in reg["programs"] if p["key"] == key), None)
    if existing:
        return existing, reg
    p = {"key": key, "terminal": terminal, "type": ptype}
    reg["programs"].append(p)
    if terminal not in reg["terminals"]:
        reg["terminals"].append(terminal)
    ws_paths(key).dir.mkdir(parents=True, exist_ok=True)
    save_registry(reg)
    return p, reg


def delete_program(key: str) -> dict:
    reg = load_registry()
    if len(reg["programs"]) <= 1:
        raise ValueError("The last remaining program can't be deleted.")
    reg["programs"] = [p for p in reg["programs"] if p["key"] != key]
    if reg.get("active") == key:
        reg["active"] = reg["programs"][0]["key"]
    save_registry(reg)
    shutil.rmtree(ws_paths(key).dir, ignore_errors=True)
    return reg


def set_active(key: str) -> None:
    reg = load_registry()
    reg["active"] = key
    save_registry(reg)


def set_faults_path(path) -> None:
    reg = load_registry()
    reg["faults_path"] = path
    save_registry(reg)


# ---------------------------------------------------------------- small helpers
def fault_slug(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")[:50] or "fault"
    return f"{base}_{hashlib.md5(name.encode('utf-8')).hexdigest()[:6]}"


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return x


def rule_hash(versions_raw, bypasses=None) -> str:
    """Fingerprint of a fault's rule logic. Program 2 compares the fingerprint saved at
    Evaluate time with the live one to warn that the logic changed since. The ranges of any bypass a
    condition uses are part of the fingerprint, so editing a bypass also counts as a logic change."""
    def one(c):
        joiner = c.get("joiner") if c.get("joiner") == "OR" else "AND"
        if c.get("type") == "group":                    # sub-logic (brackets): fingerprint its contents too
            return {"type": "group", "joiner": joiner, "mode": c.get("mode") or "none",
                    "mode_value": _num(c.get("mode_value") or 0),
                    "conditions": [one(x) for x in c.get("conditions") or []]}
        d = {"column": c.get("column"), "op": c.get("op"), "value": _num(c.get("value")),
             "joiner": joiner, "mode": c.get("mode") or "none", "mode_value": _num(c.get("mode_value") or 0)}
        if c.get("op") in ("in", "not_in"):            # a bypass's ranges are part of the logic too
            bp = (bypasses or {}).get(c.get("bypass")) or {}
            d["bypass"] = {"id": c.get("bypass"), "versions": sorted(
                [{"effective_from": bv.get("effective_from") or None,
                  "ranges": [[_num(r.get("from")), _num(r.get("to"))] for r in bv.get("ranges") or []]}
                 for bv in bp.get("versions") or []],
                key=lambda x: x["effective_from"] or "")}
        return d

    norm = []
    for v in versions_raw or []:
        norm.append({"effective_from": v.get("effective_from") or None,
                     "conditions": [one(c) for c in v.get("conditions", [])]})
    norm.sort(key=lambda v: v["effective_from"] or "")
    return hashlib.md5(json.dumps(norm, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:12]


def normalize_feature_specs(cols):
    out = []
    for c in cols or []:
        if isinstance(c, str):
            out.append({"column": c, "tolerance": 0, "role": "diagnostic"})
        else:
            d = dict(c)
            d.setdefault("role", "diagnostic")
            out.append(d)
    return out


# ---------------------------------------------------------------- root-cause state (program 2's own file, per program)
def _fix_cluster(cl: dict) -> dict:
    if "description_versions" in cl:
        versions = cl.pop("description_versions")
        cl["description"] = versions[-1]["description"] if versions else ""
    cl.setdefault("description", "")
    return cl


def rc_state_load(key: str) -> dict:
    """Loads a program's rootcause_state.json. First time only, imports any pattern groups / labels that
    an older version stored inside fdd_settings.json."""
    p = ws_paths(key)
    st = read_json(p.rc_state, None)
    if st is None:
        st = {"faults": {}}
        old = read_json(p.settings, {}) or {}
        for fault, spec in (old.get("rules") or {}).items():
            moved = {k: spec[k] for k in RC_KEYS if k in spec}
            if moved:
                moved["clusters"] = [_fix_cluster(c) for c in moved.get("clusters", [])]
                st["faults"][fault] = moved
        p.dir.mkdir(parents=True, exist_ok=True)
        atomic_write_json(p.rc_state, st)
    st.setdefault("faults", {})
    return st


def rc_state_save(key: str, st: dict) -> None:
    atomic_write_json(ws_paths(key).rc_state, st)


# ---------------------------------------------------------------- handoff: program 1 -> program 2
def _clean(v):
    return None if v is None or (isinstance(v, float) and v != v) else v


def write_handoff(key, fault, result, versions_raw, params, mapping, plc_rows, bypasses=None) -> None:
    """Called by program 1 every time a fault is evaluated (all machines). Saves what program 2 needs:
    the real events and how each one lined up with the rule's predicted intervals."""
    p = ws_paths(key)
    p.handoff.mkdir(parents=True, exist_ok=True)
    slug = fault_slug(fault)
    atomic_to_csv(result["matched_events"], p.handoff / f"{slug}.matched.csv")
    atomic_to_csv(result["intervals"], p.handoff / f"{slug}.intervals.csv")
    manifest = read_json(p.manifest, None) or {}
    manifest.setdefault("faults", {})
    now = datetime.now().isoformat(timespec="seconds")
    manifest["updated_at"] = now
    manifest["mapping"] = mapping
    manifest["faults"][fault] = {
        "slug": slug, "evaluated_at": now, "rule_hash": rule_hash(versions_raw, bypasses), "params": params,
        "plc_rows": int(plc_rows), "machine_aware": "machine" in result["matched_events"].columns,
        "machines_without_plc": result.get("machines_without_plc", []),
        "counts": {k: _clean(result.get(k)) for k in ("tp", "fp", "fn", "no_data", "precision", "recall", "f1")},
        "ground_truth": int(len(result["matched_events"])),
    }
    atomic_write_json(p.manifest, manifest)


def read_manifest(key: str) -> dict:
    return read_json(ws_paths(key).manifest, None) or {}


def read_handoff(key: str, slug: str):
    p = ws_paths(key)
    m = pd.read_csv(p.handoff / f"{slug}.matched.csv")
    iv = pd.read_csv(p.handoff / f"{slug}.intervals.csv")
    for c in ("coming", "going"):
        if c in m.columns:
            m[c] = pd.to_datetime(m[c], errors="coerce")
    for c in ("start", "end"):
        if c in iv.columns:
            iv[c] = pd.to_datetime(iv[c], errors="coerce")
    if "machine" in m.columns:
        m["machine"] = m["machine"].astype(str).str.strip()
    return m, iv.reset_index(drop=True)


# ---------------------------------------------------------------- flask helpers (page, logo)
LOGO_JS = r"""
(function(){
  const img = document.getElementById('logoImg'), add = document.getElementById('logoAdd'),
        file = document.getElementById('logoFile'), wrap = document.getElementById('logoWrap');
  function show(has){ img.hidden = !has; add.hidden = has; wrap.classList.toggle('has-logo', has); }
  img.addEventListener('load', ()=>show(true));
  img.addEventListener('error', ()=>show(false));
  if(img.complete) show(img.naturalWidth > 0);
  add.addEventListener('click', ()=>file.click());
  img.title = 'Double-click to change the logo';
  img.addEventListener('dblclick', ()=>file.click());
  file.addEventListener('change', async ()=>{
    if(!file.files.length) return;
    const fd = new FormData(); fd.append('logo', file.files[0]);
    let r; try{ r = await (await fetch('/api/logo', {method:'POST', body:fd})).json(); } catch(e){ r = {ok:false, error:e.message}; }
    if(r.ok){ const u = '/logo?'+Date.now(); img.src = u; document.querySelectorAll('link[rel=icon]').forEach(l=>l.href = u); }
    else alert(r.error || 'Could not save the logo.');
    file.value = '';
  });
})();
"""


def serve_page(html: str):
    from flask import Response
    return Response(html.replace("/*THEME*/", THEME_CSS).replace("/*LOGOJS*/", LOGO_JS), mimetype="text/html")


def register_logo(app) -> None:
    """GET /logo serves static/logo.(svg|png|jpg|webp); POST /api/logo saves a new one (the 'Add logo' button)."""
    from flask import jsonify, request, send_file

    @app.route("/logo")
    def logo():
        for name in ("logo.svg", "logo.png", "logo.jpg", "logo.jpeg", "logo.webp"):
            p = APP_DIR / "static" / name
            if p.exists():
                r = send_file(p)
                r.headers["Cache-Control"] = "no-cache"
                r.headers["Content-Security-Policy"] = "default-src 'none'; style-src 'unsafe-inline'; sandbox"
                return r
        return ("", 404)

    @app.route("/api/logo", methods=["POST"])
    def upload_logo():
        f = request.files.get("logo")
        if not f or not f.filename:
            return jsonify(ok=False, error="No file received."), 400
        ext = Path(f.filename).suffix.lower()
        if ext not in (".png", ".jpg", ".jpeg", ".svg", ".webp"):
            return jsonify(ok=False, error="Please choose a .png, .jpg, .svg or .webp file."), 400
        data = f.read()
        if len(data) > 2 * 1024 * 1024:
            return jsonify(ok=False, error="That logo is larger than 2 MB."), 400
        d = APP_DIR / "static"
        d.mkdir(exist_ok=True)
        for old in d.glob("logo.*"):
            try:
                old.unlink()
            except OSError:
                pass
        (d / f"logo{ext}").write_bytes(data)
        return jsonify(ok=True)


def run_server(app, port: int, title: str) -> None:
    if "--no-browser" not in sys.argv:
        threading.Timer(1.3, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
    print(f"Starting {title} -> http://127.0.0.1:{port}")
    print("To stop it, close this window or press Ctrl+C.")
    app.run(host="127.0.0.1", port=port, debug=False)
