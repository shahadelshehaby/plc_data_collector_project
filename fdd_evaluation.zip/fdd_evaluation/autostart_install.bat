@echo off
cd /d "%~dp0"
schtasks /create /tn "FDD Platform - Evaluation" /tr "\"%~dp0start_background.bat\"" /sc onlogon /rl limited /f
if errorlevel 1 (echo Could not create the task. Try right-click - Run as administrator.) else (echo Done. Evaluation and the NAS sync will start when you sign in to Windows.)
pause
