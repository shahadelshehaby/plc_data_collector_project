# FDD Evaluation (port 5120)

Replicates your PLC fault logic, backtests it against the real fault history, and reports hits, misses and false
alarms per terminal / type / machine. Decision support only — no PLC connection, nothing is written to a PLC.

## Start
Double-click `run.bat` (Python 3.9+). To start with Windows, run `autostart_install.bat` once.

## Tabs
1. **Files** – master list (one-time Excel), fault history (manual upload). PLC files are optional now: the NAS feeds PLC data.
2. **Settings** – column mapping, matching, and the **NAS sync** panel (InfluxDB address, token, sync interval, machine → terminal / PLC type with dates).
3. **Logic** – rule logic per fault; copy / move a logic to another terminal / type.
4. **Evaluate** – pick terminals, types, machines; results saved for Root Cause.

## NAS sync
Every N minutes (Settings, default 30) the app reads only new rows from InfluxDB (read-only), converts UTC to Dubai time,
files them under the machine's terminal / PLC type, then runs Evaluation for the programs that got rows. Late rows are
caught by a short overlap re-read; rows already stored are skipped. Runs while the app is open.

## Files this program writes
`programs.json`, `programs/<key>/{fdd_settings.json, plc_data_store.csv, handoff/}`, `nas_config.json` (contains the token – keep private),
`nas_state.json`, `activity/`. The separate Root Cause project reads `handoff/` and the PLC store, and never writes here.

Colours/fonts: top of `fdd_theme.py`. Logo: `static/logo.png`.
