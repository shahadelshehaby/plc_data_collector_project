"""
PROGRAM 1 of 2 — FDD Rule Builder & Backtester (port 5120): Files, Settings, Bypass, Logic, Evaluate.
Root cause analysis is the separate program rootcause_app.py (port 5001).

FDD Rule Builder & Backtester — local web app backend.

Runs entirely on your own machine (127.0.0.1) — nothing is sent anywhere
else. Decision-support / validation tool only: it does not read from or
write to any PLC, and does not touch control or safety logic.
"""
import sys
if sys.version_info < (3, 9):
    print("=" * 60)
    print(f"This tool needs Python 3.9 or newer. You have {sys.version.split()[0]}.")
    print("Download the latest version from https://python.org/downloads")
    print("and make sure to check 'Add Python to PATH' during install.")
    print("=" * 60)
    input("Press Enter to close...")
    sys.exit(1)

import io
import json
import re
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, request, jsonify, send_file, Response

import fdd_core as core
import threading

import building_status as bs
import nas_sync
from fdd_common import (APP_DIR, PORT_RULE_BUILDER, RC_KEYS, atomic_to_csv, create_program, delete_program, load_registry,
                        program_label, rc_state_load, rc_state_save, read_json, register_logo, run_server, serve_page, set_active,
                        set_faults_path, write_handoff, ws_paths)


DEFAULT_SETTINGS = {
    "paths": {"master": None, "plc": [], "faults": None},
    "mapping": {
        "master_desc_col": None, "plc_ts_col": None, "plc_machine_col": None, "signal_cols": [],
        "faults_come_col": None, "faults_go_col": None, "faults_desc_col": None, "faults_machine_col": None,
        "tolerance_seconds": 1, "max_gap_seconds": 2, "min_duration_seconds": 0,
    },
    "rules": {},
    "bypasses": {},   # named range lists for this terminal / type: {id: {name, description, versions:[{id, effective_from, ranges}]}}
    "meta": {},   # filled in when settings are saved: the machines found in this program's PLC data
}


def _migrate_rules(rules: dict) -> dict:
    """Upgrade old formats saved by earlier versions of this tool:
    feature_columns from plain strings to {"column": str, "tolerance": 0, "role": "diagnostic"},
    and any leftover versioned "description_versions" back to a flat "description"
    (using the most recently-added entry) since dated root-cause history was removed."""
    for spec in rules.values():
        cols = spec.get("feature_columns")
        if cols and isinstance(cols[0], str):
            spec["feature_columns"] = [{"column": c, "tolerance": 0, "role": "diagnostic"} for c in cols]
        elif cols:
            for c in cols:
                c.setdefault("role", "diagnostic")
        spec.pop("labels", None)  # old classifier-based labels are no longer used
        for cl in spec.get("clusters", []):
            if "description_versions" in cl:
                versions = cl.pop("description_versions")
                cl["description"] = versions[-1]["description"] if versions else ""
            else:
                cl.setdefault("description", "")
    return rules


def load_settings(path) -> dict:
    if path.exists():
        try:
            saved = json.loads(path.read_text(encoding="utf-8"))
            merged = json.loads(json.dumps(DEFAULT_SETTINGS))  # deep copy
            merged.update({k: v for k, v in saved.items() if k in merged})
            if "mapping" in saved:
                merged["mapping"].update(saved["mapping"])
            if "paths" in saved:
                merged["paths"].update(saved["paths"])
            p = merged["paths"].get("plc")  # older versions stored a single path string
            merged["paths"]["plc"] = [p] if isinstance(p, str) and p else (p if isinstance(p, list) else [])
            if "rules" in merged:
                merged["rules"] = _migrate_rules(merged["rules"])
            return merged
        except Exception:  # noqa: BLE001
            pass
    return json.loads(json.dumps(DEFAULT_SETTINGS))


def save_settings(settings: dict) -> None:
    tmp = SETTINGS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(settings, indent=2, default=str), encoding="utf-8")
    tmp.replace(SETTINGS_PATH)


# --------------------------------------------------------------------------
# Programs = terminal + type. Each one is its own workspace (master list, PLC files, mapping, rules,
# stored PLC data). The module-level SETTINGS / STATE / SETTINGS_PATH / PLC_STORE_PATH always point at the
# ACTIVE program; activate_program() re-points them, so every endpoint below works on "the current program".
# --------------------------------------------------------------------------
WS_LOCK = threading.RLock()
WS_CACHE = {}                    # program key -> {"SETTINGS": ..., "STATE": ...}
SHARED = {"faults_raw": None}    # the fault history is ONE file shared by every program
CURRENT = {"key": None}
LAST_RESULTS = {}                # (program key, fault) -> evaluation result, for the CSV exports
SETTINGS = json.loads(json.dumps(DEFAULT_SETTINGS))
STATE = {}
SETTINGS_PATH = None
PLC_STORE_PATH = None


def _new_state():
    return {
        "master_df": None, "plc_df": None, "faults_df": SHARED["faults_raw"],
        "plc_raws": {},  # path -> raw DataFrame for every PLC file loaded this session
        "plc_ts_col": None, "plc_machine_col": None, "faults_machine_col": None, "signal_cols": [],
        "faults_come_col": None, "faults_go_col": None, "faults_desc_col": None,
        "applied": False,
    }


def _stamp_rules(key, settings) -> bool:
    """Every logic carries the terminal and PLC type it belongs to (so a copy of the settings file is self-explanatory).
    Older logics, saved before this existed, are stamped the first time their program is opened. Returns True if
    anything changed."""
    p = next((q for q in load_registry()["programs"] if q["key"] == key), None)
    changed = False
    if p:
        for spec in (settings.get("rules") or {}).values():
            if spec.get("terminal") != p["terminal"] or spec.get("type") != p["type"]:
                spec["terminal"], spec["type"] = p["terminal"], p["type"]
                changed = True
    return changed


def activate_program(key):
    global SETTINGS, STATE, SETTINGS_PATH, PLC_STORE_PATH
    with WS_LOCK:
        paths = ws_paths(key)
        first = key not in WS_CACHE
        if first:
            paths.dir.mkdir(parents=True, exist_ok=True)
            WS_CACHE[key] = {"SETTINGS": load_settings(paths.settings), "STATE": _new_state()}
        SETTINGS, STATE = WS_CACHE[key]["SETTINGS"], WS_CACHE[key]["STATE"]
        SETTINGS_PATH, PLC_STORE_PATH, CURRENT["key"] = paths.settings, paths.plc_store, key
        if first:
            # Root-cause state (pattern groups, labels) belongs to program 2 and lives in its own file. Older
            # versions kept it inside the rules: copy it across once, then keep it out of the rules, so saving
            # a rule here can never overwrite a label made there.
            rc_state_load(key)
            if any(k in spec for spec in SETTINGS["rules"].values() for k in RC_KEYS):
                for _spec in SETTINGS["rules"].values():
                    for _k in RC_KEYS:
                        _spec.pop(_k, None)
                save_settings(SETTINGS)
            if _stamp_rules(key, SETTINGS):
                save_settings(SETTINGS)


activate_program(load_registry()["active"])


def df_info(df: pd.DataFrame) -> dict:
    numeric_cols = list(df.select_dtypes(include=[np.number]).columns)
    sample = json.loads(df.head(5).astype(str).to_json(orient="records"))
    return {"columns": list(df.columns), "numeric_columns": numeric_cols, "rows": len(df), "sample": sample}


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024 * 1024  # 1 GB
register_logo(app)
try:
    bs.register(app)     # GET /building/status for the Engineering Building dashboard
except Exception:        # noqa: BLE001  (the integration must never be able to stop the platform starting)
    traceback.print_exc()


@app.route("/")
def index():
    return serve_page(INDEX_HTML)


# --------------------------------------------------------------------------
# Settings persistence
# --------------------------------------------------------------------------

def _program_payload():
    reg = load_registry()
    return {"programs": [dict(p, label=program_label(p)) for p in reg["programs"]],
            "active": CURRENT["key"], "terminals": reg["terminals"]}


@app.route("/api/settings", methods=["GET"])
def api_get_settings():
    reg = load_registry()
    s = json.loads(json.dumps(SETTINGS))
    s["paths"]["faults"] = reg.get("faults_path")     # the fault history is shared by every program
    return jsonify(ok=True, settings=s, **_program_payload())


@app.route("/api/program/activate", methods=["POST"])
def api_program_activate():
    key = (request.get_json(force=True) or {}).get("key")
    if key not in {p["key"] for p in load_registry()["programs"]}:
        return jsonify(ok=False, error="Unknown terminal/type."), 400
    set_active(key)
    activate_program(key)
    return jsonify(ok=True, **_program_payload())


@app.route("/api/program/create", methods=["POST"])
def api_program_create():
    """Create a terminal/type (or open it if it already exists) and make it the active program."""
    b = request.get_json(force=True) or {}
    try:
        p, _reg = create_program(b.get("terminal"), b.get("type"))
    except ValueError as e:
        return jsonify(ok=False, error=str(e)), 400
    set_active(p["key"])
    activate_program(p["key"])
    return jsonify(ok=True, **_program_payload())


@app.route("/api/program/delete", methods=["POST"])
def api_program_delete():
    key = (request.get_json(force=True) or {}).get("key")
    try:
        reg = delete_program(key)
    except ValueError as e:
        return jsonify(ok=False, error=str(e)), 400
    WS_CACHE.pop(key, None)
    activate_program(reg["active"])
    return jsonify(ok=True, **_program_payload())


@app.route("/api/scope")
def api_scope():
    """What the Evaluate tab can pick from: every program with its machines."""
    out = []
    for p in load_registry()["programs"]:
        ws = WS_CACHE.get(p["key"])
        s = ws["SETTINGS"] if ws else (read_json(ws_paths(p["key"]).settings, {}) or {})
        m = s.get("mapping") or {}
        out.append(dict(_prog_fields(p), key=p["key"], machines=(s.get("meta") or {}).get("machines", []),
                        configured=bool(m.get("plc_ts_col") and m.get("signal_cols")),
                        faults=sum(1 for sp in (s.get("rules") or {}).values() if sp.get("versions"))))
    return jsonify(ok=True, programs=out)


def _bypass_refs(rules) -> dict:
    """{bypass id: sorted list of faults} for every IN / NOT IN condition in these rules."""
    refs = {}
    for fault, spec in (rules or {}).items():
        for v in spec.get("versions") or []:
            for c in core.leaf_conditions(v.get("conditions")):
                if c.get("op") in core.BYPASS_OPS:
                    refs.setdefault(c.get("bypass") or "", set()).add(fault)
    return {k: sorted(v) for k, v in refs.items()}


def _carry_bypasses(spec: dict, src_bypasses: dict, dst_settings: dict) -> list:
    """Bypasses belong to one terminal / type. When a logic is copied to another one, every bypass it uses is
    matched there BY NAME (same name = the target's own ranges are used), or copied across if the target has
    no bypass with that name. Rewrites the condition ids in `spec` in place; returns the names copied across."""
    dst = dst_settings.setdefault("bypasses", {})
    by_name = {str(b.get("name", "")).strip().lower(): bid for bid, b in dst.items()}
    remap, copied = {}, []
    for v in spec.get("versions") or []:
        for c in core.leaf_conditions(v.get("conditions")):
            if c.get("op") not in core.BYPASS_OPS:
                continue
            old = c.get("bypass")
            if old not in remap:
                src = src_bypasses.get(old)
                key = str((src or {}).get("name", "")).strip().lower()
                if src is None:
                    remap[old] = old
                elif key in by_name:
                    remap[old] = by_name[key]
                else:
                    new_id = old if old not in dst else f"{old}_{len(dst) + 1}"
                    dst[new_id] = json.loads(json.dumps(src))
                    by_name[key] = new_id
                    remap[old] = new_id
                    copied.append(src.get("name"))
            c["bypass"] = remap[old]
    return copied


@app.route("/api/save_settings", methods=["POST"])
def api_save_settings():
    body = request.get_json(force=True)
    new_rules = body["rules"] if "rules" in body else SETTINGS["rules"]
    new_bypasses = body["bypasses"] if "bypasses" in body else (SETTINGS.get("bypasses") or {})
    broken = {bid: faults for bid, faults in _bypass_refs(new_rules).items() if bid not in new_bypasses}
    if broken:
        faults = sorted({f for fs in broken.values() for f in fs})
        return jsonify(ok=False, error="Not saved: these faults use a bypass that does not exist (pick one in their "
                                       "IN / NOT IN condition): " + ", ".join(faults[:6]) + (" …" if len(faults) > 6 else "")), 400
    if "mapping" in body:
        SETTINGS["mapping"] = body["mapping"]
    if "rules" in body:
        SETTINGS["rules"] = body["rules"]
    if "bypasses" in body:
        SETTINGS["bypasses"] = body["bypasses"]
    if "paths" in body:
        SETTINGS["paths"].update(body["paths"])
    _stamp_rules(CURRENT["key"], SETTINGS)
    save_settings(SETTINGS)
    return jsonify(ok=True)


# --------------------------------------------------------------------------
# File selection / loading
# --------------------------------------------------------------------------

@app.route("/api/pick_file", methods=["POST"])
def api_pick_file():
    body = request.get_json(force=True)
    role = body.get("role", "file")
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(
            title=f"Select {role} file",
            filetypes=[("Data files", "*.xlsx *.xls *.csv"), ("All files", "*.*")],
        )
        root.destroy()
        if not path:
            return jsonify(ok=False, error="No file selected.")
        return jsonify(ok=True, path=path)
    except Exception as e:  # noqa: BLE001
        return jsonify(ok=False, error=f"Couldn't open a file browser here ({e}). Type the full file path in the box instead.")


def _mapped(name):
    return STATE.get(name) or SETTINGS["mapping"].get(name)


def _plc_columns():
    """Union of columns (and numeric columns) across every PLC file loaded,
    or — when none are loaded this session — whatever the stored data has."""
    cols, numeric = [], []
    frames = list(STATE["plc_raws"].values())
    if not frames and PLC_STORE_PATH.exists():
        frames = [pd.read_csv(PLC_STORE_PATH, nrows=5000)]
    for df in frames:
        for c in df.columns:
            if c not in cols:
                cols.append(c)
        for c in df.select_dtypes(include=[np.number]).columns:
            if c not in numeric:
                numeric.append(c)
    return cols, numeric


@app.route("/api/load_from_path", methods=["POST"])
def api_load_from_path():
    body = request.get_json(force=True)
    role, path = body.get("role"), body.get("path")
    if role not in ("master", "plc", "faults"):
        return jsonify(ok=False, error="invalid role"), 400
    if not path or not Path(path).exists():
        return jsonify(ok=False, error="File not found at that location (it may have moved) — browse for it again.")
    try:
        df = core.read_table(path)
    except Exception as e:  # noqa: BLE001
        return jsonify(ok=False, error=str(e))
    if df.empty or df.shape[1] == 0:
        return jsonify(ok=False, error="File parsed but contains no usable rows/columns.")
    if role == "plc":
        # one PLC file per machine is the normal case, so PLC files accumulate
        STATE["plc_raws"][path] = df
        paths = list(SETTINGS["paths"].get("plc") or [])
        if path not in paths:
            paths.append(path)
        SETTINGS["paths"]["plc"] = paths
        save_settings(SETTINGS)
        columns, numeric = _plc_columns()
        return jsonify(ok=True, path=path, rows=len(df), columns=columns, numeric_columns=numeric, n_files=len(STATE["plc_raws"]))
    if role == "faults":   # ONE fault history, shared by every terminal/type program
        SHARED["faults_raw"] = df
        set_faults_path(path)
        for ws in WS_CACHE.values():
            ws["STATE"]["faults_df"] = df
            ws["STATE"]["applied"] = False     # re-apply each program's settings against the new history
        return jsonify(ok=True, path=path, **df_info(df))
    STATE["master_df"] = df                    # the master list belongs to the active program only
    SETTINGS["paths"]["master"] = path
    save_settings(SETTINGS)
    return jsonify(ok=True, path=path, **df_info(df))


@app.route("/api/plc_path/remove", methods=["POST"])
def api_plc_path_remove():
    path = (request.get_json(force=True) or {}).get("path")
    STATE["plc_raws"].pop(path, None)
    SETTINGS["paths"]["plc"] = [p for p in (SETTINGS["paths"].get("plc") or []) if p != path]
    save_settings(SETTINGS)
    columns, numeric = _plc_columns()
    return jsonify(ok=True, columns=columns, numeric_columns=numeric, n_files=len(STATE["plc_raws"]))


# --------------------------------------------------------------------------
# Stored PLC data: view / delete
# --------------------------------------------------------------------------

@app.route("/api/plc_store/view", methods=["GET"])
def api_plc_store_view():
    if not PLC_STORE_PATH.exists():
        return jsonify(ok=True, exists=False)
    df = pd.read_csv(PLC_STORE_PATH)
    ts_col, machine_col = _mapped("plc_ts_col"), _mapped("plc_machine_col")
    info = {"exists": True, "total_rows": len(df), "columns": list(df.columns),
            "numeric_columns": list(df.select_dtypes(include=[np.number]).columns),
            "file_size_mb": round(PLC_STORE_PATH.stat().st_size / (1024 * 1024), 2)}
    if ts_col and ts_col in df.columns:
        ts = pd.to_datetime(df[ts_col], errors="coerce")
        info["date_min"] = str(ts.min()) if ts.notna().any() else None
        info["date_max"] = str(ts.max()) if ts.notna().any() else None
    if machine_col and machine_col in df.columns:
        by_machine = []
        for name, g in df.groupby(df[machine_col].astype(str).str.strip()):
            entry = {"machine": name, "rows": len(g)}
            if ts_col and ts_col in g.columns:
                ts = pd.to_datetime(g[ts_col], errors="coerce")
                entry["date_min"] = str(ts.min()) if ts.notna().any() else None
                entry["date_max"] = str(ts.max()) if ts.notna().any() else None
            by_machine.append(entry)
        info["by_machine"] = sorted(by_machine, key=lambda e: e["machine"])
    return jsonify(ok=True, **info)


@app.route("/api/plc_store/clear", methods=["POST"])
def api_plc_store_clear():
    """Deletes ALL stored PLC data, or just one machine's when {"machine": ...} is given."""
    body = request.get_json(silent=True) or {}
    machine = body.get("machine")
    if not PLC_STORE_PATH.exists():
        return jsonify(ok=True, removed=0)
    df = pd.read_csv(PLC_STORE_PATH)
    machine_col = _mapped("plc_machine_col")
    if machine and machine_col and machine_col in df.columns:
        keep = df[df[machine_col].astype(str).str.strip() != str(machine).strip()]
        removed = len(df) - len(keep)
        if len(keep):
            atomic_to_csv(keep, PLC_STORE_PATH)
        else:
            PLC_STORE_PATH.unlink()
    else:
        removed = len(df)
        PLC_STORE_PATH.unlink()
    STATE["plc_df"] = None  # the next Save/Apply rebuilds it from what's left
    return jsonify(ok=True, removed=removed)


# --------------------------------------------------------------------------
# Column mapping -> build workspace
# --------------------------------------------------------------------------

@app.route("/api/configure", methods=["POST"])
def api_configure():
    return _configure(request.get_json(force=True))


def _configure(body):
    """Build the ACTIVE program's workspace from a column mapping. Evaluate also calls this to prepare
    a program that isn't the one on screen (or after a restart)."""
    with bs.job("Applying settings and merging PLC data"):
        result = _configure_impl(body)
    if isinstance(result, tuple) and result[1] >= 400:
        bs.record_error(result[0].get_json().get("error", "settings error"))
    return result


def _configure_impl(body):
    try:
        faults, master = STATE["faults_df"], STATE["master_df"]
        raws = list(STATE["plc_raws"].items())
        missing = [n for n, v in (("the master list", master), ("the fault history", faults)) if v is None]
        if not raws and not PLC_STORE_PATH.exists():
            missing.append("PLC data (run “Sync now” in the NAS box on the Files tab)")
        if missing:
            return jsonify(ok=False, error="Still needed on the Files tab: " + ", ".join(missing) + "."), 400

        ts_col = body["plc_ts_col"]
        machine_col = body.get("plc_machine_col") or None
        signal_cols = body["signal_cols"]
        come_col = body["faults_come_col"]
        go_col = body.get("faults_go_col") or None
        desc_col = body["faults_desc_col"]
        faults_machine_col = body.get("faults_machine_col") or None
        master_desc_col = body["master_desc_col"]

        # Every PLC file loaded this session is merged into the permanent
        # store (duplicates by machine+timestamp are skipped, never overwritten).
        n_bad_plc = added = skipped = 0
        if raws:
            merged = None
            for path, raw in raws:
                missing = [c for c in (ts_col, machine_col) if c and c not in raw.columns]
                if missing:
                    return jsonify(ok=False, error=f"{Path(path).name} has no column named {', '.join(repr(m) for m in missing)} — every PLC file needs the same timestamp/machine column names."), 400
                d = raw.copy()
                d[ts_col] = core.to_datetime_series(d[ts_col])
                n_bad_plc += int(d[ts_col].isna().sum())
                d = d.dropna(subset=[ts_col]).reset_index(drop=True)
                if machine_col:
                    d[machine_col] = d[machine_col].astype(str).str.strip()
                r = core.merge_plc_store(PLC_STORE_PATH, d, ts_col, machine_col)
                added += r["added"]
                skipped += r["skipped_duplicates"]
                merged = r["merged"]
            plc = merged
        else:
            plc = pd.read_csv(PLC_STORE_PATH)
            plc[ts_col] = core.to_datetime_series(plc[ts_col])
            plc = plc.dropna(subset=[ts_col]).sort_values(ts_col).reset_index(drop=True)
        if machine_col and machine_col in plc.columns:
            plc[machine_col] = plc[machine_col].astype(str).str.strip()

        faults = faults.copy()
        faults[come_col] = core.to_datetime_series(faults[come_col])
        n_bad_f = int(faults[come_col].isna().sum())
        if go_col:
            faults[go_col] = core.to_datetime_series(faults[go_col])
        if faults_machine_col:
            if faults_machine_col not in faults.columns:
                return jsonify(ok=False, error=f"The fault history has no column named {faults_machine_col!r}."), 400
            faults[faults_machine_col] = faults[faults_machine_col].astype(str).str.strip()
        faults = faults.dropna(subset=[come_col]).reset_index(drop=True)

        warnings = []
        if bool(machine_col) != bool(faults_machine_col):
            warnings.append("Only one of the PLC / fault-history machine columns is set, so machines are NOT being kept apart. Set both (or neither).")
        if machine_col and faults_machine_col and machine_col in plc.columns:
            only_faults = sorted(set(faults[faults_machine_col].unique()) - set(plc[machine_col].unique()))
            if only_faults:
                warnings.append("The fault history mentions machines with no stored PLC data: " + ", ".join(only_faults[:8]) + (" …" if len(only_faults) > 8 else "") + ". Their events will show as 'No PLC data'.")

        STATE.update({
            "plc_df": plc, "faults_df": faults,
            "plc_ts_col": ts_col, "plc_machine_col": machine_col, "signal_cols": signal_cols,
            "faults_come_col": come_col, "faults_go_col": go_col, "faults_desc_col": desc_col,
            "faults_machine_col": faults_machine_col, "applied": True,
        })

        master_faults = sorted({m for m in master[master_desc_col].astype(str).str.strip() if m})
        for fname in master_faults:
            if fname not in SETTINGS["rules"]:
                SETTINGS["rules"][fname] = {"versions": []}
        _stamp_rules(CURRENT["key"], SETTINGS)

        SETTINGS["mapping"] = {
            "master_desc_col": master_desc_col, "plc_ts_col": ts_col, "plc_machine_col": machine_col, "signal_cols": signal_cols,
            "faults_come_col": come_col, "faults_go_col": go_col, "faults_desc_col": desc_col, "faults_machine_col": faults_machine_col,
            "tolerance_seconds": body.get("tolerance_seconds", 1),
            "max_gap_seconds": body.get("max_gap_seconds", 2),
            "min_duration_seconds": body.get("min_duration_seconds", 0),
        }
        SETTINGS["meta"] = {"machines": sorted(plc[machine_col].astype(str).unique().tolist()) if machine_col and machine_col in plc.columns else []}
        save_settings(SETTINGS)

        return jsonify(
            ok=True,
            master_faults=master_faults,
            signal_cols=signal_cols,
            rules=SETTINGS["rules"],
            warnings=warnings,
            stats={
                "plc_rows": len(plc), "event_rows": len(faults), "master_rows": len(master_faults),
                "plc_bad_ts": n_bad_plc, "event_bad_ts": n_bad_f,
                "plc_rows_added": added, "plc_rows_skipped_duplicate": skipped,
                "plc_machines": int(plc[machine_col].nunique()) if machine_col and machine_col in plc.columns else None,
            },
        )
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify(ok=False, error=str(e)), 400


# --------------------------------------------------------------------------
# Evaluation
# --------------------------------------------------------------------------

def _ground_truth_for(fault: str) -> pd.DataFrame:
    faults = STATE["faults_df"]
    desc_col, come_col, go_col = STATE["faults_desc_col"], STATE["faults_come_col"], STATE["faults_go_col"]
    machine_col = STATE.get("faults_machine_col")
    target = fault.strip().lower()
    sel = faults[desc_col].astype(str).str.strip().str.lower() == target
    coming = faults.loc[sel, come_col]
    going = faults.loc[sel, go_col] if go_col else coming
    out = pd.DataFrame({"coming": coming.values, "going": going.values})
    if machine_col and machine_col in faults.columns:
        out["machine"] = faults.loc[sel, machine_col].astype(str).str.strip().values
    return out


def _versions_from_body(versions_raw):
    return [{
        "effective_from": pd.to_datetime(v["effective_from"]) if v.get("effective_from") else None,
        "conditions": v["conditions"],
    } for v in versions_raw]


def _run_fault_scoped(plc, ts_col, versions, max_gap, min_dur, ground_truth, tolerance, only_machines=None, bypasses=None,
                      keep_from=None):
    """core.run_fault, run once PER MACHINE when the PLC data and the fault
    history both carry a machine column, then combined.

    Why this matters for correctness: interval detection groups contiguous
    rows by timestamp alone. With several machines in one table, a reading
    on one machine could be merged into, or hide a false positive on,
    another machine. Splitting first keeps every machine's timeline and
    events isolated. Every machine with PLC data is evaluated (a machine
    with no real events can still produce false positives), and a machine
    that has fault events but no PLC data at all is reported as 'no_data'.

    The combined result carries a 'machine' column everywhere, and
    matched_interval_idx is re-based so it still indexes the combined
    'intervals' table.
    """
    plc_machine_col = STATE.get("plc_machine_col")
    if not (plc_machine_col and plc_machine_col in plc.columns and "machine" in ground_truth.columns):
        res = core.run_fault(plc, ts_col, versions, max_gap, min_dur, ground_truth.drop(columns=["machine"], errors="ignore"), tolerance, bypasses,
                             keep_from=keep_from)
        res["machines_without_plc"] = []
        return res

    norm_plc = plc[plc_machine_col].astype(str).str.strip()
    gt = ground_truth.copy()
    gt["machine"] = gt["machine"].astype(str).str.strip()
    machines = sorted(set(gt["machine"].unique()) | set(norm_plc.unique()))
    if only_machines:                       # evaluate just the machines the user picked
        machines = [m for m in machines if m in only_machines]

    tp = fp = fn = no_data = 0
    matched_parts, extra_parts, interval_parts, without_plc = [], [], [], []
    offset = 0
    for m in machines:
        gt_m = gt.loc[gt["machine"] == m].drop(columns=["machine"]).reset_index(drop=True)
        plc_m = plc.loc[norm_plc == m]
        if plc_m.empty:
            without_plc.append(m)
            g = gt_m.copy()
            g["matched_interval_idx"] = np.nan
            g["delta_seconds"] = np.nan
            g["status"] = "no_data"
            g["machine"] = m
            no_data += len(g)
            matched_parts.append(g)
            continue
        r = core.run_fault(plc_m, ts_col, versions, max_gap, min_dur, gt_m, tolerance, bypasses, keep_from=keep_from)
        tp += r["tp"]; fp += r["fp"]; fn += r["fn"]; no_data += r["no_data"]
        me = r["matched_events"].copy()
        me["matched_interval_idx"] = pd.to_numeric(me["matched_interval_idx"], errors="coerce") + offset
        me["machine"] = m
        ex = r["extra_intervals"].copy(); ex["machine"] = m
        iv = r["intervals"].copy(); iv["machine"] = m
        offset += len(r["intervals"])
        matched_parts.append(me); extra_parts.append(ex); interval_parts.append(iv)

    precision = tp / (tp + fp) if (tp + fp) else None
    recall = tp / (tp + fn) if (tp + fn) else None
    f1 = (2 * precision * recall / (precision + recall)) if precision and recall and (precision + recall) > 0 else None
    empty_iv = pd.DataFrame(columns=["start", "end", "machine"])
    return {
        "tp": tp, "fp": fp, "fn": fn, "no_data": no_data,
        "precision": precision, "recall": recall, "f1": f1,
        "matched_events": pd.concat(matched_parts, ignore_index=True) if matched_parts else gt.iloc[0:0],
        "extra_intervals": pd.concat(extra_parts, ignore_index=True) if extra_parts else empty_iv,
        "intervals": pd.concat(interval_parts, ignore_index=True) if interval_parts else empty_iv,
        "machines_without_plc": without_plc,
    }


def _handoff(fault, result, versions_raw, tolerance, max_gap, min_dur, bypasses=None, window=None):
    """Save this evaluation where the Root Causes program will find it (in this program's handoff folder)."""
    try:
        write_handoff(
            CURRENT["key"], fault, result, versions_raw,
            {"tolerance_seconds": tolerance, "max_gap_seconds": max_gap, "min_duration_seconds": min_dur,
             "date_from": _day(window, 0), "date_to": _day(window, 1)},
            {"plc_ts_col": STATE["plc_ts_col"], "plc_machine_col": STATE.get("plc_machine_col"),
             "faults_machine_col": STATE.get("faults_machine_col")},
            len(STATE["plc_df"]),
            bypasses=bypasses,
        )
    except Exception:  # noqa: BLE001  (a handoff problem must never break Evaluate itself)
        traceback.print_exc()


def _prog_fields(p):
    return {"program": p["key"], "terminal": p["terminal"], "type": p["type"], "program_label": program_label(p)}


def ensure_ready(key):
    """Make sure program `key` has its data loaded and its saved settings applied (it may not be the one on
    screen, or the app may just have restarted). Leaves `key` active. Returns (ok, error message)."""
    activate_program(key)
    if STATE.get("applied"):
        return True, None
    m = SETTINGS.get("mapping") or {}
    if not (m.get("master_desc_col") and m.get("plc_ts_col") and m.get("faults_come_col") and m.get("faults_desc_col") and m.get("signal_cols")):
        return False, "Settings haven't been saved for this program yet (Settings tab, then Save settings)."
    try:
        if STATE.get("master_df") is None:
            p = SETTINGS["paths"].get("master")
            if not (p and Path(p).exists()):
                return False, "This program's master list can't be found. Load it again on the Files tab."
            STATE["master_df"] = core.read_table(p)
        if STATE.get("faults_df") is None:
            fp = load_registry().get("faults_path")
            if not (fp and Path(fp).exists()):
                return False, "The fault history file can't be found. Load it again on the Files tab."
            SHARED["faults_raw"] = core.read_table(fp)
            for ws in WS_CACHE.values():
                if ws["STATE"].get("faults_df") is None:
                    ws["STATE"]["faults_df"] = SHARED["faults_raw"]
        resp = _configure(dict(m))
        data = (resp[0] if isinstance(resp, tuple) else resp).get_json()
        return (True, None) if data.get("ok") else (False, data.get("error", "Could not prepare this program."))
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def _parse_window(frm, to):
    """Evaluate-tab dates ('YYYY-MM-DD', either may be blank) -> (start, end) Timestamps, end EXCLUSIVE (the day
    after the 'to' date, so the whole 'to' day is included). (None, None) = all data."""
    try:
        start = pd.Timestamp(frm) if frm else None
        end = pd.Timestamp(to) + pd.Timedelta(days=1) if to else None
    except (ValueError, TypeError):
        raise ValueError("The From / To dates could not be read.")
    if start is not None and end is not None and start >= end:
        raise ValueError("The From date must be on or before the To date.")
    return (start, end) if (start is not None or end is not None) else None


def _day(window, i):
    """A window's From (i=0) or To (i=1) date as 'YYYY-MM-DD' for display, or None."""
    if not window or window[i] is None:
        return None
    return str((window[1] - pd.Timedelta(days=1)).date()) if i == 1 else str(window[0].date())


def _warmup_seconds(versions_raw, max_gap):
    """How much PLC data BEFORE the From date to include, so a timer (on a condition or a sub-logic) that was
    already running at the start of the range counts the same as in a full run."""
    longest = 0.0
    for v in versions_raw:
        stack = list(v.get("conditions") or [])
        while stack:
            c = stack.pop()
            if c.get("mode") == "timer":
                longest = max(longest, float(c.get("mode_value") or 0))
            stack.extend(c.get("conditions") or [])
    return longest + float(max_gap or 0) + 1


def _evaluate_one(fault, only_machines, window=None):
    """Evaluate one fault in the ACTIVE program. Runs over all machines are also saved for Root Causes (a run
    limited to dates is saved too, and Root Causes shows which dates it covers).

    window: (start, end) from _parse_window, or None for all data. Only PLC rows from (start - warm-up) to end
    are evaluated, and only real events that overlap [start, end) are counted — this is what makes a short date
    range fast."""
    spec = SETTINGS["rules"].get(fault) or {}
    versions_raw = spec.get("versions") or []
    if not versions_raw:
        raise ValueError("Add at least one rule version first.")
    m = SETTINGS["mapping"]
    tolerance, max_gap, min_dur = float(m.get("tolerance_seconds", 1)), float(m.get("max_gap_seconds", 2)), float(m.get("min_duration_seconds", 0))
    bypasses = SETTINGS.get("bypasses") or {}
    plc, ts_col = STATE["plc_df"], STATE["plc_ts_col"]
    gt = _ground_truth_for(fault)
    keep_from = None
    if window:
        start, end = window
        ts = plc[ts_col]
        sel = pd.Series(True, index=plc.index)
        if start is not None:
            sel &= ts >= start - pd.Timedelta(seconds=_warmup_seconds(versions_raw, max_gap))
            keep_from = start
        if end is not None:
            sel &= ts < end
        plc = plc.loc[sel]
        going = gt["going"].fillna(gt["coming"]) if "going" in gt.columns else gt["coming"]
        gsel = pd.Series(True, index=gt.index)
        if start is not None:
            gsel &= going >= start
        if end is not None:
            gsel &= gt["coming"] < end
        gt = gt.loc[gsel].reset_index(drop=True)
    result = _run_fault_scoped(plc, ts_col, _versions_from_body(versions_raw), max_gap, min_dur,
                               gt, tolerance, only_machines=only_machines, bypasses=bypasses, keep_from=keep_from)
    LAST_RESULTS[(CURRENT["key"], fault)] = result
    saved = only_machines is None
    if saved:
        _handoff(fault, result, versions_raw, tolerance, max_gap, min_dur, bypasses, window)
    return result, saved


@app.route("/api/evaluate", methods=["POST"])
def api_evaluate():
    """Detail view of one fault in one program (optionally limited to some machines)."""
    body = request.get_json(force=True) or {}
    fault, key = body.get("fault", ""), body.get("program") or CURRENT["key"]
    only = set(body.get("machines") or []) or None
    original = CURRENT["key"]
    try:
        window = _parse_window(body.get("from"), body.get("to"))
        with WS_LOCK, bs.job(f"Evaluating {fault}"):
            ok, err = ensure_ready(key)
            if not ok:
                return jsonify(ok=False, error=err), 400
            result, saved = _evaluate_one(fault, only, window)
        matched = result["matched_events"].copy()
        matched["coming"] = matched["coming"].astype(str)
        if "going" in matched.columns:
            matched["going"] = matched["going"].astype(str)
        extra = result["extra_intervals"].copy()
        if len(extra):
            extra["start"], extra["end"] = extra["start"].astype(str), extra["end"].astype(str)
        return jsonify(
            ok=True,
            tp=result["tp"], fp=result["fp"], fn=result["fn"], no_data=result["no_data"],
            precision=result["precision"], recall=result["recall"], f1=result["f1"],
            ground_truth_count=len(result["matched_events"]),
            interval_count=len(result["intervals"]),
            matched_events=json.loads(matched.head(500).to_json(orient="records")),
            matched_truncated=len(matched) > 500,
            extra_intervals=json.loads(extra.head(500).to_json(orient="records")),
            extra_truncated=len(extra) > 500,
            handoff_saved=saved,
        )
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify(ok=False, error=str(e)), 400
    finally:
        with WS_LOCK:
            activate_program(original)


def _evaluate_programs(wanted, only, window=None):
    """Evaluate every fault with logic in the programs `wanted` (None = all), optionally limited to some machines.
    Returns the summary list. Used by the Evaluate tab and by the NAS sync."""
    original = CURRENT["key"]
    summary = []
    try:
        with WS_LOCK:
            programs = [p for p in load_registry()["programs"] if wanted is None or p["key"] in wanted]
            with bs.job("Evaluating faults") as job:
                plan = []
                for p in programs:
                    job.progress(step=f"Preparing {program_label(p)}")
                    ok, err = ensure_ready(p["key"])
                    if not ok:
                        summary.append(dict(_prog_fields(p), fault="(whole program)", error=err))
                        continue
                    plan += [(p, fault) for fault, spec in SETTINGS["rules"].items() if spec.get("versions")]
                job.progress(done=0, total=len(plan))
                for i, (p, fault) in enumerate(plan, 1):
                    activate_program(p["key"])
                    job.progress(step=f"{fault} — {program_label(p)}")
                    try:
                        result, _saved = _evaluate_one(fault, only, window)
                        summary.append(dict(
                            _prog_fields(p), fault=fault,
                            ground_truth_count=len(result["matched_events"]), predicted_intervals=len(result["intervals"]),
                            tp=result["tp"], fp=result["fp"], fn=result["fn"], no_data=result["no_data"],
                            precision=result["precision"], recall=result["recall"], f1=result["f1"]))
                        bs.record_items(1, 1 if (result["fp"] or result["fn"]) else 0)
                    except Exception as e:  # noqa: BLE001
                        summary.append(dict(_prog_fields(p), fault=fault, error=str(e)))
                        bs.record_error(f"{fault}: {e}")
                    job.progress(done=i)
        return summary
    finally:
        with WS_LOCK:
            activate_program(original)


@app.route("/api/evaluate_all", methods=["POST"])
def api_evaluate_all():
    """Evaluate every fault with logic, in the programs and machines picked in `scope` (null = all)."""
    body = request.get_json(force=True) or {}
    scope = body.get("scope") or {}
    only = set(scope.get("machines") or []) or None
    try:
        window = _parse_window(scope.get("from"), scope.get("to"))
        summary = _evaluate_programs(scope.get("programs"), only, window)
        return jsonify(ok=True, summary=summary, handoff_saved=(only is None),
                       date_from=_day(window, 0), date_to=_day(window, 1))
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify(ok=False, error=str(e)), 400


# --------------------------------------------------------------------------
# Copy / move a logic to another terminal and type
# --------------------------------------------------------------------------

def _write_settings_file(key, settings):
    p = ws_paths(key).settings
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(settings, indent=2, default=str), encoding="utf-8")
    tmp.replace(p)


@app.route("/api/logic/copy", methods=["POST"])
def api_logic_copy():
    """Copy (or move) one fault's logic from the active program to another terminal/type."""
    b = request.get_json(force=True) or {}
    fault, move = b.get("fault", ""), bool(b.get("move"))
    src = CURRENT["key"]
    with WS_LOCK:
        spec = (SETTINGS["rules"].get(fault) or {})
        if not spec.get("versions"):
            return jsonify(ok=False, error="This fault has no logic to copy yet."), 400
        try:
            target, _ = create_program(b.get("terminal"), b.get("type"))
        except ValueError as e:
            return jsonify(ok=False, error=str(e)), 400
        dst = target["key"]
        if dst == src:
            return jsonify(ok=False, error="That is the terminal / type you are already in."), 400
        if dst in WS_CACHE:
            dst_settings = WS_CACHE[dst]["SETTINGS"]
        else:
            dst_settings = load_settings(ws_paths(dst).settings)
        if (dst_settings["rules"].get(fault) or {}).get("versions") and not b.get("overwrite"):
            return jsonify(ok=False, exists=True, error=f"{fault} already has logic in Terminal {target['terminal']} · Type {target['type']}."), 400
        copy = json.loads(json.dumps(spec))
        copy["terminal"], copy["type"] = target["terminal"], target["type"]
        bp_copied = _carry_bypasses(copy, SETTINGS.get("bypasses") or {}, dst_settings)
        dst_settings["rules"][fault] = copy
        _write_settings_file(dst, dst_settings)
        # the root-cause names/groupings for that fault travel with it, so nothing has to be re-taught
        rc_src = rc_state_load(src)["faults"].get(fault)
        if rc_src:
            rc_dst = rc_state_load(dst)
            rc_dst["faults"][fault] = json.loads(json.dumps(rc_src))
            rc_state_save(dst, rc_dst)
        if move:
            SETTINGS["rules"][fault] = {"versions": [], "terminal": SETTINGS["rules"][fault].get("terminal"), "type": SETTINGS["rules"][fault].get("type")}
            save_settings(SETTINGS)
        return jsonify(ok=True, rules=SETTINGS["rules"], program_label=program_label(target),
                       note=f"Make sure “{fault}” is also in that type’s master list, and that its PLC files use the same column names as the logic."
                            + (f" These bypasses were copied there too (check their ranges for that terminal / type): {', '.join(bp_copied)}." if bp_copied else ""),
                       **_program_payload())


@app.route("/api/export/<program>/<path:fault>/<kind>")
def api_export(program, fault, kind):
    result = LAST_RESULTS.get((program, fault))
    if not result:
        return "No results yet for this fault — evaluate it first.", 404
    key_map = {"matched": "matched_events", "extra": "extra_intervals", "all": "intervals"}
    if kind not in key_map:
        return "invalid export kind", 400
    buf = io.BytesIO()
    result[key_map[kind]].to_csv(buf, index=False)
    buf.seek(0)
    safe = "".join(c if c.isalnum() or c in " -_" else "_" for c in fault).strip().replace(" ", "_")
    return send_file(buf, as_attachment=True, download_name=f"{program}__{safe}__{kind}.csv", mimetype="text/csv")


# --------------------------------------------------------------------------
# NAS sync (InfluxDB on the Synology) — see nas_sync.py
# --------------------------------------------------------------------------

def _program_cols(key):
    ws = WS_CACHE.get(key)
    m = (ws["SETTINGS"] if ws else (read_json(ws_paths(key).settings, {}) or {})).get("mapping") or {}
    return m.get("plc_ts_col"), m.get("plc_machine_col")


def _mark_stale(keys):
    """New PLC rows were stored: make the next Evaluate rebuild those programs from the store."""
    with WS_LOCK:
        for k in keys:
            if k in WS_CACHE:
                WS_CACHE[k]["STATE"]["applied"] = False
                WS_CACHE[k]["STATE"]["plc_df"] = None


def _evaluate_in_context(keys):
    with app.app_context():       # the sync runs in a background thread; the settings code builds Flask responses
        return _evaluate_programs(keys, None)


NAS_HOST = {"lock": WS_LOCK, "program_cols": _program_cols, "mark_stale": _mark_stale,
            "evaluate": lambda keys: _evaluate_in_context(set(keys))}       # Evaluation only — never Root Cause
try:
    nas_sync.register(app, NAS_HOST)
except Exception:  # noqa: BLE001
    traceback.print_exc()


INDEX_HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FDD Rule Builder & Backtester</title>
<link rel="icon" href="/logo">
<style>/*THEME*/</style>
</head>
<body>
<header class="app-header">
  <span class="logo-wrap" id="logoWrap"><img id="logoImg" src="/logo" alt="Company logo" hidden><button class="small" id="logoAdd" type="button" hidden>Add logo</button><input type="file" id="logoFile" accept=".png,.jpg,.jpeg,.svg,.webp" hidden></span>
  <h1>FDD Rule Builder &amp; Backtester</h1>
  <span class="status" id="liveStatus" role="status" aria-live="polite"><span class="dot dot-off"></span><span id="liveStatusText">Starting…</span></span>
  <nav class="tabs" aria-label="Sections">
    <button class="tabbtn active" data-tab="files">1. Files</button>
    <button class="tabbtn" data-tab="settings">2. Settings</button>
    <button class="tabbtn" data-tab="bypass">3. Bypass</button>
    <button class="tabbtn" data-tab="logic">4. Logic</button>
    <button class="tabbtn" data-tab="evaluate">5. Evaluate</button>
  </nav>
</header>
<main>
  <div class="progbar" id="progBar" role="group" aria-label="Terminal and type">
    <label for="progTerminal">Terminal</label><select id="progTerminal" onchange="onTerminalChange()"></select>
    <label for="progType">Type</label><select id="progType" onchange="onTypeChange()"></select>
    <button class="small" onclick="newType()">+ New type</button>
    <button class="small danger" onclick="deleteProgram()">Delete this type</button>
    <span class="hint" id="progHint" style="margin:0;"></span>
  </div>

  <!-- ================= FILES TAB ================= -->
  <div id="tab-files" class="tabpage active">
    <div class="panel">
      <h2>Data files</h2>
      <div class="hint" style="margin:0 0 6px;">Every terminal / type is its own program, so its <b>master list</b>, settings and rules are kept separately. When you add a master list you are asked which terminal and type it belongs to; you can also create a new type there. The <b>fault history</b> is one file for all of them. <b>PLC data is not uploaded</b> — it is synced from the NAS (box below) and stored inside the app.</div>
      <div id="fileRow_master"></div>
      <div id="fileRow_faults"></div>
    </div>

    <div class="panel" id="nasPanel">
      <h2>NAS sync — InfluxDB on the Synology <span class="hint" style="margin:0 0 0 8px; font-weight:400;">applies to every terminal / type</span></h2>
      <div class="hint" style="margin:0 0 8px;">The PLC data comes from the NAS — there is no PLC file to load. The app reads the 1-second rows the collector PC writes to InfluxDB. It only <b>reads</b> (use a read-only token), pulls only rows newer than the last pull, and adds them to the matching terminal / type. Rows are converted from UTC to Dubai time so they line up with the fault history’s “PLC time”. Syncing runs while this app is open.</div>
      <div class="form-row"><label for="nas_url">InfluxDB address</label><div><input type="text" id="nas_url" placeholder="http://192.168.1.50:8086"></div></div>
      <div class="form-row"><label for="nas_org">Organisation</label><div><input type="text" id="nas_org"></div></div>
      <div class="form-row"><label for="nas_bucket">Bucket</label><div><input type="text" id="nas_bucket"></div></div>
      <div class="form-row"><label for="nas_token">API token</label><div><input type="password" id="nas_token" autocomplete="off"><div class="helper">Saved on this PC only. Leave blank to keep the saved token.</div></div></div>
      <div class="form-row"><label for="nas_tag">Machine tag name</label><div><input type="text" id="nas_tag" placeholder="crane_id"><div class="helper">The InfluxDB tag that holds the machine name (for example crane_id).</div></div></div>
      <div class="form-row"><label for="nas_measurement">Measurement (optional)</label><div><input type="text" id="nas_measurement"><div class="helper">Leave blank to read every measurement in the bucket.</div></div></div>
      <div class="form-row"><label for="nas_interval">Sync every (minutes)</label><div><input type="number" id="nas_interval" min="1" max="1440"><div class="helper">Default 30. A change applies from the next check — no restart needed.</div></div></div>
      <div class="form-row"><label>When syncing</label><div>
        <label class="chip"><input type="checkbox" id="nas_enabled"> Sync automatically</label>
        <label class="chip"><input type="checkbox" id="nas_autoeval"> Run Evaluation afterwards (programs that got new rows)</label></div></div>
      <details style="margin:6px 0 0;"><summary class="hint" style="cursor:pointer;">More options</summary>
        <div class="form-row"><label for="nas_tz">Time zone of the fault history</label><div><input type="text" id="nas_tz" placeholder="Asia/Dubai"><div class="helper">InfluxDB stores UTC; rows are converted to this clock.</div></div></div>
        <div class="form-row"><label for="nas_overlap">Re-read overlap (minutes)</label><div><input type="number" id="nas_overlap" min="0"><div class="helper">Each sync starts this far before the last pulled row, so rows the collector delivered late are picked up. Rows already stored are skipped.</div></div></div>
        <div class="form-row"><label for="nas_chunk">Query size (hours)</label><div><input type="number" id="nas_chunk" min="1"><div class="helper">The first load copies history in pieces of this size.</div></div></div>
        <div class="form-row"><label for="nas_start">First load starts on</label><div><input type="date" id="nas_start"><div class="helper">Blank = the last 7 days. Only used for a machine’s very first pull.</div></div></div>
        <div class="form-row"><label for="nas_timefield">PLC’s own time field (optional)</label><div><input type="text" id="nas_timefield" placeholder="PLCTime"><div class="helper">Default PLCTime = the PLC’s own clock. If that field is missing in the data, or you clear this box, InfluxDB’s time is used instead (converted from UTC to the time zone above). It is read as local time, like your fault history. If the time column of a terminal / type is already called the same as a field, that field is used automatically.</div></div></div>
        <div class="form-row"><label for="nas_tscol">Time column name</label><div><input type="text" id="nas_tscol"><div class="helper">Used only for a terminal / type that has no column mapping saved yet; otherwise its saved mapping is used.</div></div></div>
        <div class="form-row"><label for="nas_mcol">Machine column name</label><div><input type="text" id="nas_mcol"></div></div>
      </details>
      <div class="toolbar" style="margin-top:12px;">
        <button class="primary" onclick="nasSave()">Save NAS settings</button>
        <button onclick="nasTest()">Test connection</button>
        <button onclick="nasDiscover()">Find machines</button>
        <button onclick="nasSyncNow()" id="nasSyncBtn">Sync now</button>
        <span class="hint" id="nasMsg" style="margin:0;"></span>
      </div>
      <div id="nasStatus" style="margin-top:6px;"></div>
      <div class="group-title" style="margin-top:16px;">Machines → terminal and PLC type</div>
      <div class="hint" style="margin:0 0 8px;">The terminal is read from the 2nd character of the machine name (Y2893w58 → terminal 2); type a terminal to override it. Give each machine its PLC type. If a machine is switched to another PLC program later, add a line with the date it changed — rows before that date go to the old type, rows from that date go to the new one. A machine with no type is skipped until you give it one.</div>
      <div class="toolbar">
        <label class="hint" style="margin:0;" for="nasBulkTerm">Give every machine without a type, in terminal</label>
        <select id="nasBulkTerm" style="width:auto;"></select>
        <label class="hint" style="margin:0;" for="nasBulkType">the type</label>
        <input type="text" id="nasBulkType" style="width:90px;" placeholder="A" maxlength="30">
        <button class="small" onclick="nasBulk()">Apply</button>
      </div>
      <div class="toolbar">
        <label class="hint" style="margin:0;" for="nasResyncFrom">Re-sync the ticked machines from</label>
        <input type="date" id="nasResyncFrom" style="width:auto;">
        <button class="small" onclick="nasResync()">Re-sync selected</button>
        <span class="hint" style="margin:0;">Date blank = from the first-load date. Data is copied from the NAS again; rows already stored are not duplicated.</span>
      </div>
      <div style="overflow-x:auto;"><table id="nasMachineTable"><thead><tr><th><input type="checkbox" id="nasSelAll" title="Select all machines" onchange="nasSelectAll(this.checked)"></th><th>Machine</th><th>Terminal</th><th>PLC type (from date)</th><th>Last row pulled</th></tr></thead><tbody></tbody></table></div>
    </div>

    <div class="panel">
      <h2>Stored PLC data</h2>
      <div class="toolbar"><button class="small" onclick="viewPlcStore()">View stored data</button></div>
      <div id="plcStoreView"><div class="hint" style="margin:0;">Click “View stored data” to see what is saved inside the app, and to delete a machine’s data or everything.</div></div>
    </div>
  </div>

  <!-- ================= SETTINGS TAB ================= -->
  <div id="tab-settings" class="tabpage">
    <div id="settingsNotice"></div>
    <div class="panel">
      <h2>Column mapping</h2>
      <div class="form-row"><label for="m_master_desc">Master: fault description</label>
        <div><select id="m_master_desc"></select></div></div>
      <div class="form-row"><label for="m_plc_ts">PLC: timestamp</label>
        <div><select id="m_plc_ts"></select><div class="helper">Must have the same name in every PLC file.</div></div></div>
      <div class="form-row"><label for="m_plc_machine">PLC: machine / asset (optional)</label>
        <div><select id="m_plc_machine"></select>
          <div class="helper">PLC data is stored permanently inside the app and grows each time you load a file. New rows are matched against what is stored by (machine, timestamp) — or timestamp alone if no machine column is set — and only genuinely new rows are added; stored rows are never overwritten. <a href="#" onclick="switchTab('files'); return false;">View or delete stored data</a></div></div></div>
      <div class="form-row"><label>PLC: signal columns</label>
        <div>
          <div class="toolbar" style="margin-bottom:8px;">
            <button class="small" type="button" onclick="setAllSignals(true)">Select all</button>
            <button class="small" type="button" onclick="setAllSignals(false)">Select none</button>
          </div>
          <div id="m_plc_signals" class="checklist"></div>
        </div></div>
      <div class="form-row"><label for="m_f_come">Faults: coming (start) time</label>
        <div><select id="m_f_come"></select></div></div>
      <div class="form-row"><label for="m_f_go">Faults: going (end) time</label>
        <div><select id="m_f_go"></select></div></div>
      <div class="form-row"><label for="m_f_desc">Faults: description</label>
        <div><select id="m_f_desc"></select></div></div>
      <div class="form-row"><label for="m_f_machine">Faults: machine / asset (optional)</label>
        <div><select id="m_f_machine"></select>
          <div class="helper">If both machine columns are set, every fault is evaluated separately per machine and the results are combined, so one machine’s PLC data is never matched against another machine’s events.</div></div></div>
    </div>

    <div class="panel">
      <h2>Matching</h2>
      <div class="form-row"><label for="cfg_tolerance">Match tolerance (seconds)</label>
        <div><input type="number" id="cfg_tolerance" value="1"><div class="helper">Added to each end of a real event’s window before checking for overlap.</div></div></div>
      <div class="form-row"><label for="cfg_maxgap">Max gap (seconds)</label>
        <div><input type="number" id="cfg_maxgap" value="2"><div class="helper">PLC readings closer together than this are merged into one interval.</div></div></div>
      <div class="form-row"><label for="cfg_mindur">Minimum interval (seconds)</label>
        <div><input type="number" id="cfg_mindur" value="0"><div class="helper">Predicted intervals shorter than this are ignored. 0 = off.</div></div></div>
      <div class="helper" style="margin-top:6px;">Events are matched by <b>overlap</b>: a real event spans [coming time, going time], and a predicted interval counts as a match if it overlaps that window (widened by the tolerance) — it does not have to start at exactly the same second. This absorbs debounce or persistence delays between the real onset and your rule’s raw threshold crossing.</div>
    </div>

    <div class="savebar">
      <button class="primary" id="applyBtn">Save settings</button>
      <span class="hint" id="applyErr"></span>
    </div>
  </div>

  <!-- ================= BYPASS TAB ================= -->
  <div id="tab-bypass" class="tabpage">
    <div class="panel" style="padding:14px 22px;">
      <div class="toolbar" style="margin:0;">
        <b style="font-size:14px;">Bypasses for <span id="bpScope"></span> (<span id="bpCount">0</span>)</b>
        <button class="small primary" onclick="addBypass()">+ New bypass</button>
      </div>
      <div class="hint" style="margin:8px 0 0;">A <b>bypass</b> is a named list of ranges (from → to). In the Logic tab, add a condition, pick the column (for example the gantry position), choose <b>NOT IN bypass</b> and the bypass name: while the value is inside any of its ranges that condition is false, so the fault cannot trigger there. <b>IN bypass</b> does the opposite. Editing a bypass changes every fault that uses it. Both ends of a range are included; a blank reading counts as outside every range. If the ranges changed on a date, add a version from that date — older data is still checked with the old ranges.</div>
    </div>
    <div id="bpBox"></div>
    <div class="savebar">
      <button class="primary" onclick="saveRuleChanges()">Save changes</button>
      <span class="hint" id="bpMsg"></span>
    </div>
  </div>

  <!-- ================= LOGIC TAB ================= -->
  <div id="tab-logic" class="tabpage">
    <div class="panel" style="padding:14px 22px;" id="logicStats">
      <span class="hint" style="margin:0;">Apply Settings first to see your fault list here.</span>
    </div>
    <div class="layout">
      <div class="panel fault-list">
        <h2>Not yet defined (<span id="countUndone">0</span>)</h2>
        <input type="text" id="faultSearch" placeholder="Search...">
        <div id="faultListBox"></div>
      </div>
      <div class="panel rule-panel" id="rulePanel">
        <div class="hint">Select a fault on the left to define or edit its logic. Pick another fault any time to continue — unsaved edits are saved automatically when you switch.</div>
      </div>
      <div class="panel fault-list">
        <h2>Defined (<span id="countDone">0</span>)</h2>
        <input type="text" id="faultSearchDone" placeholder="Search...">
        <div id="faultListBoxDone"></div>
      </div>
    </div>
  </div>

  <!-- ================= EVALUATE TAB ================= -->
  <div id="tab-evaluate" class="tabpage">
    <div class="panel">
      <h2>What to evaluate</h2>
      <div id="scopeBox"><div class="hint" style="margin:0;">Loading…</div></div>
    </div>
    <div class="panel">
      <h2>Results</h2>
      <div class="hint" style="margin:0 0 10px;">Evaluating <b>all machines</b> also saves each fault’s matched events for the Root Causes program (port 5001), which reads them from each program’s <code>handoff</code> folder.</div>
      <div class="toolbar">
        <button class="primary" id="evalAllBtn">Evaluate selected</button>
        <span class="hint" id="evalAllErr" style="margin:0;"></span>
      </div>
      <div id="overallCards"></div>
      <div style="overflow-x:auto;"><table id="summaryTable"><thead><tr><th>Terminal · Type</th><th>Fault</th><th>Ground truth</th><th>Predicted</th><th>TP</th><th>FP</th><th>FN</th><th>No data</th><th>Precision</th><th>Recall</th><th>F1</th></tr></thead><tbody></tbody></table></div>
    </div>
    <div class="panel" id="detailPanel" style="display:none;">
      <h2 id="detailTitle"></h2>
      <div id="detailBody"></div>
    </div>
  </div>

</main>

<script>
/*LOGOJS*/
// ============================================================
// Tabs
// ============================================================
document.querySelectorAll('.tabbtn').forEach(btn=>{
  btn.addEventListener('click', ()=>switchTab(btn.dataset.tab));
});
function switchTab(tab){
  saveIfDirty();
  document.querySelectorAll('.tabbtn').forEach(b=>b.classList.toggle('active', b.dataset.tab===tab));
  document.querySelectorAll('.tabpage').forEach(p=>p.classList.toggle('active', p.id==='tab-'+tab));
  $('progBar').style.display = (tab==='evaluate') ? 'none' : 'flex';   // Evaluate has its own picker
  if(tab==='evaluate') loadScope();
  if(tab==='bypass') renderBypasses();
}
function $(id){ return document.getElementById(id); }
// live status text in the header (red on error)
function setStatus(text, kind){
  const el = $('liveStatus'); if(!el) return;
  $('liveStatusText').textContent = text;
  el.className = 'status' + (kind==='err' ? ' err' : '');
  el.querySelector('.dot').className = 'dot dot-' + (kind||'ok');
}
const READY_TEXT = 'Ready — decision support only, no PLC connection';
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escAttr(s){ return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
async function postJSON(url, body){
  setStatus('Working…','attn');
  try{
    const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
    const d = await r.json();
    if(d && d.ok===false && d.error) setStatus('⚠ '+d.error,'err'); else setStatus(READY_TEXT,'ok');
    return d;
  } catch(e){ setStatus('⚠ '+e.message,'err'); throw e; }
}

// ============================================================
// Global state
// ============================================================
let settings = {paths:{}, mapping:{}, rules:{}};
let cols = {master:[], plc:[], plc_numeric:[], faults:[]};
let signalCols = [];
let masterFaults = [];
let rules = {};
let selectedFault = null;
let cfg = {tolerance_seconds:1, max_gap_seconds:2, min_duration_seconds:0};
let programs = [], terminals = [], activeKey = null;   // terminal / type programs
let suppressAutoApply = false;   // true while the app is reloading saved files at start-up

// ============================================================
// FILES TAB
// ============================================================
const ROLE_LABELS = {master:'1. Master fault list', faults:'3. Fault event history'};
let plcPaths = [];    // one entry per PLC file of THIS terminal/type (one file per machine is the normal case)
let plcStatus = [];   // {text, cls} per entry

function renderFileRow(role){
  if(role==='plc'){ renderPlcRows(); return; }
  const note = role==='master' ? 'for the selected terminal / type' : 'one file for every terminal';
  $('fileRow_'+role).innerHTML = `
    <div class="form-row">
      <label>${ROLE_LABELS[role]}<div class="helper">${note}</div></label>
      <div>
        <div class="file-row">
          <button class="small" onclick="browseFile('${role}')">Browse…</button>
          <input type="text" id="path_${role}" placeholder="Full file path (or click Browse)" value="${escAttr(settings.paths[role]||'')}">
          <button class="small primary" onclick="loadPath('${role}')">Load</button>
        </div>
        <div class="helper" id="status_${role}"></div>
      </div>
    </div>`;
}

function renderPlcRows(){
  if(!$('fileRow_plc')) return;
  const rows = plcPaths.map((p,i)=>`
    <div class="file-row">
      <button class="small" onclick="browsePlc(${i})">Browse…</button>
      <input type="text" id="plcpath_${i}" placeholder="Full path to this machine's PLC file" value="${escAttr(p)}">
      <button class="small primary" onclick="loadPlc(${i})">Load</button>
      <button class="small danger" onclick="removePlc(${i})" title="Stop using this file (data already stored is kept)">Remove</button>
    </div>
    <div class="helper" id="plcstatus_${i}" style="margin:-2px 0 8px;"></div>`).join('');
  $('fileRow_plc').innerHTML = `
    <div class="form-row">
      <label>2. PLC data<div class="helper">one file per machine, for the selected terminal / type</div></label>
      <div>${rows || '<div class="helper" style="margin:0 0 8px;">No PLC files yet.</div>'}
        <button class="small" onclick="addPlcRow()">+ Add PLC file</button></div>
    </div>`;
  plcStatus.forEach((s,i)=>{ const el=$('plcstatus_'+i); if(s && el){ el.textContent=s.text; el.className='helper '+(s.cls||''); } });
}
['master','faults'].forEach(renderFileRow);

function syncPlcPaths(){ plcPaths = plcPaths.map((p,i)=> $('plcpath_'+i) ? $('plcpath_'+i).value.trim() : p); }
function setPlcStatus(i, text, cls){
  plcStatus[i] = {text, cls};
  const el = $('plcstatus_'+i); if(el){ el.textContent = text; el.className = 'helper '+cls; }
}
function addPlcRow(){ syncPlcPaths(); plcPaths.push(''); plcStatus.push(null); renderPlcRows(); }

async function browsePlc(i){
  setPlcStatus(i,'Opening file browser…','');
  const r = await postJSON('/api/pick_file', {role:'plc'});
  if(!r.ok){ setPlcStatus(i,'⚠ '+r.error,'err'); return; }
  syncPlcPaths(); plcPaths[i] = r.path; renderPlcRows();
  await loadPlc(i);
}
async function loadPlc(i){
  syncPlcPaths();
  const path = plcPaths[i]; if(!path) return;
  if(!(settings.paths.plc||[]).includes(path)){ await addFile('plc', path); return; }   // a new file: ask which terminal/type
  await doLoadPlc(path);
}
async function doLoadPlc(path){
  let i = plcPaths.indexOf(path);
  if(i < 0){ plcPaths.push(path); plcStatus.push(null); renderPlcRows(); i = plcPaths.length-1; }
  setPlcStatus(i,'Loading…','');
  const r = await postJSON('/api/load_from_path', {role:'plc', path});
  if(!r.ok){ setPlcStatus(i,'⚠ '+r.error,'err'); return; }
  setPlcStatus(i,'Loaded '+r.rows.toLocaleString()+' rows','ok');
  settings.paths.plc = [...new Set([...(settings.paths.plc||[]), path])];
  cols.plc = r.columns; cols.plc_numeric = r.numeric_columns;
  maybePopulateSettingsTab();
}
async function removePlc(i){
  syncPlcPaths();
  const path = plcPaths[i];
  if(path){
    const r = await postJSON('/api/plc_path/remove', {path});
    if(r.ok){ cols.plc = r.columns; cols.plc_numeric = r.numeric_columns; settings.paths.plc = (settings.paths.plc||[]).filter(p=>p!==path); }
  }
  plcPaths.splice(i,1); plcStatus.splice(i,1); renderPlcRows();
}

async function browseFile(role){
  $('status_'+role).textContent = 'Opening file browser…'; $('status_'+role).className='helper';
  const r = await postJSON('/api/pick_file', {role});
  if(!r.ok){ $('status_'+role).textContent = '⚠ '+r.error; $('status_'+role).className='helper err'; return; }
  $('path_'+role).value = r.path;
  await loadPath(role);
}
async function loadPath(role){
  const path = $('path_'+role).value.trim();
  if(!path) return;
  if(role==='master' && settings.paths.master !== path){ await addFile('master', path); return; }   // a new master list: ask which terminal/type
  await doLoadPath(role, path);
}
async function doLoadPath(role, path){
  $('path_'+role).value = path;
  $('status_'+role).textContent = 'Loading…'; $('status_'+role).className='helper';
  const r = await postJSON('/api/load_from_path', {role, path});
  if(!r.ok){ $('status_'+role).textContent = '⚠ '+r.error; $('status_'+role).className='helper err'; return; }
  $('status_'+role).textContent = 'Loaded '+r.rows.toLocaleString()+' rows'; $('status_'+role).className='helper ok';
  settings.paths[role] = path;
  cols[role] = r.columns;
  maybePopulateSettingsTab();
}

// ---- which terminal / type does a newly added file belong to? ----
async function addFile(role, path){
  const what = role==='master' ? 'master list' : 'PLC file';
  const pick = await askProgram({
    title: 'Which terminal and type is this '+what+' for?',
    intro: '<b>'+esc(path.split(/[\\/]/).pop())+'</b><br>Each terminal / type has its own master list, PLC files, settings and rules. Pick the terminal, then its type — or create a new type.'});
  if(!pick) return;
  await switchProgram(pick.terminal, pick.type);
  if(role==='master') await doLoadPath('master', path); else await doLoadPlc(path);
}

function askProgram({title, intro, terminal, newOnly}){
  return new Promise(resolve=>{
    const cur = programs.find(p=>p.key===activeKey) || {};
    const t0 = terminal || cur.terminal || terminals[0] || '1';
    document.body.insertAdjacentHTML('beforeend', `
      <div class="modal-bg" id="progModal" role="dialog" aria-modal="true">
        <div class="panel modal-card">
          <h2>${esc(title)}</h2>
          <div class="hint" style="margin:0 0 12px;">${intro}</div>
          <div class="form-row"><label for="pmTerminal">Terminal</label>
            <div><select id="pmTerminal">${terminals.map(t=>`<option ${t===t0?'selected':''}>${esc(t)}</option>`).join('')}</select></div></div>
          <div class="form-row"><label for="pmType">Type</label>
            <div><select id="pmType" ${newOnly?'hidden':''}></select>
              <input type="text" id="pmNew" placeholder="Name of the new type, e.g. B" maxlength="30" style="margin-top:6px;"></div></div>
          <div class="toolbar" style="margin:14px 0 0;"><button class="primary" id="pmOk">Continue</button><button id="pmCancel">Cancel</button></div>
        </div>
      </div>`);
    const done = v=>{ $('progModal').remove(); resolve(v); };
    const sync = ()=>{ const isNew = newOnly || $('pmType').value==='__new__'; $('pmNew').style.display = isNew ? '' : 'none'; };
    const fill = ()=>{
      const t = $('pmTerminal').value;
      const types = programs.filter(p=>p.terminal===t).map(p=>p.type);
      const preferred = (cur.terminal===t) ? cur.type : types[0];
      $('pmType').innerHTML = types.map(x=>`<option ${x===preferred?'selected':''}>${esc(x)}</option>`).join('') + '<option value="__new__">＋ New type…</option>';
      if(!types.length) $('pmType').value = '__new__';
      sync();
    };
    $('pmTerminal').addEventListener('change', fill);
    $('pmType').addEventListener('change', sync);
    $('pmCancel').addEventListener('click', ()=>done(null));
    $('pmOk').addEventListener('click', ()=>{
      const isNew = newOnly || $('pmType').value==='__new__';
      const type = (isNew ? $('pmNew').value : $('pmType').value).trim();
      if(!type){ $('pmNew').style.display=''; $('pmNew').focus(); return; }
      done({terminal: $('pmTerminal').value, type});
    });
    fill();
  });
}

async function switchProgram(terminal, type){
  await saveIfDirty();
  const cur = programs.find(p=>p.key===activeKey);
  if(cur && cur.terminal===terminal && cur.type.toLowerCase()===type.toLowerCase()) return true;
  const r = await postJSON('/api/program/create', {terminal, type});   // opens the existing one if it is already there
  if(!r.ok){ alert(r.error); return false; }
  await loadProgram();
  return true;
}
async function activateKey(key){
  await saveIfDirty();
  const r = await postJSON('/api/program/activate', {key});
  if(!r.ok){ alert(r.error); return; }
  await loadProgram();
}
function renderProgBar(){
  const active = programs.find(p=>p.key===activeKey) || programs[0];
  if(!active) return;
  $('progTerminal').innerHTML = terminals.map(t=>`<option ${t===active.terminal?'selected':''}>${esc(t)}</option>`).join('');
  $('progType').innerHTML = programs.filter(p=>p.terminal===active.terminal)
    .map(p=>`<option value="${esc(p.key)}" ${p.key===active.key?'selected':''}>${esc(p.type)}</option>`).join('');
  $('progHint').textContent = 'Files, settings and logic below belong to '+active.label+'.';
}
async function onTerminalChange(){
  const t = $('progTerminal').value;
  const types = programs.filter(p=>p.terminal===t);
  if(types.length){ await activateKey(types[0].key); }
  else { renderProgBar(); await newType(t); }
}
function onTypeChange(){ activateKey($('progType').value); }
async function newType(terminal){
  const cur = programs.find(p=>p.key===activeKey) || {};
  const pick = await askProgram({title:'New type', terminal: terminal || cur.terminal, newOnly:true,
    intro:'Create a new type under a terminal. Its master list, PLC files, settings and rules are kept separate from the other types.'});
  if(pick) await switchProgram(pick.terminal, pick.type);
}
async function deleteProgram(){
  const cur = programs.find(p=>p.key===activeKey); if(!cur) return;
  if(!confirm('Delete '+cur.label+' and everything stored for it (PLC data, rules, root-cause labels)? This cannot be undone.')) return;
  const r = await postJSON('/api/program/delete', {key: cur.key});
  if(!r.ok){ alert(r.error); return; }
  dirty = false;
  await loadProgram();
}

// ============================================================
// SETTINGS TAB
// ============================================================
function guessCol(headers, keywords){
  const lower = headers.map(h=>h.toLowerCase());
  for(const kw of keywords){ const i=lower.findIndex(h=>h.includes(kw)); if(i>-1) return headers[i]; }
  return headers[0]||'';
}
function fillSelect(id, headers, selected, allowNone){
  const sel=$(id); sel.innerHTML='';
  const opts = allowNone ? ['(none)',...headers] : headers;
  opts.forEach(h=>{ const o=document.createElement('option'); o.value=h; o.textContent=h; if(h===selected) o.selected=true; sel.appendChild(o); });
}
function buildSignalChecklist(tsCol, preselected){
  const box=$('m_plc_signals'); box.innerHTML='';
  cols.plc.filter(h=>h!==tsCol).forEach(h=>{
    const id='sig_'+h.replace(/\W/g,'_');
    const checked = preselected ? preselected.includes(h) : cols.plc_numeric.includes(h);
    box.insertAdjacentHTML('beforeend', `<label style="font-size:12px; display:flex; gap:6px; align-items:center; font-weight:400;">
      <input type="checkbox" id="${id}" data-col="${h}" ${checked?'checked':''}> ${h}</label>`);
  });
}
function setAllSignals(checked){
  document.querySelectorAll('#m_plc_signals input[type=checkbox]').forEach(cb=>cb.checked=checked);
  markSettingsDirty();
}

let settingsPopulated = false;
function maybePopulateSettingsTab(){
  const need = [];
  if(!cols.master.length) need.push('the <b>master fault list</b>');
  if(!cols.faults.length) need.push('the <b>fault history</b>');
  if(!cols.plc.length) need.push('<b>PLC data</b> (press “Sync now” in the NAS box)');
  $('settingsNotice').innerHTML = need.length ? `<div class="notice info">Before you can map columns here, load on the Files tab: ${need.join(', ')}.</div>` : '';
  if(need.length) return;
  const m = settings.mapping || {};
  fillSelect('m_master_desc', cols.master, m.master_desc_col || guessCol(cols.master,['desc','fault','name']));
  const tsGuess = m.plc_ts_col || guessCol(cols.plc,['timestamp','time','date']);
  fillSelect('m_plc_ts', cols.plc, tsGuess);
  fillSelect('m_plc_machine', cols.plc, m.plc_machine_col || guessCol(cols.plc,['machine','asset','equipment','unit']), true);
  buildSignalChecklist(tsGuess, m.signal_cols);
  $('m_plc_ts').onchange = ()=>buildSignalChecklist($('m_plc_ts').value);
  fillSelect('m_f_come', cols.faults, m.faults_come_col || guessCol(cols.faults,['plc time','plc_time','coming','start','onset','begin']));
  fillSelect('m_f_go', cols.faults, m.faults_go_col || guessCol(cols.faults,['going','end','clear','reset']), true);
  fillSelect('m_f_desc', cols.faults, m.faults_desc_col || guessCol(cols.faults,['desc','message','event','fault']));
  fillSelect('m_f_machine', cols.faults, m.faults_machine_col || guessCol(cols.faults,['machine','crane','asset','equipment','unit']), true);
  $('cfg_tolerance').value = m.tolerance_seconds ?? 1;
  $('cfg_maxgap').value = m.max_gap_seconds ?? 2;
  $('cfg_mindur').value = m.min_duration_seconds ?? 0;
  settingsPopulated = true;

  // if we already have a complete saved mapping, auto-apply so Logic/Evaluate are ready immediately
  if(!suppressAutoApply && m.master_desc_col && m.plc_ts_col && m.faults_come_col && m.faults_desc_col && (m.signal_cols||[]).length){
    applySettings(true);
  }
}

async function applySettings(silent){
  signalCols = [...document.querySelectorAll('#m_plc_signals input:checked')].map(cb=>cb.dataset.col);
  cfg.tolerance_seconds = +$('cfg_tolerance').value;
  cfg.max_gap_seconds = +$('cfg_maxgap').value;
  cfg.min_duration_seconds = +$('cfg_mindur').value;
  const body = {
    master_desc_col: $('m_master_desc').value,
    plc_ts_col: $('m_plc_ts').value,
    plc_machine_col: $('m_plc_machine').value === '(none)' ? null : $('m_plc_machine').value,
    signal_cols: signalCols,
    faults_come_col: $('m_f_come').value,
    faults_go_col: $('m_f_go').value === '(none)' ? null : $('m_f_go').value,
    faults_desc_col: $('m_f_desc').value,
    faults_machine_col: $('m_f_machine').value === '(none)' ? null : $('m_f_machine').value,
    tolerance_seconds: cfg.tolerance_seconds,
    max_gap_seconds: cfg.max_gap_seconds,
    min_duration_seconds: cfg.min_duration_seconds,
  };
  if(!silent){ $('applyBtn').disabled = true; $('applyBtn').textContent = 'Saving…'; }
  const data = await postJSON('/api/configure', body);
  if(!silent){ $('applyBtn').disabled = false; $('applyBtn').textContent = 'Save settings'; }
  if(!data.ok){ $('applyErr').textContent='⚠ '+data.error; $('applyErr').className='hint err'; return; }
  const warn = (data.warnings||[]).join(' ');
  if(warn){ $('applyErr').textContent = '⚠ '+warn; $('applyErr').className='hint warn'; }
  else { $('applyErr').textContent = silent ? '' : 'Saved ✓'; $('applyErr').className='hint ok'; }

  masterFaults = data.master_faults;
  rules = data.rules;
  $('logicStats').innerHTML = `<span class="hint" style="margin:0;">PLC rows (stored, accumulated): <b>${data.stats.plc_rows.toLocaleString()}</b> (+${data.stats.plc_rows_added.toLocaleString()} new, ${data.stats.plc_rows_skipped_duplicate.toLocaleString()} duplicates skipped this load) &nbsp;•&nbsp; Fault events: <b>${data.stats.event_rows.toLocaleString()}</b> &nbsp;•&nbsp; Master faults: <b>${data.stats.master_rows.toLocaleString()}</b></span>`;
  renderFaultList();
}
$('applyBtn').addEventListener('click', ()=>applySettings(false));
function markSettingsDirty(){
  if(!settingsPopulated) return;
  $('applyErr').textContent = 'Unsaved changes'; $('applyErr').className = 'hint warn';
}
['input','change'].forEach(evt => $('tab-settings').addEventListener(evt, markSettingsDirty));

async function viewPlcStore(){
  $('plcStoreView').innerHTML = '<div class="hint" style="margin:0;">Loading…</div>';
  const r = await fetch('/api/plc_store/view').then(r=>r.json());
  if(!r.ok){ $('plcStoreView').innerHTML = '<div class="hint err" style="margin:0;">⚠ '+(r.error||'Could not load stored data')+'</div>'; return; }
  if(!r.exists){ $('plcStoreView').innerHTML = '<div class="hint" style="margin:0;">Nothing stored yet — load PLC files, then press Save settings.</div>'; return; }
  let html = `<div class="cards">
      <div class="card"><div class="v">${r.total_rows.toLocaleString()}</div><div class="l">Stored rows</div></div>
      ${r.by_machine ? `<div class="card"><div class="v">${r.by_machine.length}</div><div class="l">Machines</div></div>` : ''}
      <div class="card"><div class="v">${r.file_size_mb} MB</div><div class="l">On disk</div></div>
    </div>`;
  if(r.date_min) html += `<div class="hint" style="margin:0 0 12px;">Covers ${r.date_min} → ${r.date_max}</div>`;
  if(r.by_machine){
    html += `<table><thead><tr><th>Machine</th><th>Rows</th><th>From</th><th>To</th><th></th></tr></thead><tbody>` +
      r.by_machine.map(m=>`<tr><td>${m.machine}</td><td>${m.rows.toLocaleString()}</td><td>${m.date_min||'—'}</td><td>${m.date_max||'—'}</td>
        <td style="text-align:right;"><button class="small danger" onclick="deleteMachineFromStore('${m.machine.replace(/'/g,"\\'")}')">Delete this machine’s data</button></td></tr>`).join('') +
      `</tbody></table>`;
  }
  html += `<div class="toolbar" style="margin:14px 0 0;"><button class="small danger" onclick="clearAllPlcStore()">Delete all stored PLC data</button></div>`;
  $('plcStoreView').innerHTML = html;
}
async function deleteMachineFromStore(machine){
  if(!confirm('Delete all stored PLC data for "'+machine+'"? This cannot be undone.')) return;
  const r = await postJSON('/api/plc_store/clear', {machine});
  viewPlcStore();
  setStatus('Removed '+(r.removed||0).toLocaleString()+' rows for '+machine+' — press Save settings to refresh','attn');
}
async function clearAllPlcStore(){
  if(!confirm('Delete ALL stored PLC data? This cannot be undone.')) return;
  const r = await postJSON('/api/plc_store/clear', {});
  viewPlcStore();
  setStatus('Removed '+(r.removed||0).toLocaleString()+' stored rows','attn');
}

// ============================================================
// LOGIC TAB
// ============================================================
function renderFaultList(){
  const undone = masterFaults.filter(f => !((rules[f]?.versions||[]).length));
  const done = masterFaults.filter(f => (rules[f]?.versions||[]).length);
  $('countUndone').textContent = undone.length;
  $('countDone').textContent = done.length;

  const qUndone = ($('faultSearch').value||'').toLowerCase();
  $('faultListBox').innerHTML = undone.filter(f=>f.toLowerCase().includes(qUndone)).map(f=>
    `<div class="fault-item ${f===selectedFault?'active':''}" onclick="selectFault('${f.replace(/'/g,"\\'")}')">${f}</div>`
  ).join('') || '<div class="hint">Nothing left — every fault has logic defined.</div>';

  const qDone = ($('faultSearchDone')?.value||'').toLowerCase();
  $('faultListBoxDone').innerHTML = done.filter(f=>f.toLowerCase().includes(qDone)).map(f=>{
    const n = rules[f].versions.length;
    return `<div class="fault-item ${f===selectedFault?'active':''}" onclick="selectFault('${f.replace(/'/g,"\\'")}')">${f}<span class="badge">${n} rule${n!==1?'s':''}</span></div>`;
  }).join('') || '<div class="hint">None defined yet.</div>';
}
$('faultSearch').addEventListener('input', renderFaultList);
$('faultSearchDone').addEventListener('input', renderFaultList);
async function selectFault(f){ await saveIfDirty(); selectedFault=f; renderFaultList(); renderRulePanel(); }


let dirty = false;
function setRuleMsg(text, cls){ const el = $('saveRuleMsg'); if(el){ el.textContent = text; el.className = 'hint '+(cls||''); } }
function markDirty(){ dirty = true; setRuleMsg('Unsaved changes','warn'); }
async function persistRules(){
  const names = Object.values(bypasses).map(b=>String(b.name||'').trim().toLowerCase());
  if(names.some(n=>!n)) throw new Error('every bypass needs a name (Bypass tab)');
  if(new Set(names).size !== names.length) throw new Error('two bypasses have the same name (Bypass tab)');
  const r = await postJSON('/api/save_settings', {rules, bypasses});
  if(!r.ok) throw new Error(r.error || 'not saved');
}
async function saveRuleChanges(){
  setRuleMsg('Saving…',''); if(bpDirty) setBpMsg('Saving…','');
  try{
    await persistRules();
    dirty = false; bpDirty = false;
    setRuleMsg('Saved ✓','ok'); setBpMsg('Saved ✓','ok');
    renderBypasses();
  }
  catch(e){ setRuleMsg('⚠ Could not save: '+e.message,'err'); setBpMsg('⚠ Could not save: '+e.message,'err'); }
}
async function saveIfDirty(){ if(dirty || bpDirty) await saveRuleChanges(); }

function renderRulePanel(){
  if(!rules[selectedFault]) rules[selectedFault] = {versions:[]};
  const r = rules[selectedFault];
  if(!r.feature_columns) r.feature_columns = [];
  const box = $('rulePanel');
  box.innerHTML = `
    <h2>${selectedFault} <span class="pill" title="This logic belongs to this terminal and PLC type">${esc(progLabel())}</span></h2>
    <div class="toolbar" style="margin:0 0 8px;"><button class="small" onclick="copyLogic(false)">Copy to another terminal / type…</button><button class="small" onclick="copyLogic(true)">Move to another terminal / type…</button></div>
    <div class="hint" style="margin:0 0 14px;">Matched automatically against the identically-worded event in the fault history file. Edits stay local until you press Save changes (they are also saved if you switch faults or tabs).</div>
    <div style="margin-top:4px;"><b style="font-size:13px;">Rule versions</b></div>
    <div id="versionsBox"></div>
    <button class="secondary small" id="addVersionBtn" style="margin-top:6px;">+ Add rule version</button>

    <div style="margin-top:26px; border-top:1px solid var(--line); padding-top:16px;">
      <b style="font-size:13px;">Root cause context columns</b>
      <div class="hint" style="margin-top:2px;">Pick columns that help explain WHY this fault happened. Mark each one as a <b>trigger variable</b> (the signal that already defines the fault — always present, so it's kept for context but not used to group occurrences) or a <b>diagnostic feature</b> (varies between occurrences and is what actually groups similar root causes together). Set a tolerance on a diagnostic column so nearby values still count as the same pattern — leave it at 0 to require an exact match. Used in the Root Causes program.</div>
      <div id="featureColsBox" style="margin-top:10px;"></div>
    </div>

    <div class="hint" style="margin-top:20px;">Recurring-location flagging and sensor-health checks (flickering, abnormal jumps) run automatically in the Root Causes program — thresholds are computed from your data each time, nothing to configure here.</div>

    <div class="hint" style="margin-top:16px;">Run evaluation from the Evaluate tab once you've defined logic here.</div>

    <div class="savebar">
      <button class="primary" id="saveRuleBtn" onclick="saveRuleChanges()">Save changes</button>
      <span class="hint" id="saveRuleMsg"></span>
    </div>
  `;
  if(dirty) setRuleMsg('Unsaved changes','warn');
  renderFeatureCols();
  $('addVersionBtn').addEventListener('click', ()=>{
    r.versions.push({id:'v'+Date.now(), effective_from:null, conditions:[{column:signalCols[0]||'', op:'>=', value:0, joiner:'AND', mode:'none', mode_value:0}]});
    renderVersions(); markDirty(); renderFaultList();
  });
  renderVersions();
}
function renderFeatureCols(){
  const r = rules[selectedFault];
  const selected = {}; r.feature_columns.forEach(f=>selected[f.column]=f);
  $('featureColsBox').innerHTML = cols.plc.map(c=>{
    const id = 'feat_'+c.replace(/\W/g,'_');
    const isOn = c in selected;
    const f = isOn ? selected[c] : null;
    const role = f ? (f.role||'diagnostic') : 'diagnostic';
    const mode = f ? (f.mode||'proximity') : 'proximity';
    let inner = '';
    if(isOn){
      inner += `<select style="flex:0 0 200px;" onchange="setFeatureRole('${c.replace(/'/g,"\\'")}', this.value)" title="Trigger variable: already what defines the fault — always present, excluded from grouping. Diagnostic feature: varies between occurrences and is what distinguishes one root cause from another.">
          <option value="diagnostic" ${role==='diagnostic'?'selected':''}>Diagnostic feature (varies — used to group)</option>
          <option value="trigger" ${role==='trigger'?'selected':''}>Trigger variable (always present — context only)</option>
        </select>`;
      if(role==='diagnostic'){
        inner += `<select style="flex:0 0 170px;" onchange="setFeatureMode('${c.replace(/'/g,"\\'")}', this.value)">
            <option value="proximity" ${mode==='proximity'?'selected':''}>Proximity (discover)</option>
            <option value="threshold" ${mode==='threshold'?'selected':''}>Threshold buckets</option>
          </select>`;
        if(mode==='proximity'){
          inner += `<span class="hint" style="margin:0;">tolerance ±</span><input type="number" step="any" min="0" value="${f.tolerance||0}" style="width:80px;" onchange="setFeatureTolerance('${c.replace(/'/g,"\\'")}', this.value)">`;
        }
      }
    }
    let bucketsHtml = '';
    if(isOn && role==='diagnostic' && mode==='threshold'){
      const buckets = f.buckets || [];
      bucketsHtml = `<div style="margin:6px 0 10px 20px; padding:10px; background:var(--panel2); border-radius:6px;">
        ${buckets.map((b,i)=>`<div class="cond-row">
            <span class="hint" style="margin:0; flex:0 0 60px;">if &lt;</span>
            <input type="number" step="any" style="width:100px;" value="${b.upper_bound==null?'':b.upper_bound}" placeholder="${b.upper_bound==null?'(else)':''}" ${b.upper_bound==null?'disabled':''} onchange="setBucketBound('${c.replace(/'/g,"\\'")}',${i},this.value)">
            <input type="text" style="flex:1 1 160px;" value="${b.label}" placeholder="Label" onchange="setBucketLabel('${c.replace(/'/g,"\\'")}',${i},this.value)">
            ${buckets.length>1 && b.upper_bound!=null ? `<button class="danger small" onclick="removeBucket('${c.replace(/'/g,"\\'")}',${i})">×</button>` : ''}
          </div>`).join('')}
        <button class="secondary small" onclick="addBucket('${c.replace(/'/g,"\\'")}')">+ Add range</button>
      </div>`;
    }
    return `<div style="padding:4px 0;">
      <div style="display:flex; align-items:center; gap:8px; font-size:12px; flex-wrap:wrap;">
        <label style="display:flex; gap:6px; align-items:center; font-weight:400; flex:1 1 160px;">
          <input type="checkbox" id="${id}" data-col="${c}" ${isOn?'checked':''} onchange="toggleFeatureCol('${c.replace(/'/g,"\\'")}', this.checked)"> ${c}
        </label>
        ${inner}
      </div>
      ${bucketsHtml}
    </div>`;
  }).join('');
}
function toggleFeatureCol(col, checked){
  const r = rules[selectedFault];
  if(checked){ if(!r.feature_columns.some(f=>f.column===col)) r.feature_columns.push({column:col, tolerance:0, role:'diagnostic', mode:'proximity', buckets:[]}); }
  else { r.feature_columns = r.feature_columns.filter(f=>f.column!==col); }
  renderFeatureCols(); markDirty();
}
function setFeatureRole(col, role){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  if(f) f.role = role;
  renderFeatureCols(); markDirty();
}
function setFeatureMode(col, mode){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  if(f){
    f.mode = mode;
    if(mode==='threshold' && (!f.buckets || !f.buckets.length)){
      f.buckets = [{upper_bound:null, label:''}];
    }
  }
  renderFeatureCols(); markDirty();
}
function setFeatureTolerance(col, val){
  const r = rules[selectedFault];
  const f = r.feature_columns.find(f=>f.column===col);
  if(f) f.tolerance = parseFloat(val) || 0;
  markDirty();
}
function addBucket(col){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  // insert a new bound before the final catch-all
  f.buckets.splice(f.buckets.length-1, 0, {upper_bound: 0, label:''});
  renderFeatureCols(); markDirty();
}
function removeBucket(col, idx){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  f.buckets.splice(idx,1);
  renderFeatureCols(); markDirty();
}
function setBucketBound(col, idx, val){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  f.buckets[idx].upper_bound = val===''? null : parseFloat(val);
  markDirty();
}
function setBucketLabel(col, idx, val){
  const f = rules[selectedFault].feature_columns.find(f=>f.column===col);
  f.buckets[idx].label = val;
  markDirty();
}

function versionLabel(v, nextV){
  const untilLabel = nextV ? (nextV.effective_from ? new Date(nextV.effective_from).toLocaleDateString() : '?') : 'now / ongoing';
  return (v.effective_from ? 'From '+new Date(v.effective_from).toLocaleDateString() : 'From start of data') + ' → ' + untilLabel;
}
function renderVersions(){
  const r = rules[selectedFault];
  const sorted = [...r.versions].sort((a,b)=>(a.effective_from? new Date(a.effective_from).getTime():-Infinity)-(b.effective_from? new Date(b.effective_from).getTime():-Infinity));
  $('versionsBox').innerHTML = sorted.map((v,i)=>`<div class="version-card">
      <div class="vh"><b id="label_${v.id}">${versionLabel(v, sorted[i+1])}</b>
        <button class="danger small" onclick="deleteVersion('${v.id}')">Delete</button></div>
      <div class="field" style="max-width:220px; margin-bottom:10px;">
        <label>Effective from date (blank = start of data)</label>
        <input type="date" id="date_${v.id}" value="${v.effective_from?v.effective_from.slice(0,10):''}">
        <button class="secondary small" style="margin-top:6px;" onclick="applyVersionDate('${v.id}')">Apply date</button>
        <button class="secondary small" style="margin-top:6px;" onclick="clearVersionDate('${v.id}')">Clear (start of data)</button>
      </div>
      <div id="conds_${v.id}"></div>
      <div class="toolbar" style="margin:6px 0 0;">
        <button class="secondary small" onclick="addCondition('${v.id}','')">+ Add condition</button>
        <button class="secondary small" onclick="addGroup('${v.id}','')" title="Brackets: a group of conditions combined first, then used as one condition">+ Add sub-logic ( )</button>
      </div>
    </div>`).join('') || '<div class="hint">No rule versions yet — add one to define when this fault triggers.</div>';
  sorted.forEach(v=>renderConditions(v.id));
}
function applyVersionDate(id){
  const val = $('date_'+id).value;
  const v = rules[selectedFault].versions.find(v=>v.id===id);
  v.effective_from = val ? val+'T00:00:00' : null;
  renderVersions(); markDirty();
}
function clearVersionDate(id){
  const v = rules[selectedFault].versions.find(v=>v.id===id);
  v.effective_from = null;
  renderVersions(); markDirty();
}
function deleteVersion(id){
  rules[selectedFault].versions = rules[selectedFault].versions.filter(v=>v.id!==id);
  renderVersions(); renderFaultList(); markDirty();
}
// ---- conditions & sub-logic (groups). A condition is addressed by a path of indexes: "2" = 3rd item at the
// top level, "2.0" = 1st item inside that group, and so on. A group = {type:'group', joiner, mode, mode_value,
// conditions:[...]} and works like brackets: its conditions are combined first, then used as one item.
const MAX_GROUP_DEPTH = 3;
function newLeaf(joiner){ return {column:signalCols[0]||'', op:'>=', value:0, joiner:joiner||'AND', mode:'none', mode_value:0}; }
function versionOf(vid){ return rules[selectedFault].versions.find(v=>v.id===vid); }
function listAt(vid, gpath){           // the conditions array of the top level ('') or of the group at gpath
  let list = versionOf(vid).conditions;
  if(gpath==='') return list;
  gpath.split('.').forEach(i=>{ list = list[+i].conditions; });
  return list;
}
function splitPath(path){ const k = path.lastIndexOf('.'); return k<0 ? ['', +path] : [path.slice(0,k), +path.slice(k+1)]; }
function condAt(vid, path){ const [g,i] = splitPath(path); return listAt(vid, g)[i]; }
function leafConds(list){ return (list||[]).flatMap(c=>c.type==='group' ? leafConds(c.conditions) : [c]); }

function addCondition(vid, gpath){
  const list = listAt(vid, gpath||'');
  list.push(newLeaf('AND'));
  renderConditions(vid); markDirty();
}
function addGroup(vid, gpath){
  const list = listAt(vid, gpath||'');
  list.push({type:'group', joiner: list.length ? 'OR' : 'AND', mode:'none', mode_value:0, conditions:[newLeaf('AND'), newLeaf('AND')]});
  renderConditions(vid); markDirty();
}
function removeCondition(vid, path){
  const [g,i] = splitPath(path);
  const c = listAt(vid, g)[i];
  if(c.type==='group' && leafConds(c.conditions).length>1 && !confirm('Remove this sub-logic and every condition inside it?')) return;
  listAt(vid, g).splice(i,1);
  renderConditions(vid); markDirty();
}
function ungroup(vid, path){            // replace a group by its own conditions (removes the brackets)
  const [g,i] = splitPath(path);
  const list = listAt(vid, g), grp = list[i];
  const inner = grp.conditions || [];
  if(inner.length) inner[0].joiner = grp.joiner;
  list.splice(i, 1, ...inner);
  renderConditions(vid); markDirty();
}

const OP_CHOICES = [['>=','>='],['>','>'],['<=','<='],['<','<'],['==','=='],['!=','!='],['in','IN bypass'],['not_in','NOT IN bypass']];
function joinerSel(vid, path, c, first){
  return first ? '<span style="width:68px; flex:0 0 68px;"></span>'
    : `<select onchange="updateCond('${vid}','${path}','joiner',this.value)" style="flex:0 0 68px;">
        <option value="AND" ${c.joiner!=='OR'?'selected':''}>AND</option>
        <option value="OR" ${c.joiner==='OR'?'selected':''}>OR</option></select>`;
}
function leafRow(vid, path, c, first){
  const mode = c.mode || 'none';
  const isBp = BP_OPS.includes(c.op);
  return `
    <div class="cond-row">
      ${joinerSel(vid, path, c, first)}
      <select onchange="updateCond('${vid}','${path}','column',this.value)">${signalCols.map(s=>`<option ${s===c.column?'selected':''}>${s}</option>`).join('')}</select>
      <select onchange="updateCond('${vid}','${path}','op',this.value)" style="flex:0 0 ${isBp?'128px':'70px'};">
        ${OP_CHOICES.map(([o,l])=>`<option value="${o}" ${o===c.op?'selected':''}>${l}</option>`).join('')}
      </select>
      ${isBp
        ? `<select onchange="updateCond('${vid}','${path}','bypass',this.value)" title="Ranges are edited in the Bypass tab">${bpOptions(c.bypass)}</select>`
        : `<input type="number" step="any" value="${c.value}" onchange="updateCond('${vid}','${path}','value',this.value)">`}
      <select onchange="updateCond('${vid}','${path}','mode',this.value)" style="flex:0 0 128px;" title="None = instant check. Timer = must hold true for N seconds. Value tolerance = loosen the threshold by +/- an amount on this column (for a bypass: widen every range by that amount).">
        <option value="none" ${mode==='none'?'selected':''}>No tolerance</option>
        <option value="timer" ${mode==='timer'?'selected':''}>Timer (seconds)</option>
        <option value="tolerance" ${mode==='tolerance'?'selected':''}>${isBp?'Widen ranges (±)':'Value tolerance (±)'}</option>
      </select>
      ${mode!=='none' ? `<input type="number" step="any" min="0" value="${c.mode_value||0}" placeholder="${mode==='timer'?'seconds':'± amount'}" style="width:80px; flex:0 0 80px;" onchange="updateCond('${vid}','${path}','mode_value',this.value)">` : ''}
      <button class="danger small" title="Remove this condition" onclick="removeCondition('${vid}','${path}')">×</button>
    </div>`;
}
function groupBox(vid, path, c, first, depth){
  const mode = c.mode==='timer' ? 'timer' : 'none';
  const inner = c.conditions || [];
  return `
    <div class="cond-row">
      ${joinerSel(vid, path, c, first)}
      <b style="font-size:13px;">( Sub-logic</b>
      <select onchange="updateCond('${vid}','${path}','mode',this.value)" style="flex:0 0 190px;" title="Timer = this whole sub-logic must stay true for N seconds before it counts.">
        <option value="none" ${mode==='none'?'selected':''}>No timer</option>
        <option value="timer" ${mode==='timer'?'selected':''}>Whole sub-logic true for (s)</option>
      </select>
      ${mode==='timer' ? `<input type="number" step="any" min="0" value="${c.mode_value||0}" placeholder="seconds" style="width:80px; flex:0 0 80px;" onchange="updateCond('${vid}','${path}','mode_value',this.value)">` : ''}
      <button class="small" title="Remove the brackets but keep the conditions" onclick="ungroup('${vid}','${path}')">Ungroup</button>
      <button class="danger small" title="Remove this sub-logic" onclick="removeCondition('${vid}','${path}')">×</button>
    </div>
    <div style="margin:2px 0 8px 34px; padding:8px 10px; border:1px dashed var(--line); border-left:3px solid var(--line); border-radius:6px; background:var(--panel2);">
      ${renderCondList(vid, inner, path+'.', depth+1) || '<div class="hint" style="margin:0;">Empty — add a condition, otherwise this sub-logic is ignored.</div>'}
      <div class="toolbar" style="margin:6px 0 0;">
        <button class="secondary small" onclick="addCondition('${vid}','${path}')">+ Condition</button>
        ${depth+1 < MAX_GROUP_DEPTH ? `<button class="secondary small" onclick="addGroup('${vid}','${path}')">+ Sub-logic</button>` : ''}
        <b style="font-size:13px; margin-left:auto;">)</b>
      </div>
    </div>`;
}
function renderCondList(vid, list, prefix, depth){
  return (list||[]).map((c,i)=>{
    const path = prefix + i;
    return c.type==='group' ? groupBox(vid, path, c, i===0, depth) : leafRow(vid, path, c, i===0);
  }).join('');
}
function bpRisky(list){                 // a bypass that can't block its whole level (joined by OR, or an OR after it)
  return (list||[]).some((c,i)=> (c.type==='group' && bpRisky(c.conditions)) ||
    (BP_OPS.includes(c.op) && ((i>0 && c.joiner==='OR') || list.slice(i+1).some(x=>x.joiner==='OR'))));
}
function logicText(list){               // the logic written out with brackets, for the preview line
  return (list||[]).map((c,i)=>{
    const j = i ? ' '+(c.joiner==='OR'?'OR':'AND')+' ' : '';
    if(c.type==='group'){
      const t = '( '+(logicText(c.conditions)||'empty')+' )';
      return j + (c.mode==='timer' && c.mode_value ? t+' for ≥'+c.mode_value+'s' : t);
    }
    const v = BP_OPS.includes(c.op) ? (c.op==='in'?'IN ':'NOT IN ')+bpName(c.bypass) : c.op+' '+c.value;
    return j + c.column+' '+v;
  }).join('');
}
function readsAs(v){ return v.conditions.length ? '<b>Reads as:</b> '+esc(logicText(v.conditions)) : ''; }
function renderConditions(vid){
  const v = versionOf(vid);
  $('conds_'+vid).innerHTML = renderCondList(vid, v.conditions, '', 0)
  + `<div class="hint" id="readas_${vid}" style="margin:6px 0 0;">${readsAs(v)}</div>`
  + (bpRisky(v.conditions) ? '<div class="hint warn">⚠ A bypass only blocks its own level (the whole rule, or the sub-logic it is in) when it is joined with AND and no OR comes after it on that level. Put the IN / NOT IN condition last on its level, joined with AND — or put the ORs inside a sub-logic.</div>' : '')
  + '<div class="hint">Each level is evaluated in order, top to bottom — e.g. A AND B OR C means (A AND B) OR C. Use <b>sub-logic</b> for brackets: Signal == 1 AND ( ControlON == 1 OR ( MachineOn == 0 AND Key == 0 ) ). A sub-logic can have its own timer (the whole bracket must stay true for N seconds). Timer on a condition = it must hold continuously for N seconds (resets instantly if it goes false). Value tolerance = loosens the threshold on this column. NOT IN bypass = false while the column is inside any range of that bypass (Bypass tab).</div>';
}
function updateCond(vid, path, field, val){
  const c = condAt(vid, path);
  c[field] = (field==='value' || field==='mode_value') ? parseFloat(val) : val;
  if(field==='op' && BP_OPS.includes(val) && !c.bypass){ const first = bpList()[0]; c.bypass = first ? first[0] : ''; }
  if(field==='op' && !BP_OPS.includes(val)) delete c.bypass;
  if(field==='mode' || field==='op' || field==='joiner') renderConditions(vid);
  else { const el = $('readas_'+vid); if(el) el.innerHTML = readsAs(versionOf(vid)); }
  markDirty();
}

// ============================================================
// BYPASS TAB — every bypass of this terminal / type on one page; used by IN / NOT IN conditions in the Logic tab
// ============================================================
const BP_OPS = ['in','not_in'];
let bypasses = {};          // id -> {name, description, versions:[{id, effective_from, ranges:[{from, to, note}]}]}
let bpDirty = false;

function byEff(a,b){ return (a.effective_from? new Date(a.effective_from).getTime():-Infinity) - (b.effective_from? new Date(b.effective_from).getTime():-Infinity); }
function bpList(){ return Object.entries(bypasses).sort((a,b)=>String(a[1].name||'').localeCompare(String(b[1].name||''))); }
function bpName(id){ return bypasses[id] ? (bypasses[id].name || '(no name)') : '(missing bypass)'; }
function bpUsedBy(id){
  return Object.keys(rules).filter(f=>(rules[f].versions||[]).some(v=>leafConds(v.conditions).some(c=>BP_OPS.includes(c.op) && c.bypass===id))).sort();
}
function bpOptions(sel){
  const list = bpList();
  if(!list.length) return '<option value="">— create one in the Bypass tab —</option>';
  let h = (sel && !bypasses[sel]) ? '<option value="'+escAttr(sel)+'" selected>(missing bypass)</option>' : '';
  if(!sel) h += '<option value="" selected>— pick a bypass —</option>';
  return h + list.map(([id,b])=>`<option value="${escAttr(id)}" ${id===sel?'selected':''}>${esc(b.name||'(no name)')}</option>`).join('');
}
function setBpMsg(text, cls){ const el = $('bpMsg'); if(el){ el.textContent = text; el.className = 'hint '+(cls||''); } }
function markBpDirty(){ bpDirty = true; setBpMsg('Unsaved changes','warn'); }

function addBypass(){
  const id = 'bp'+Date.now();
  bypasses[id] = {name:'New bypass '+(Object.keys(bypasses).length+1), description:'', versions:[{id:'bv'+Date.now(), effective_from:null, ranges:[{from:'', to:'', note:''}]}]};
  markBpDirty(); renderBypasses();
  const el = $('bpcard_'+id); if(el){ el.scrollIntoView({behavior:'smooth', block:'start'}); const n = $('bpname_'+id); if(n){ n.focus(); n.select(); } }
}
function deleteBypass(id){
  const used = bpUsedBy(id);
  if(used.length){ alert('This bypass is used by: '+used.join(', ')+'.\nRemove it from those logics first.'); return; }
  if(!confirm('Delete the bypass "'+bpName(id)+'"?')) return;
  delete bypasses[id]; markBpDirty(); renderBypasses();
}
function setBpField(id, field, val){
  bypasses[id][field] = val; markBpDirty();
  if(field==='name'){ const t = $('bptitle_'+id); if(t) t.textContent = val || '(no name)'; }
}
function bpVersion(id, vid){ return bypasses[id].versions.find(v=>v.id===vid); }
function addBpVersion(id){
  const b = bypasses[id];
  const last = [...b.versions].sort(byEff).pop();
  b.versions.push({id:'bv'+Date.now(), effective_from: new Date().toISOString().slice(0,10)+'T00:00:00',
                   ranges: JSON.parse(JSON.stringify(last ? last.ranges : [{from:'', to:'', note:''}]))});
  markBpDirty(); renderBypasses();
}
function deleteBpVersion(id, vid){
  const b = bypasses[id];
  if(b.versions.length<=1) return;
  b.versions = b.versions.filter(v=>v.id!==vid); markBpDirty(); renderBypasses();
}
function setBpVersionDate(id, vid, val){ bpVersion(id, vid).effective_from = val ? val+'T00:00:00' : null; markBpDirty(); renderBypasses(); }
function addBpRange(id, vid){ bpVersion(id, vid).ranges.push({from:'', to:'', note:''}); markBpDirty(); renderBypasses(); }
function delBpRange(id, vid, j){ bpVersion(id, vid).ranges.splice(j,1); markBpDirty(); renderBypasses(); }
function setBpRange(id, vid, j, field, val){
  bpVersion(id, vid).ranges[j][field] = (field==='note') ? val : (val==='' ? '' : parseFloat(val));
  markBpDirty();
}

function bypassCard(id, b){
  const used = bpUsedBy(id);
  const sorted = [...b.versions].sort(byEff);
  const versionsHtml = sorted.map((v,i)=>`<div class="version-card">
      <div class="vh"><b>${versionLabel(v, sorted[i+1])}</b>
        ${b.versions.length>1 ? `<button class="danger small" onclick="deleteBpVersion('${id}','${v.id}')">Delete version</button>` : ''}</div>
      <div class="field" style="max-width:220px; margin-bottom:10px;">
        <label>Effective from date (blank = start of data)</label>
        <input type="date" value="${v.effective_from ? v.effective_from.slice(0,10) : ''}" onchange="setBpVersionDate('${id}','${v.id}', this.value)">
      </div>
      <table><thead><tr><th>From</th><th>To</th><th>Note (optional)</th><th></th></tr></thead><tbody>
        ${v.ranges.map((r,j)=>`<tr>
          <td><input type="number" step="any" value="${r.from===''||r.from==null?'':r.from}" onchange="setBpRange('${id}','${v.id}',${j},'from',this.value)"></td>
          <td><input type="number" step="any" value="${r.to===''||r.to==null?'':r.to}" onchange="setBpRange('${id}','${v.id}',${j},'to',this.value)"></td>
          <td><input type="text" value="${escAttr(r.note||'')}" onchange="setBpRange('${id}','${v.id}',${j},'note',this.value)"></td>
          <td style="text-align:right;"><button class="danger small" title="Remove this range" onclick="delBpRange('${id}','${v.id}',${j})">×</button></td></tr>`).join('')
          || '<tr><td colspan="4" class="hint">No ranges — this version bypasses nothing.</td></tr>'}
      </tbody></table>
      <button class="secondary small" style="margin-top:6px;" onclick="addBpRange('${id}','${v.id}')">+ Add range</button>
    </div>`).join('');
  return `<div class="panel" id="bpcard_${id}">
    <h2 style="display:flex; align-items:center; gap:10px;"><span id="bptitle_${id}">${esc(b.name||'(no name)')}</span>
      <span class="badge">${used.length} fault${used.length!==1?'s':''}</span></h2>
    <div class="form-row"><label for="bpname_${id}">Name</label><div><input type="text" id="bpname_${id}" maxlength="60" value="${escAttr(b.name||'')}" oninput="setBpField('${id}','name', this.value)"></div></div>
    <div class="form-row"><label for="bpdesc_${id}">Description</label><div><input type="text" id="bpdesc_${id}" value="${escAttr(b.description||'')}" placeholder="e.g. hatch-cover area, gantry position in mm" oninput="setBpField('${id}','description', this.value)"></div></div>
    <div class="hint" style="margin:0 0 12px;">Used by: ${used.length ? used.map(esc).join(', ') : 'no fault yet'}</div>
    ${versionsHtml}
    <div class="toolbar" style="margin-top:8px;">
      <button class="secondary small" onclick="addBpVersion('${id}')">+ Add version (ranges changed on a date)</button>
      <button class="small danger" onclick="deleteBypass('${id}')" ${used.length ? 'disabled title="Remove it from the logics that use it first"' : ''}>Delete this bypass</button>
    </div>
  </div>`;
}

function renderBypasses(){
  if(!$('bpBox')) return;
  const list = bpList();
  $('bpScope').textContent = progLabel();
  $('bpCount').textContent = list.length;
  $('bpBox').innerHTML = list.map(([id,b])=>bypassCard(id,b)).join('')
    || '<div class="panel"><div class="hint" style="margin:0;">No bypasses yet for this terminal / type — press “+ New bypass”.</div></div>';
  if(bpDirty) setBpMsg('Unsaved changes','warn');
}

// ============================================================
// EVALUATE TAB
// ============================================================
let scopeData = [];
const scopeSel = {programs:new Set(), known:new Set(), allMachines:true, machines:new Set(), from:'', to:''};
try{ const d = JSON.parse(localStorage.getItem('fddEvalDates')||'{}'); scopeSel.from = d.from||''; scopeSel.to = d.to||''; }catch(e){}
function setScopeDate(which, val){
  scopeSel[which] = val||'';
  try{ localStorage.setItem('fddEvalDates', JSON.stringify({from:scopeSel.from, to:scopeSel.to})); }catch(e){}
  renderScope();
}
function datesLabel(f, t){ return (f||t) ? (f||'start of data')+' → '+(t||'latest data') : 'all dates'; }

async function loadScope(){
  let d;
  try{ d = await (await fetch('/api/scope')).json(); }
  catch(e){ $('scopeBox').innerHTML = '<div class="hint err" style="margin:0;">⚠ '+esc(e.message)+'</div>'; return; }
  scopeData = d.programs || [];
  scopeData.forEach(p=>{ if(!scopeSel.known.has(p.key)){ scopeSel.known.add(p.key); scopeSel.programs.add(p.key); } });
  [...scopeSel.programs].forEach(k=>{ if(!scopeData.some(p=>p.key===k)) scopeSel.programs.delete(k); });
  renderScope();
}
function scopeMachines(){
  return [...new Set(scopeData.filter(p=>scopeSel.programs.has(p.key)).flatMap(p=>p.machines||[]))].sort();
}
function renderScope(){
  const terms = [...new Set(scopeData.map(p=>p.terminal))];
  const ms = scopeMachines(); window._scopeMachines = ms;
  const termChips = terms.map(t=>{
    const ps = scopeData.filter(p=>p.terminal===t), n = ps.filter(p=>scopeSel.programs.has(p.key)).length;
    return `<label class="chip"><input type="checkbox" ${n===ps.length?'checked':''} onchange="toggleTerminal(this.dataset.t, this.checked)" data-t="${escAttr(t)}"> Terminal ${esc(t)}</label>`;
  }).join('');
  const progChips = scopeData.map(p=>`<label class="chip" title="${p.faults} fault(s) with logic"><input type="checkbox" ${scopeSel.programs.has(p.key)?'checked':''} onchange="toggleProgram(this.dataset.k, this.checked)" data-k="${escAttr(p.key)}"> ${esc(p.terminal)} · ${esc(p.type)}${p.configured?'':' <span class="muted">(not set up)</span>'}</label>`).join('');
  const machChips = ms.map((m,i)=>`<label class="chip"><input type="checkbox" ${(scopeSel.allMachines||scopeSel.machines.has(m))?'checked':''} ${scopeSel.allMachines?'disabled':''} onchange="toggleMachine(${i}, this.checked)"> ${esc(m)}</label>`).join('');
  const nM = scopeSel.allMachines ? ms.length : ms.filter(m=>scopeSel.machines.has(m)).length;
  $('scopeBox').innerHTML = `
    <div class="scope-row"><label>Terminals</label><div class="chips">${termChips || '<span class="hint" style="margin:0;">None yet.</span>'}</div></div>
    <div class="scope-row"><label>Types</label><div class="chips">${progChips}</div></div>
    <div class="scope-row"><label>Machines</label><div class="chips">
      <label class="chip"><input type="checkbox" ${scopeSel.allMachines?'checked':''} onchange="toggleAllMachines(this.checked)"> All machines</label>${machChips}
      ${ms.length ? '' : '<span class="hint" style="margin:0;">Machines appear after you save settings with a machine column.</span>'}</div></div>
    <div class="scope-row"><label>Dates</label><div class="chips">
      <label class="hint" style="margin:0; display:flex; gap:6px; align-items:center;">From <input type="date" style="width:auto;" value="${escAttr(scopeSel.from)}" onchange="setScopeDate('from', this.value)"></label>
      <label class="hint" style="margin:0; display:flex; gap:6px; align-items:center;">To <input type="date" style="width:auto;" value="${escAttr(scopeSel.to)}" onchange="setScopeDate('to', this.value)"></label>
      <button class="small" onclick="setScopeDate('from',''); setScopeDate('to','')">All dates</button>
      <span class="hint" style="margin:0;">Blank = no limit. A short range evaluates much faster; the whole “To” day is included.</span></div></div>
    ${(scopeSel.from && scopeSel.to && scopeSel.from > scopeSel.to) ? '<div class="hint err" style="margin:6px 0 0;">⚠ From is after To.</div>' : ''}
    <div class="hint" style="margin:6px 0 0;">${scopeSel.programs.size} type(s) · ${nM} machine(s) · ${esc(datesLabel(scopeSel.from, scopeSel.to))}</div>`;
}
function toggleTerminal(t, on){ scopeData.filter(p=>p.terminal===t).forEach(p=>on ? scopeSel.programs.add(p.key) : scopeSel.programs.delete(p.key)); renderScope(); }
function toggleProgram(k, on){ on ? scopeSel.programs.add(k) : scopeSel.programs.delete(k); renderScope(); }
function toggleAllMachines(on){ scopeSel.allMachines = on; if(!on) scopeSel.machines = new Set(scopeMachines()); renderScope(); }
function toggleMachine(i, on){ const m = window._scopeMachines[i]; on ? scopeSel.machines.add(m) : scopeSel.machines.delete(m); renderScope(); }

$('evalAllBtn').addEventListener('click', async ()=>{
  const say = (t, cls)=>{ $('evalAllErr').textContent = t; $('evalAllErr').className = 'hint '+(cls||''); };
  if(!scopeSel.programs.size){ say('Select at least one terminal / type.', 'err'); return; }
  let machines = null;
  if(!scopeSel.allMachines){
    machines = scopeMachines().filter(m=>scopeSel.machines.has(m));
    if(!machines.length){ say('Select at least one machine (or tick All machines).', 'err'); return; }
  }
  if(scopeSel.from && scopeSel.to && scopeSel.from > scopeSel.to){ say('The From date is after the To date.', 'err'); return; }
  say('Evaluating…', ''); $('evalAllBtn').disabled = true;
  const data = await postJSON('/api/evaluate_all', {scope:{programs:[...scopeSel.programs], machines, from:scopeSel.from||null, to:scopeSel.to||null}});
  $('evalAllBtn').disabled = false;
  if(!data.ok){ say('⚠ '+data.error, 'err'); return; }
  window._lastScopeMachines = machines;
  window._lastScopeDates = {from:scopeSel.from||null, to:scopeSel.to||null};
  if(data.handoff_saved && (data.date_from || data.date_to)) say('Results saved for the Root Causes program ✓ — covering '+datesLabel(data.date_from, data.date_to)+' only. Evaluate with all dates to give Root Causes the full history.', 'ok');
  else if(data.handoff_saved) say('Results saved for the Root Causes program ✓', 'ok');
  else say('A machine filter is on, so these results were NOT saved for Root Causes. Evaluate all machines to refresh them.', 'warn');
  renderSummary(data.summary);
});

function pct(v){ return v!=null ? (v*100).toFixed(0)+'%' : '—'; }
function renderSummary(summary){
  window._summary = summary;
  const valid = summary.filter(s=>!s.error);
  const tp = valid.reduce((a,s)=>a+s.tp,0), fp = valid.reduce((a,s)=>a+s.fp,0), fn = valid.reduce((a,s)=>a+s.fn,0);
  const noData = valid.reduce((a,s)=>a+(s.no_data||0),0);
  const precision = (tp+fp)? tp/(tp+fp) : null, recall=(tp+fn)? tp/(tp+fn) : null;
  const f1 = (precision!=null && recall!=null && (precision+recall)>0) ? 2*precision*recall/(precision+recall) : null;
  $('overallCards').innerHTML = `<div class="cards">
      <div class="card tp"><div class="v">${tp}</div><div class="l">Total TP</div></div>
      <div class="card fn"><div class="v">${fn}</div><div class="l">Total FN (genuine misses)</div></div>
      <div class="card fp"><div class="v">${fp}</div><div class="l">Total FP</div></div>
      <div class="card"><div class="v">${noData}</div><div class="l">No PLC data (excluded from recall)</div></div>
      <div class="card"><div class="v">${pct(precision)}</div><div class="l">Overall precision</div></div>
      <div class="card"><div class="v">${pct(recall)}</div><div class="l">Overall recall</div></div>
      <div class="card"><div class="v">${pct(f1)}</div><div class="l">Overall F1</div></div>
    </div>`;
  $('summaryTable').querySelector('tbody').innerHTML = summary.map((s,i)=>{
    const where = `${esc(s.terminal)} · ${esc(s.type)}`;
    if(s.error) return `<tr><td>${where}</td><td>${esc(s.fault)}</td><td colspan="9" class="hint err" style="margin:0;">⚠ ${esc(s.error)}</td></tr>`;
    return `<tr class="clickable" onclick="showDetailAt(${i})">
      <td>${where}</td><td>${esc(s.fault)}</td><td>${s.ground_truth_count}</td><td>${s.predicted_intervals}</td>
      <td>${s.tp}</td><td>${s.fp}</td><td>${s.fn}</td><td>${s.no_data||0}</td>
      <td>${pct(s.precision)}</td><td>${pct(s.recall)}</td><td>${pct(s.f1)}</td></tr>`;
  }).join('') || '<tr><td colspan="11" class="hint">No faults with rule logic in the selected types yet — define some in the Logic tab.</td></tr>';
}

function showDetailAt(i){ const s = window._summary[i]; showDetail(s.program, s.fault, s.program_label); }
async function showDetail(program, fault, label){
  $('detailPanel').style.display='block';
  const dd = window._lastScopeDates || {};
  $('detailTitle').textContent = fault + (label ? ' — '+label : '') + ((dd.from||dd.to) ? ' — '+datesLabel(dd.from, dd.to) : '');
  $('detailBody').innerHTML = '<div class="hint" style="margin:0;">Loading…</div>';
  const dts = window._lastScopeDates || {};
  const data = await postJSON('/api/evaluate', {program, fault, machines: window._lastScopeMachines || null, from: dts.from || null, to: dts.to || null});
  if(!data.ok){ $('detailBody').innerHTML = '<div class="hint err" style="margin:0;">⚠ '+esc(data.error)+'</div>'; return; }
  const encFault = encodeURIComponent(fault), encProg = encodeURIComponent(program);
  const statusLabel = {matched:'Matched', missed:'Missed', no_data:'No PLC data'};
  const statusClass = {matched:'matched', missed:'missed', no_data:'nodata'};
  const hasM = data.matched_events.some(m=>m.machine);
  const hasMx = data.extra_intervals.some(iv=>iv.machine);
  $('detailBody').innerHTML = `
    <div class="toolbar">
      <button class="small" onclick="window.open('/api/export/${encProg}/${encFault}/matched','_blank')">Export matched events CSV</button>
      <button class="small" onclick="window.open('/api/export/${encProg}/${encFault}/extra','_blank')">Export extra intervals CSV</button>
      <button class="small" onclick="window.open('/api/export/${encProg}/${encFault}/all','_blank')">Export all predicted intervals CSV</button>
    </div>
    <div style="margin-top:10px;"><b style="font-size:14px;">Ground truth events (${data.ground_truth_count})</b> <span class="hint" style="margin:0;">— “No PLC data” events are excluded from the recall calculation</span></div>
    <table><thead><tr>${hasM?'<th>Machine</th>':''}<th>Coming</th><th>Going</th><th>Status</th><th>Δ vs predicted</th></tr></thead><tbody>
      ${data.matched_events.map(m=>`<tr>${hasM?`<td>${esc(m.machine||'')}</td>`:''}<td>${esc(m.coming)}</td><td>${esc(m.going||'')}</td>
        <td><span class="pill ${statusClass[m.status]||m.status}">${statusLabel[m.status]||m.status}</span></td>
        <td>${m.delta_seconds!=null ? (+m.delta_seconds).toFixed(2)+'s' : '—'}</td></tr>`).join('') || '<tr><td colspan="5" class="hint">No matching events found in the fault history for this exact fault name.</td></tr>'}
    </tbody></table>
    ${data.matched_truncated?'<div class="hint">Showing first 500 — export CSV for the full list.</div>':''}
    <div style="margin-top:14px;"><b style="font-size:14px;">Predicted intervals with no matching actual event (${data.interval_count - data.tp})</b></div>
    <table><thead><tr>${hasMx?'<th>Machine</th>':''}<th>Start</th><th>End</th></tr></thead><tbody>
      ${data.extra_intervals.map(iv=>`<tr>${hasMx?`<td>${esc(iv.machine||'')}</td>`:''}<td>${esc(iv.start)}</td><td>${esc(iv.end)}</td></tr>`).join('') || '<tr><td colspan="3" class="hint">None</td></tr>'}
    </tbody></table>
    ${data.extra_truncated?'<div class="hint">Showing first 500 — export CSV for the full list.</div>':''}
  `;
}

// ============================================================
// Copy / move a logic to another terminal / type
// ============================================================
function progLabel(){ const p = programs.find(p=>p.key===activeKey); return p ? 'Terminal '+p.terminal+' · Type '+p.type : ''; }
async function copyLogic(move){
  if(!selectedFault || !(rules[selectedFault]?.versions||[]).length){ alert('Define and save some logic for this fault first.'); return; }
  await saveIfDirty();
  const pick = await askProgram({title:(move?'Move':'Copy')+' “'+selectedFault+'” to…',
    intro:'The logic'+(move?' is moved (it is removed from '+esc(progLabel())+')':' is copied (the original stays in '+esc(progLabel())+')')+'. Its root-cause names and groupings go with it. Pick the terminal and type, or create a new type.'});
  if(!pick) return;
  let r = await postJSON('/api/logic/copy', {fault:selectedFault, terminal:pick.terminal, type:pick.type, move});
  if(!r.ok && r.exists && confirm(r.error+' Replace it?')) r = await postJSON('/api/logic/copy', {fault:selectedFault, terminal:pick.terminal, type:pick.type, move, overwrite:true});
  if(!r.ok){ if(!r.exists) alert(r.error); return; }
  programs = r.programs; terminals = r.terminals;
  rules = r.rules; renderProgBar(); renderFaultList(); renderRulePanel();
  alert((move?'Moved':'Copied')+' to '+r.program_label+'.\n\n'+r.note);
}

// ============================================================
// NAS SYNC (Settings tab)
// ============================================================
let nas = {config:{}, machines:[], status:{}};
const NAS_FIELDS = {nas_url:'url', nas_org:'org', nas_bucket:'bucket', nas_tag:'machine_tag', nas_measurement:'measurement',
  nas_interval:'interval_minutes', nas_tz:'timezone', nas_overlap:'overlap_minutes', nas_chunk:'chunk_hours', nas_start:'history_start',
  nas_tscol:'ts_col', nas_mcol:'machine_col', nas_timefield:'time_field'};
function nasSay(t, cls){ const el=$('nasMsg'); el.textContent=t; el.className='hint '+(cls||''); }
function nasFill(){
  const c = nas.config;
  Object.entries(NAS_FIELDS).forEach(([id,k])=>{ $(id).value = c[k] ?? ''; });
  $('nas_token').value = ''; $('nas_token').placeholder = c.has_token ? '•••••••• saved — leave blank to keep' : 'InfluxDB API token';
  $('nas_enabled').checked = !!c.enabled; $('nas_autoeval').checked = !!c.auto_evaluate;
  renderNasMachines(); renderNasStatus();
}
function nasCollect(){
  const b = {enabled:$('nas_enabled').checked, auto_evaluate:$('nas_autoeval').checked, token:$('nas_token').value.trim(), machines:{}};
  Object.entries(NAS_FIELDS).forEach(([id,k])=>{ b[k] = $(id).value; });
  nas.machines.forEach(m=>{ b.machines[m.name] = {terminal:m.terminal, timeline:m.timeline}; });
  return b;
}
async function nasLoad(){
  try{ nas = await (await fetch('/api/nas/config')).json(); nasFill(); } catch(e){ nasSay('⚠ '+e.message,'err'); }
}
async function nasSave(quiet){
  const r = await postJSON('/api/nas/config', nasCollect());
  if(!r.ok){ nasSay('⚠ '+r.error,'err'); return false; }
  nas = r; nasFill(); if(!quiet) nasSay('Saved ✓','ok'); return true;
}
async function nasTest(){
  nasSay('Testing…','');
  const b = nasCollect(); const r = await postJSON('/api/nas/test', {url:b.url, org:b.org, bucket:b.bucket, token:b.token, measurement:b.measurement, machine_tag:b.machine_tag});
  nasSay(r.ok ? '✓ '+r.message : '⚠ '+r.error, r.ok?'ok':'err');
}
async function nasDiscover(){
  if(!(await nasSave(true))) return;
  nasSay('Looking for machines…','');
  const r = await postJSON('/api/nas/discover', {});
  if(!r.ok){ nasSay('⚠ '+r.error,'err'); return; }
  nas = r; nasFill();
  nasSay('Found '+r.found+' machine(s), '+r.added+' new. Give the new ones a PLC type below, then Save NAS settings.', 'ok');
}
async function nasSyncNow(){
  if(!(await nasSave(true))) return;
  const r = await postJSON('/api/nas/sync', {});
  nasSay(r.ok ? 'Sync started…' : '⚠ '+r.error, r.ok?'':'err');
  setTimeout(nasRefreshStatus, 800);
}
async function nasRefreshStatus(){
  try{ const r = await (await fetch('/api/nas/config')).json(); const was = nas.status && nas.status.running; nas.status = r.status;
       if(was && !r.status.running) nasAfterSync();
       r.machines.forEach(m=>{ const mine = nas.machines.find(x=>x.name===m.name); if(mine) mine.last_row = m.last_row; else nas.machines.push(m); });
       renderNasStatus(); renderNasMachines(true); } catch(e){}
}
function renderNasStatus(){
  const s = nas.status || {}, c = nas.config || {};
  const when = t => t ? new Date(t).toLocaleString() : '—';
  let h = '';
  if(s.running) h += `<div class="notice info">Syncing… ${esc(s.step||'')} ${s.total? '('+s.done+' of '+s.total+' machines)':''}</div>`;
  if(s.last_error) h += `<div class="notice err">⚠ ${esc(s.last_error)}</div>`;
  const r = s.last_result;
  let line = `Last sync: <b>${when(s.last_attempt)}</b>${s.last_ok?'':''} &nbsp;•&nbsp; Next: <b>${c.enabled && s.next_due ? when(s.next_due) : 'automatic sync is off'}</b>`;
  if(r && !r.error){
    line += ` &nbsp;•&nbsp; ${(r.added_total||0).toLocaleString()} new row(s) stored`;
    if((r.programs_updated||[]).length) line += ` in ${r.programs_updated.length} program(s)`;
    if(r.evaluation) line += ` &nbsp;•&nbsp; Evaluation ran for ${r.evaluation.faults} fault(s)`;
    if(r.evaluation && r.evaluation.skipped && r.evaluation.skipped.length) h += `<div class="notice warn">Evaluation skipped: ${esc(r.evaluation.skipped.join(' | '))}</div>`;
  }
  h += `<div class="hint" style="margin:0;">${line}</div>`;
  const un = (nas.machines||[]).filter(m=>!m.timeline.length).length;
  if(un) h += `<div class="notice warn" style="margin-top:8px;">${un} machine(s) have no PLC type yet — their data is not pulled until you give them one.</div>`;
  $('nasStatus').innerHTML = h;
  $('nasSyncBtn').disabled = !!s.running;
}
const nasSel = new Set();
function nasSelect(i,on){ on ? nasSel.add(nas.machines[i].name) : nasSel.delete(nas.machines[i].name); }
function nasSelectAll(on){ nas.machines.forEach(m=> on ? nasSel.add(m.name) : nasSel.delete(m.name)); renderNasMachines(); }
async function nasResync(){
  const names = nas.machines.filter(m=>nasSel.has(m.name) && m.timeline.length).map(m=>m.name);
  if(!names.length){ nasSay('Tick at least one machine that has a PLC type.','err'); return; }
  const from = $('nasResyncFrom').value;
  if(!confirm('Copy the data of '+names.length+' machine(s) from the NAS again'+(from?' starting '+from:' from the first-load date')+'? Rows already stored are not duplicated.')) return;
  if(!(await nasSave(true))) return;
  const r = await postJSON('/api/nas/resync', {machines:names, since:from});
  nasSay(r.ok ? 'Re-sync started for '+names.length+' machine(s)…' : '⚠ '+r.error, r.ok?'':'err');
  setTimeout(nasRefreshStatus, 800);
}
async function nasAfterSync(){
  try{
    const v = await fetch('/api/plc_store/view').then(r=>r.json());
    if(v.exists){ cols.plc = v.columns; cols.plc_numeric = v.numeric_columns || []; maybePopulateSettingsTab(); }
  }catch(e){}
}
function renderNasMachines(statusOnly){
  const ae = document.activeElement;
  if(statusOnly && ae && $('nasMachineTable').contains(ae)) return;      // don't disturb someone who is typing
  const ts = [...new Set(nas.machines.map(m=>m.terminal || m.terminal_auto))].sort();
  const bt = $('nasBulkTerm'), cur = bt.value;
  bt.innerHTML = '<option value="">all</option>' + ts.map(t=>`<option>${esc(t)}</option>`).join(''); bt.value = ts.includes(cur) ? cur : '';
  $('nasMachineTable').querySelector('tbody').innerHTML = nas.machines.map((m,i)=>`<tr>
    <td><input type="checkbox" ${nasSel.has(m.name)?'checked':''} onchange="nasSelect(${i},this.checked)" aria-label="Select ${escAttr(m.name)}"></td>
    <td class="nowrap">${esc(m.name)}</td>
    <td><input type="text" style="width:90px;" value="${escAttr(m.terminal)}" placeholder="${escAttr(m.terminal_auto)} (auto)" oninput="nasSetTerm(${i},this.value)"></td>
    <td>${m.timeline.map((e,j)=>`<div class="file-row" style="margin-bottom:4px;">
        ${j===0 ? '<span class="hint" style="margin:0; width:92px;">from start</span>' : `<input type="date" style="width:150px;" value="${escAttr(e.from)}" oninput="nasSetEntry(${i},${j},'from',this.value)">`}
        <input type="text" style="width:110px;" value="${escAttr(e.type)}" placeholder="type, e.g. A" maxlength="30" oninput="nasSetEntry(${i},${j},'type',this.value)">
        <button class="small danger" title="Remove" onclick="nasDelEntry(${i},${j})">×</button></div>`).join('')}
      <button class="small" onclick="nasAddEntry(${i})">${m.timeline.length ? '+ Changed to another type on a date' : '+ Set PLC type'}</button></td>
    <td class="nowrap">${esc(m.last_row||'—')}</td></tr>`).join('')
    || '<tr><td colspan="5" class="hint">No machines yet — press “Find machines” (after Save and Test).</td></tr>';
}
function nasSetTerm(i,v){ nas.machines[i].terminal = v.trim(); nasSay('Unsaved changes','warn'); }
function nasSetEntry(i,j,k,v){ nas.machines[i].timeline[j][k] = v; nasSay('Unsaved changes','warn'); }
function nasAddEntry(i){ const t = nas.machines[i].timeline; t.push({from:'', type: t.length ? t[t.length-1].type : ''}); renderNasMachines(); renderNasStatus(); nasSay('Unsaved changes','warn'); }
function nasDelEntry(i,j){ nas.machines[i].timeline.splice(j,1); renderNasMachines(); renderNasStatus(); nasSay('Unsaved changes','warn'); }
function nasBulk(){
  const ty = $('nasBulkType').value.trim(), tm = $('nasBulkTerm').value;
  if(!ty){ $('nasBulkType').focus(); return; }
  nas.machines.forEach(m=>{ if(!m.timeline.length && (!tm || (m.terminal||m.terminal_auto)===tm)) m.timeline.push({from:'', type:ty}); });
  renderNasMachines(); renderNasStatus(); nasSay('Unsaved changes — press Save NAS settings','warn');
}
setInterval(()=>{ if($('tab-files').classList.contains('active')) nasRefreshStatus(); }, 5000);
nasLoad();

// ============================================================
// Boot: (re)load everything for the active terminal / type
// ============================================================
function resetProgramState(){
  cols = {master:[], plc:[], plc_numeric:[], faults:[]};
  signalCols = []; masterFaults = []; selectedFault = null; dirty = false; settingsPopulated = false;
  $('rulePanel').innerHTML = '<div class="hint">Select a fault on the left to define or edit its logic. Pick another fault any time to continue — unsaved edits are saved automatically when you switch.</div>';
  $('logicStats').innerHTML = '<span class="hint" style="margin:0;">Save settings first to see this type’s fault list here.</span>';
  $('plcStoreView').innerHTML = '<div class="hint" style="margin:0;">Click “View stored data” to see what is saved inside the app for this type, and to delete a machine’s data or everything.</div>';
  $('applyErr').textContent = ''; $('applyErr').className = 'hint';
  renderFaultList();
}

async function loadProgram(){
  setStatus('Loading terminal / type…','attn');
  const s = await (await fetch('/api/settings')).json();
  settings = s.settings; programs = s.programs; terminals = s.terminals; activeKey = s.active;
  renderProgBar();
  cfg = {
    tolerance_seconds: settings.mapping.tolerance_seconds ?? 1,
    max_gap_seconds: settings.mapping.max_gap_seconds ?? 2,
    min_duration_seconds: settings.mapping.min_duration_seconds ?? 0,
  };
  rules = settings.rules || {};
  bypasses = settings.bypasses || {}; bpDirty = false;
  resetProgramState();
  setBpMsg(''); renderBypasses();
  plcPaths = []; plcStatus = [];     // PLC data comes from the NAS, not from files
  ['master','faults'].forEach(renderFileRow);

  suppressAutoApply = true;   // load everything first, then apply the saved mapping once
  if(settings.paths.master) await loadPath('master');
  if(settings.paths.faults) await loadPath('faults');
  if(!cols.plc.length){       // PLC files unreachable — this type's permanent store may still hold the data
    const v = await fetch('/api/plc_store/view').then(r=>r.json());
    if(v.exists){ cols.plc = v.columns; cols.plc_numeric = v.numeric_columns || []; }
  }
  suppressAutoApply = false;
  maybePopulateSettingsTab();
  setStatus(READY_TEXT,'ok');
}
loadProgram();
</script>
</body>
</html>

"""

if __name__ == "__main__":
    nas_sync.start_scheduler(NAS_HOST)     # pulls from the NAS every N minutes for as long as the app is open
    run_server(app, PORT_RULE_BUILDER, "FDD Rule Builder & Backtester")
