Put your company logo in this folder, named  logo.png  (or logo.svg / logo.jpg).
It shows top-left (64 px high) and is used as the browser-tab icon.
No logo here? The slot shows an "Add logo" button instead.
