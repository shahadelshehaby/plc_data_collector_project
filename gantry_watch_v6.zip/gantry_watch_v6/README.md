# Gantry Watch

Analyzes 1-second PLC exports from the cranes and produces, per day:

- one PDF per crane;
- a `Summary_<date>.pdf`;
- an `Operation_<date>.pdf`.

Everything is run, tuned and downloaded from a browser page. No reports folder is created; you download what you need.

## Start it

1. Install [Python 3.10+](https://www.python.org/downloads/). On Windows, tick **Add python.exe to PATH** during install. You only need to do this once per computer.
2. Double-click **run.bat** (Windows) or **run.sh** (Mac/Linux).
3. Your browser opens **http://localhost:8765**. Keep the black console window open while you work; closing it stops the analyzer.

The first start installs the required packages, so it needs internet once.

## Use it

**PLC data tab.** Data arrives in two ways: pulled automatically from InfluxDB on the NAS (see *NAS sync* below), or uploaded by hand. To upload, drop files on the box or click it to choose them (.xlsx, .xls or .csv; one file per crane per day). Each file is stored and analyzed once.

Raw InfluxDB downloads can be uploaded as they are, without cleaning them in Excel first. The 3 annotation rows at the top (#group, #datatype, #default) and the empty, result and table columns are removed automatically. The Source column shows whether a file came from the NAS or an upload.

- The crane comes from the start of the file name: `B203_2026-07-01.xlsx` is crane **B203**.
- The lane is the crane's letters: B203 is lane **B**, G435 is lane **G**.
- Uploading a file with the same name again replaces the old one.
- Files stay until you delete them (×), including after you close and restart the analyzer.

**Analysis tabs (Cases, Performance, Pickups, Energy, Data quality).** Live results, filled automatically every time data is analysed (after an upload or a NAS sync); an open tab refreshes by itself within a few seconds. All five share one filter bar: dates (with Latest day / 7 days / 30 days / All), lanes and cranes. The filters are remembered in your browser. Each list has a **CSV** download.

- **Cases.** One crane's chain of jobs up to the job that completes it (rules: Settings > Rules > Cases), both successful cases and cases with unnecessary moves. Each crane is grouped on its own, and a case can continue past midnight. Totals, a table per crane with the success rate, and the list of cases. Click a case for its chart and its jobs with the reason for each verdict.
- **Performance.** Reposition moves (MoveType 3) with an issue: slower than expected, aborted, no movement, abnormal step sequence, or not reaching the reference. Click a move for its speed chart (expected against actual).
- **Pickups.** Pickup and setdown jobs (MoveType 1/2): necessary, unnecessary, unknown, with the reason. Click one to see the case it belongs to.
- **Energy.** Used, fed back, net, counted (per Settings > Energy) and wasted, per day, crane or lane.
- **Data quality.** Per file: repeated seconds, job id blips, gaps, rows without a job id, job ids that come back. Shows which days' results to take with care.

Results always follow the active profile's saved settings: when you save settings (or switch profile or replace Columns_info), all files are analysed again in the background, newest days first, and the tabs update as they finish. The results live in `analyzer_data/results.db`; it is rebuilt automatically if deleted.

**Reports tab.** The same results as PDFs, combined from what is already analysed. Choose what to report on, then **Build reports**:

- **Report type.** *Daily* gives one set per day: Summary, Operation, and optionally one report per crane. *Period* gives one set for the whole date range, plus an **Overview** with totals and a chart per day, and tables per lane and per crane.
- **Dates.** Set From and To, or use the Latest day / Last 7 days / All dates shortcuts.
- **Lanes.** Click lane letters to limit the report to those lanes. None selected means all lanes.
- **Cranes.** Tick the cranes you want. The small number shows how many days of data each crane has in the chosen dates.
- **Include.** Pick the reports: Overview (Period only), Summary, Operation, a detailed report per crane, raw results (JSON). Per-crane detail reports have one page per move, so they get long and are the slowest to build; they're off by default in Period mode.
- **Cases in the Operation report.** As in Settings, only cases with unnecessary moves, only successful cases, or all cases.

Results can be opened in the browser or downloaded one by one, per day, or all as a zip. The latest 20 report sets are kept under **Saved reports**, also after a restart.

When a file spans midnight, each move is counted on the day it started.

**Settings tab.** Every analysis parameter, grouped as:

| Section | What it controls |
|---|---|
| Machine motion | Acceleration, deceleration, top speed and time offset for gantry, trolley and hoist |
| Thresholds | Hoist safe height, position-match tolerance, necessity tolerance, abort checks, slow threshold |
| Energy | How energy is calculated (torque × speed, or voltage × current), P_ref per axis, efficiencies, speed direction, and whether energy fed back by braking is deducted |
| Power and cost | Cost per kWh and currency (leave cost empty to hide cost columns); supply voltage and power factor for the voltage × current method |
| Column mapping | Which PLC column holds each signal: reference position, actual position, speed, drive current, drive voltage |
| Rules | Every decision the analysis makes (see *Analysis rules* below) |
| Application | Port, network access, open browser on start |

**Profiles.** Settings are saved as named profiles. Typical uses are one per crane, one per terminal, or one per person. Pick the active profile from the top-right menu; the analysis tabs and reports always use the active profile's *saved* settings. Saving settings re-analyses all files in the background.

- **Save as new profile** makes a copy.
- **More** lets you reset to factory defaults, export or import a profile as XML, or delete one.

Default column names: hoist position `In_HOIST`, trolley position `In_TROLLEYPOMUX`, gantry position `In_GANTRY1`. Current and voltage come from `In_<AXIS>Current1/2` and `In_<AXIS>Voltage1/2`. If an export names a column differently, add the name under **Column mapping**. Where several names are listed, the first one found in the file is used.

**Code descriptions tab.** Shows the code → description table from `Columns_info.xlsx` (Step, StepInfo, MoveType, LandingType, TargetType, RemoteRequestInfo), with search. Reports use these names; for example, step tables show "5 - move active". **Replace file** swaps in a new Columns_info; the old one is kept in `config/columns_info_backups/`.

## Energy calculation

The default method is **torque × speed**, for drives that log actual torque and actual speed as a percentage of their reference values (Siemens Masterdrives VC: `GantryTorque1/2` + `GANTRYSPEED1/2`, and the same for trolley and hoist):

```
P_mech [kW] = P_ref × (torque % / 100) × (speed % / 100)      per drive
P_ref  [kW] = P354 [Nm] × P353 [rpm] / 9550                   (or enter P_ref in kW)
```

- **Driving vs braking.** Torque × speed is positive while driving and negative while braking. Electrical power is mechanical ÷ efficiency while driving and mechanical × efficiency while braking, when energy is fed back through the Active Front End. The default efficiency is 0.93 motor × 0.98 drive = 0.911.
- **What reports show.** Each move and day shows energy **used**, **fed back** and **net**. *Energy fed back by braking* (Settings > Energy) decides whether totals, wasted energy and cost use net (default) or used only. Wasted energy per move is never negative.
- **Speed direction.** Torque × speed needs the speed sign to show braking. On *Check automatically*, a speed tag that is never negative in a file is treated as speed magnitude, and the direction comes from the change in that axis' position. Use *Reverse sign* on an axis if its driving shows up as braking.
- **Axes without P_ref.** An axis with no P_ref (or P353/P354) is left out of the energy, and the reports say so. **Enter P353 and P354 for each axis** when you have them; until then the gantry uses 75 kW (rated power P073). Trolley and hoist need their values.
- **Not included.** Standstill and auxiliary losses (fans, lights, magnetising current, the AFE itself) are not part of torque × speed. A day's total will read lower than the crane's main meter, which is expected for "energy of a move".

The previous **voltage × current × power factor** method is still available under Method, for machines whose drives log real volts and amps. It is wrong for Masterdrives tags, which are percentages, and it counts braking as consumption.

## Analysis rules

**Default necessity rules (as specified for this terminal):**

- **Reposition (3):** necessary only if the next job is a pickup (1) at the gantry position where the reposition ended (within the necessity tolerance). Otherwise it is unnecessary. Example: reposition to 300, then pickup 300, is necessary; reposition to 300, then pickup 400, is unnecessary.
- **Pickup (1):** consecutive pickups form one chain that ends at a setdown (2), whether the setdown is in the same workorder or its own. The unbroken run of pickups at the same gantry position as the last pickup before the setdown is necessary; earlier pickups are unnecessary. A chain that never reaches a setdown is unnecessary, and unknown only if the data ends first. Each chain is one case in the Operation report.

| Pickups (gantry m) | Result |
|---|---|
| 300 → setdown | necessary |
| 300 → 300 → 300 → 300 → setdown | all necessary |
| 300 → 400 → setdown | 300 unnecessary, 400 necessary |
| 300 → 300 → 300 → 500 → setdown | the three at 300 unnecessary, 500 necessary |
| 300 → 400 → 400 → 400 → setdown | 300 unnecessary, the three at 400 necessary |
| 300 → 400 → 300 → setdown | first 300 and 400 unnecessary, last 300 necessary |
| 300 → 300 → reposition | both unnecessary |

Every rule the analysis applies is under **Settings > Rules**, so the platform can be adapted to another machine or process without code changes. The defaults are the crane rules it was built with. Results are identical to the previous version until you change something.

| Group | What you can change |
|---|---|
| Job types and columns | Job id, job type and step column names; reposition, pickup, setdown, idle and unexpected job type codes; how long a job id blip may last and still be ignored |
| Step sequence rules | Expected step order; movement steps; lift step, height axis, and how an unneeded lift is judged; end-position check; manual-intervention step and the step merged into it; resuming after an interruption |
| Performance rules | Speed-curve smoothing (time limits are under Thresholds) |
| Necessity: repositions | Necessary when position and job type match, position only, or job type only; which axis the position is compared on (gantry by default); which job types may follow |
| Necessity: pickups and setdowns | Whether pickups are judged; how a pickup without its own setdown is judged: by gantry position up to the setdown (default), always unnecessary, or unnecessary only when another pickup follows |
| Cases | What closes a case; whether the report shows all cases or only those with an unnecessary move |
| REVIEW flag | Which findings raise REVIEW: abnormal sequence, minor waste, manual intervention, slow, aborted, no movement, unnecessary |
| Wasted energy | Confirmed unnecessary moves only, or also moves that couldn't be judged |
| Lanes | Leading letters (B203 → B), one character at a position (Y2893 → 2), or a pattern |

Saving a rule change marks files *Settings changed*; they are re-analyzed automatically when a report needs them. Rules are part of the profile, so different machines or sites can have their own profile.

## NAS sync (InfluxDB on the Synology)

Instead of downloading and uploading Excel files, the analyzer can pull the 1-second rows straight from InfluxDB. Set it up under **Settings > NAS sync**:

1. In InfluxDB (usually `http://<NAS address>:8086`), create a **read-only** token: *Load Data > API Tokens > Generate API Token > Custom API Token*, tick **Read** for the PLC bucket only. The analyzer never writes to InfluxDB.
2. Fill in the **InfluxDB address**, **Organisation**, **Bucket**, **API token** and the **Machine tag name** (the tag that holds the machine name, e.g. `crane_id`). Leave **Measurement** blank unless the bucket holds other data too.
3. Press **Test connection**. It reports the InfluxDB version and the newest row it can see, or what's wrong (address, token, organisation or bucket).
4. Press **Find machines**, and check the crane name guessed for each machine: `rmg_b204` becomes **B204**, and the crane name decides the lane. Untick machines you don't want.
5. Tick **Sync automatically**, press **Save NAS settings**, then **Sync now** for the first pull.

How it works:

- Every *Sync every* minutes (default 30) while the analyzer is open, it asks InfluxDB only for rows after the newest row it already has, minus a 5-minute overlap. Rows already stored are skipped, so nothing is duplicated. If the collector PC writes rows late (for example after an outage), they are still picked up, up to 48 hours back.
- The first pull of a machine starts at *First sync starts from* (More options; default yesterday). Long pulls are split into requests of 6 hours.
- Rows are cleaned like a manual download. The PLC's own PLCTime is kept; rows without one get InfluxDB's UTC time converted to Dubai time (*Time zone* under More options).
- New rows go into one file per crane per day (`B203_2026-10-13_nas.csv`) on the PLC data tab, and are analyzed automatically. Today's file grows as the day goes on.
- **Pull again** on a machine re-reads it from the first-sync date (nothing is duplicated). **Stop** ends a running sync after the current request; rows already pulled are kept.
- Data with two times is handled: the PLC's own PLCTime is used. InfluxDB's `_time` (UTC, with varying precision such as `…:05Z` and `…:05.5Z`) is used only to know which rows are new, and for rows without a PLCTime.
- Machines that haven't worked for days get no error. They show "not yet" (or their last row) and are re-checked for at most 48 hours back each sync, so they don't slow the sync down.
- Fields stored sometimes as whole numbers and sometimes as decimals (0 and 0.5) are read as text and turned back into numbers here, so InfluxDB doesn't refuse with "schema collision". If InfluxDB still objects, the sync automatically retries that range with a simpler query.
- One machine failing never stops the others; its error shows next to it in the machine list.
- The token is stored only on this PC (`analyzer_data/nas_settings.json`) and is never shown in the browser.
- The sync uses no proxy and no extra software: plain HTTP(S) to the address you enter. For an `https://` address with a self-signed certificate, untick *Check the certificate* under More options.

Sync progress and failures also appear in the header and on the Engineering Building status page.

## Port

The analyzer only listens on **localhost** unless you allow network access. The default port is **8765**. Change it under **Settings → Application**; it takes effect after you restart. Ports 5000, 5002, 5030 and 5050 are refused. To try another port once without saving it:

```
python app.py --port 8800
```

If the start window says the port is in use, the analyzer is probably already running. Open the address it shows.

## Company logo and theme

The page follows the Engineering Building design system, including automatic dark mode. Put the company logo in the `static` folder as **`logo.svg`** or **`logo.png`**. It appears top-left of the header at 32 px high and is used as the browser-tab icon. If the logo is mostly dark, it gets a small white plate in dark mode automatically. Refresh the browser after adding it; no restart needed.

All styling lives in `static/app.css`, with the colours as CSS variables at the top.

## Engineering Building dashboard

The analyzer is a floor in the Engineering Building. Its read-only status page is:

```
GET http://localhost:8765/building/status
```

It reports the platform name, status (`idle`, `working`, `error`), the current job with progress, counters and the last error. It also lists the team who would do this work by hand, with the roles the platform automates. One **item** is one crane-day: a single PLC export analyzed.

To add the floor: in the building go to **Settings > Floors > Add floor**, open the new floor's tab, enter `http://localhost:8765` as the platform's address, and click **Test** next to "Status page".

Notes:

- The answer is cached for 5 seconds and comes from memory only, so it returns in a few milliseconds even while the analyzer is busy. If anything in it fails, it still answers, with status `error` and the message; the rest of the analyzer is unaffected.
- `status` is `error` when a file failed to analyze or a report run had problems in the last hour and nothing is running. Deleting the bad file clears it.
- If the building runs on another computer, turn on **Allow other computers on the network** (Settings > Application), restart, and use the address the start window prints instead of localhost.

## Sharing with colleagues

Tick **Allow other computers on the network** (Settings → Application), then restart. The console window prints the address others can open, e.g. `http://192.168.1.20:8765`. Windows may ask once whether to allow Python through the firewall.

## Project layout

```
plc_analyzer/
├── run.bat / run.sh             start the analyzer (opens the browser)
├── app.py                       web server
├── building_status.py           GET /building/status for the Engineering Building dashboard
├── run_analysis.py              optional command-line run (for scheduled jobs)
├── requirements.txt
├── Columns_info.xlsx            code → description table
├── config/golden_standard.xml   factory defaults (used for "Reset to factory defaults")
├── profiles/                    saved settings profiles (created on first start)
├── app_settings.json            port / network / active profile (created on first start)
├── analyzer_data/               PLC data files (uploaded and from the NAS), cached analysis, saved reports,
│                                NAS sync settings and token (created on first start)
├── static/                      the browser page: index.html, app.css (the one stylesheet), app.js, analysis.js (analysis tabs), logo
├── src/                         analysis engine, report builders, settings, NAS sync (nas_sync.py), InfluxDB cleanup (influx_clean.py),
│                                analysis rules and energy settings (rules.py), results database for the
│                                analysis tabs (results_store.py, results_api.py)
└── docs/ANALYSIS_NOTES.md       how the analysis works (sequence, performance, necessity, power, cases)
```

To move your settings to another computer, copy the `profiles/` folder, or use **Export profile** / **Import profile**.

## Command line (optional)

For scheduled runs without a browser:

```
python run_analysis.py --input "D:\PLC exports" --output "D:\Reports" --profile "A205" --mode period --json
```

## Backing up

Copy the `analyzer_data/` folder (your uploaded files) and `profiles/` folder (your settings) to keep or move everything.

## Changes in this version

- **New: analysis tabs.** Cases, Performance, Pickups, Energy and Data quality show live results for any dates, lanes and cranes, updated automatically after every NAS sync or upload (see *Use it*). Cases include successful cases too.
- **Reports:** choose which reports to build (Overview, Summary, Operation, per crane, JSON) and which cases the Operation report details.
- **Settings changes re-analyse automatically** in the background, newest days first, so the tabs never show results from old settings.
- The section tabs moved to their own row under the title; the settings profile menu is next to the title.
- All files are analysed once more after this update (to collect the Data quality figures).

- **Fixed: job id "blips" (339, 2342, 339).** When the job id changes for a few seconds and then returns to the same id, the short change is a glitch, not a job: those rows stay in the surrounding job (with its job type and step) and the job gets a note in the report. Setting: *Settings > Job types and columns > Ignore job id blips up to (s)*, default 10, 0 = off.
- **Fixed: repeated seconds.** When the same PLC second is in a file more than once, only the first row is used.
- **Fixed: rows without the PLC's own PLCTime.** Their time comes from InfluxDB's `_time`; it is now shifted by the usual difference between the PLC clock and NAS time, so these rows no longer land among another job's rows. Uploaded files with PLCTime blank in places are also read correctly now (those rows used to end up at the end of the file).
- **Faster.** Analysis is about 3 times faster, and several files are analysed at the same time (one per CPU core, keeping one free). Report PDFs are also written in parallel. The slowest part of a report is the crane detail PDFs (one chart per move): untick them in the report form when you only need the summary.
- **New: `check_jobs.py`** - checks one PLC file for repeated seconds, gaps, job id blips, ids that come back later and, for raw InfluxDB downloads, the difference between the PLC clock and NAS time. `python check_jobs.py "file.csv" 339` also lists the jobs around job 339. Nothing is changed.

- **Fixed: jobs with a repeated workorder id.** A job is now an unbroken run of rows with the same `WorkorderIdent`, in PLC-time order. Previously all rows with the same id in a file were merged into one job, so an id that came back later (next day, or reused by the PLC) produced one "move" lasting hours and the wrong "next job", which led to wrong necessary/unnecessary results. Files already analysed are re-analysed automatically. The setting "skip idle-only jobs" was removed: idle-only stretches are never treated as the next job.

- **New necessity rules (defaults).** Repositions are compared on the gantry position. Pickups are judged as chains up to the setdown, by gantry position (see *Analysis rules*). Profiles saved before this change switch to the new pickup rule automatically. The previous rules can still be chosen in Settings.
- Fixed: when the next workorder started with idle rows, a reposition was compared with that idle row (where the crane already stood) instead of the next job's real position.
- Fixed: a repeated pickup at the same gantry position was described as "at a different location".

- Renamed to **Gantry Watch** (page, browser tab, start window, Engineering Building status page). The project folder name is unchanged, so updates still extract over the existing folder.

- **Energy fix.** New default method, torque × speed per drive, with energy used, fed back and net shown separately and a setting for which one counts. The voltage × current method is kept as an option. See *Energy calculation*.
- **All analysis rules are settings** (Settings > Rules, 37 rules in 9 groups, `src/rules.py`). With the defaults, every decision is identical to before; this was checked move by move.

- NAS sync fixes for real-world data:
  - `_time` values with mixed precision are read reliably.
  - Time ranges keep microseconds, and ranges shorter than 5 ms are skipped, so InfluxDB never sees "cannot query an empty range".
  - Values are converted to text before pivoting, avoiding "schema collision: float and int", with an automatic simpler-query fallback.
  - Idle machines are re-checked for at most 48 hours back.
  - One machine's failure no longer stops the others, and error messages are kept short.

- New: NAS sync. Pulls PLC data from InfluxDB on the Synology automatically (Settings > NAS sync), read-only and incremental (`src/nas_sync.py`).
- New: raw InfluxDB downloads are cleaned automatically on upload (`src/influx_clean.py`). There's no need to delete the first rows and columns in Excel any more.
- The crane is now also found when its code isn't at the start of the file name (`raw_B203_….xlsx` → B203).
- Added `tzdata` to requirements, so time zones work on Windows.

- Restyled to the Engineering Building design system, with light and dark mode, the company logo, and the live status in the header. Features are unchanged. The front-end folder is now `static/` (was `web/`).

- Added the Engineering Building status page (`building_status.py`, `GET /building/status`).
- The launcher is now `run.bat` / `run.sh`. Port 5002 is also refused.
- Files that aren't PLC exports now get a readable error naming the missing column.

- PLC data is now stored and kept between sessions (PLC data tab). Reports are built on demand from your date, lane and crane filters, as daily sets or as one set for a period with a new Overview report.
- The analyzer is now addressed and announced as http://localhost.
- Fixed: clicking the drop box didn't open the file chooser.

- Earlier: added the web UI, settings profiles and in-browser downloads. The `RUN_ANALYSIS.*` launchers and the fixed `Daily Reports/` folder are gone.
- Current/voltage column names were hard-coded in `power_agent.py`; they now come from the profile.
- The hoist position column was hard-coded as `In_HOIST` in `sequence_agent.py`; it now comes from the profile.
- `golden_standard.xml` now actually contains `<cost_per_kwh>` and `<currency>`. The old README described them but the file didn't have them, so cost columns never appeared.
- Columns_info groups "step info" and "remote request info" are now recognised as `StepInfo` / `RemoteRequestInfo`.
- Step tables in the crane reports show the step description next to the number.
- Column-not-found errors now point to Settings → Column mapping instead of the XML file.
