"""
BUILDING INTEGRATION — read-only status page for the "Engineering Building" dashboard.

    GET /building/status     (served by the Rule Builder, app.py, on port 5120)

Everything here is written so it can NEVER slow down or break the platform:
  * the answer is cached for ~5 seconds, so the dashboard polling it costs almost nothing;
  * every error is caught, and a harmless "error" answer is returned instead of an exception;
  * the activity hooks (job / record_items / ...) swallow their own errors too.

WHAT IS AN "ITEM"?   One fault evaluated against one terminal/type program's PLC history.
WHAT IS AN "ISSUE"?  Something the platform found that needs a person: an evaluated fault where the rule
                     missed a real event or raised a false alarm, or a root-cause review that flagged a
                     sensor problem or a recurring location.

This program reports into the small folder  activity/  next to this file (NAS syncs and evaluations).
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path

PLATFORM_NAME = "FDD Evaluation — PLC Logic Backtesting"
CACHE_SECONDS = 5
JOB_STALE_SECONDS = 600      # a job file not updated for this long is ignored (e.g. the program was closed mid-job)
KEEP_HOURS = 48

# The people who would do this work by hand, in order. EDIT THIS LIST to match how your team really works.
# manual_minutes_per_item = minutes a person needs per item (one fault, on one terminal/type program).
TEAM = [
    {"role": "PLC Data Analyst",
     "description": "Exports each machine's PLC history from the historian, cleans it, removes duplicate rows and gaps, and merges the machines of each terminal/type together.",
     "automated": True, "manual_minutes_per_item": 15},
    {"role": "Fault Log Analyst",
     "description": "Matches each machine's fault history to the master fault list of its terminal and PLC program type.",
     "automated": True, "manual_minutes_per_item": 10},
    {"role": "Controls Engineer",
     "description": "Writes the fault logic (thresholds, timers, AND/OR conditions) that copies what the PLC does, and updates it whenever the PLC program changes.",
     "automated": False, "manual_minutes_per_item": 30},
    {"role": "Reliability Analyst",
     "description": "Checks every real fault against what the logic would have predicted: hits, misses and false alarms, per machine, type and terminal.",
     "automated": True, "manual_minutes_per_item": 45},
]

_ACT = Path(__file__).resolve().parent / "activity"
_EVENTS = _ACT / "events.jsonl"
_lock = threading.Lock()
_active = {}                 # process name -> the job object that owns it in THIS process
_cache = {"t": 0.0, "data": None}
_appends = {"n": 0}


# ------------------------------------------------------------------ writing activity (safe: never raises)
def _append(event: dict) -> None:
    try:
        _ACT.mkdir(exist_ok=True)
        with open(_EVENTS, "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
        _appends["n"] += 1
        if _appends["n"] % 100 == 0:
            _prune()
    except Exception:  # noqa: BLE001
        pass


def _prune() -> None:
    try:
        if _EVENTS.stat().st_size < 200_000:
            return
        cutoff = time.time() - KEEP_HOURS * 3600
        keep = [ln for ln in _EVENTS.read_text(encoding="utf-8").splitlines() if _ts_of(ln) >= cutoff]
        tmp = _EVENTS.with_name(_EVENTS.name + ".tmp")
        tmp.write_text("\n".join(keep) + "\n", encoding="utf-8")
        tmp.replace(_EVENTS)
    except Exception:  # noqa: BLE001
        pass


def _ts_of(line: str) -> float:
    try:
        return float(json.loads(line).get("ts", 0))
    except Exception:  # noqa: BLE001
        return 0.0


def record_items(n: int = 1, issues: int = 0) -> None:
    """n items finished; `issues` of them need a person's attention."""
    _append({"ts": time.time(), "kind": "items", "n": int(n), "issues": int(issues)})


def record_issues(n: int = 1) -> None:
    _append({"ts": time.time(), "kind": "items", "n": 0, "issues": int(n)})


def record_error(message) -> None:
    _append({"ts": time.time(), "kind": "error", "msg": str(message)[:300]})


class job:
    """  with job("Evaluating faults", total=12) as j:  ...  j.progress(done=3, step="High pressure")  """

    def __init__(self, step: str, total: int = 0, process: str = "rule_builder"):
        self.step, self.total, self.done, self.process, self.owner = step, int(total or 0), 0, process, False

    def _write(self) -> None:
        try:
            _ACT.mkdir(exist_ok=True)
            p = _ACT / f"job_{self.process}.json"
            tmp = p.with_name(p.name + ".tmp")
            tmp.write_text(json.dumps({"step": self.step, "items_done": self.done, "items_total": self.total, "ts": time.time()}), encoding="utf-8")
            tmp.replace(p)
        except Exception:  # noqa: BLE001
            pass

    def __enter__(self):
        try:
            with _lock:
                if _active.get(self.process) is None:     # a nested job inside a running one just joins it
                    _active[self.process] = self
                    self.owner = True
            if self.owner:
                self._write()
        except Exception:  # noqa: BLE001
            pass
        return self

    def progress(self, done=None, step=None, total=None) -> None:
        try:
            if not self.owner:
                return
            if done is not None:
                self.done = int(done)
            if step is not None:
                self.step = str(step)
            if total is not None:
                self.total = int(total)
            self._write()
        except Exception:  # noqa: BLE001
            pass

    def __exit__(self, exc_type, exc, tb):
        try:
            if self.owner:
                with _lock:
                    _active[self.process] = None
                try:
                    (_ACT / f"job_{self.process}.json").unlink()
                except OSError:
                    pass
                if exc_type is not None:
                    record_error(f"{self.step}: {exc}")
                else:
                    _append({"ts": time.time(), "kind": "ok"})
        except Exception:  # noqa: BLE001
            pass
        return False   # never swallow the caller's exception


# ------------------------------------------------------------------ reading activity -> the status answer
def _team():
    return [dict(t) for t in TEAM]


def _current_job(now: float):
    best = None
    for p in _ACT.glob("job_*.json"):
        try:
            j = json.loads(p.read_text(encoding="utf-8"))
            if now - float(j.get("ts", 0)) <= JOB_STALE_SECONDS and (best is None or j["ts"] > best["ts"]):
                best = j
        except Exception:  # noqa: BLE001
            continue
    if not best:
        return None
    return {"step": str(best.get("step", "")), "items_done": int(best.get("items_done", 0)), "items_total": int(best.get("items_total", 0))}


def _compute() -> dict:
    now = time.time()
    midnight = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    items_today = items_hour = issues_today = 0
    last_error, last_error_ts, last_ok_ts = None, 0.0, 0.0
    if _EVENTS.exists():
        for line in _EVENTS.read_text(encoding="utf-8").splitlines():
            try:
                ev = json.loads(line)
                ts, kind = float(ev.get("ts", 0)), ev.get("kind")
            except Exception:  # noqa: BLE001
                continue
            if kind == "items":
                n, iss = int(ev.get("n", 0)), int(ev.get("issues", 0))
                if ts >= midnight:
                    items_today += n
                    issues_today += iss
                if ts >= now - 3600:
                    items_hour += n
            elif kind == "error" and ts >= last_error_ts:
                last_error, last_error_ts = ev.get("msg"), ts
            elif kind == "ok" and ts > last_ok_ts:
                last_ok_ts = ts
    cur = _current_job(now) if _ACT.exists() else None
    recent_error = last_error is not None and now - last_error_ts < 86400
    status = "working" if cur else ("error" if recent_error and last_error_ts > last_ok_ts else "idle")
    return {
        "platform": PLATFORM_NAME, "status": status, "current_job": cur,
        "counters": {"items_today": items_today, "items_last_hour": items_hour, "issues_today": issues_today},
        "last_error": last_error if recent_error else None, "team": _team(),
    }


def _fallback(err) -> dict:
    return {"platform": PLATFORM_NAME, "status": "error", "current_job": None,
            "counters": {"items_today": 0, "items_last_hour": 0, "issues_today": 0},
            "last_error": f"status page problem: {err}", "team": _team()}


def get_status() -> dict:
    now = time.time()
    with _lock:
        if _cache["data"] is not None and now - _cache["t"] < CACHE_SECONDS:
            return _cache["data"]
    try:
        data = _compute()
    except Exception as e:  # noqa: BLE001
        data = _fallback(e)
    with _lock:
        _cache["t"], _cache["data"] = now, data
    return data


def register(app) -> None:
    """Adds  GET /building/status  to a Flask app. Read-only; safe to call once from app.py."""
    from flask import jsonify

    @app.route("/building/status", methods=["GET"])
    def building_status():
        try:
            data = get_status()
        except Exception as e:  # noqa: BLE001
            data = _fallback(e)
        resp = jsonify(data)
        resp.headers["Access-Control-Allow-Origin"] = "*"     # lets the dashboard read it straight from the browser
        resp.headers["Cache-Control"] = "no-store"
        return resp
