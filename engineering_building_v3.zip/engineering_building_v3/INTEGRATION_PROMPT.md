# Making a new platform "building-ready"

Paste this block into your request whenever you ask Claude to create a new platform.
Platforms built with it appear in the Engineering Building with their own team,
current step and engineers' work, with no extra settings.

```
BUILDING INTEGRATION (required):
This platform will be shown as a floor in my "Engineering Building" dashboard.
Please include:

1. A read-only page GET /building/status that answers in under 100 ms with JSON:
   {
     "platform": "<full name>",
     "status": "idle" | "working" | "error",
     "current_job": {"step": "<what it is doing now>", "items_done": n, "items_total": n}
                    or null when idle,
     "counters": {"items_today": n, "items_last_hour": n, "issues_today": n},
     "last_error": "<message or null>",
     "team": [
       {"role": "<role name>", "description": "<what this person does>",
        "automated": true/false,
        "manual_minutes_per_item": <minutes a person would need per item>}
     ]
   }
   An "item" is one unit of work for this platform (one camera, one brake, one report...).
2. "team" must list the people who would do this work by hand, step by step,
   and mark which roles the platform automates (automated: true) and which are
   still done by engineers (automated: false).
3. Put this in its own small file (building_status.py) registered from app.py,
   cache the answer for about 5 seconds, and catch every error so this page can
   never slow down or break the platform.
4. Use its own port (not 5000, 5002 or 5050), a run.bat like my other platforms,
   and open the browser automatically.
```

For a security scanner (the floor that raises the city shield), also add this
line to the request:

```
SECURITY SCANNER (only for the vulnerability scanner):
Add a "security" section to the /building/status answer:
   "security": {"platforms_scanned": n, "platforms_total": n,
                "last_scan": "<ISO time of the last finished scan>",
                "findings": {"critical": n, "high": n, "medium": n, "low": n}}
```

After the platform is created: in the building, go to Settings > Floors > Add floor,
open the new floor's tab, enter the platform's address and click Test next to
"Status page".

For the scanner floor, also tick "City security shield" on its settings page and
click Save. Use "Move to centre" in Settings > Buildings to put the security
building in the middle of the city.
