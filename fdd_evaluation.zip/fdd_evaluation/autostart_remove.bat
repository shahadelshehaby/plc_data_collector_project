@echo off
schtasks /delete /tn "FDD Platform - Evaluation" /f
pause
