"""
launch_cranes.py
================
Starts one collector per crane listed in the Excel file, and keeps them running.

    python launch_cranes.py            # start everything + live status table
    python launch_cranes.py --check    # only read the Excel and show what WOULD run

What it does, in order:
  1. Stops a previous launcher (and its collectors) if one is still running.
  2. Reads every sheet of the Excel file. Rows with blank / NA version are skipped.
     Duplicate crane IDs or duplicate ports are refused (not started).
  3. For every port in the list: kills ANY program that currently holds that UDP
     port, and waits until the port is free.
  4. Starts crane_collector.py for each crane, restarts any that stop.
"""
import io
import json
import logging
import os
import re
import socket
import subprocess
import sys
import time
from logging.handlers import RotatingFileHandler

import collector_settings as S

IS_WINDOWS = os.name == "nt"
COLLECTOR = S.BASE_DIR / "crane_collector.py"
PID_FILE = S.RUN_DIR / "launcher.pid"
LAUNCHER_STATUS = S.STATUS_DIR / "launcher.json"

log = logging.getLogger("launcher")


# ═════════════════════════════════════════════════════════════════════════════
#  1. READ THE EXCEL FILE
# ═════════════════════════════════════════════════════════════════════════════
def _norm_version(v):
    """2 -> '2', 2.1 -> '2.1', 'v2.1' -> '2.1', 'NA'/blank -> None"""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return f"{v:g}"
    s = str(v).strip().lower().lstrip("v")
    if s in ("", "na", "n/a", "-", "none"):
        return None
    try:
        return f"{float(s):g}"
    except ValueError:
        return s


def read_crane_list(path):
    """Returns (jobs, skipped). jobs = [{crane, port, version, sheet}]"""
    import openpyxl
    # Read a copy in memory so it also works while the file is open in Excel
    with open(path, "rb") as fh:
        wb = openpyxl.load_workbook(io.BytesIO(fh.read()), data_only=True, read_only=True)

    rows, skipped = [], []
    for ws in wb.worksheets:
        it = ws.iter_rows(values_only=True)
        header = next(it, None)
        if not header:
            continue
        cols = {str(h).strip().lower(): i for i, h in enumerate(header) if h is not None}
        try:
            ci, pi, vi = cols["crane"], cols["port"], cols["collector version"]
        except KeyError:
            log.warning("Sheet '%s' has no Crane / Port / Collector Version header - ignored",
                        ws.title)
            continue
        for r in it:
            crane = r[ci] if ci < len(r) else None
            if crane is None or str(crane).strip() == "":
                continue
            crane = str(crane).strip().upper()
            version = _norm_version(r[vi] if vi < len(r) else None)
            port = r[pi] if pi < len(r) else None
            if version is None:
                continue                                   # NA / blank -> not onboarded
            if version not in S.PACKET_SIZE:
                skipped.append((crane, f"unknown collector version '{version}'"))
                continue
            try:
                port = int(float(port))
                if not 1 <= port <= 65535:
                    raise ValueError
            except (TypeError, ValueError):
                skipped.append((crane, f"invalid or missing port '{port}'"))
                continue
            rows.append({"crane": crane, "port": port, "version": version, "sheet": ws.title})

    # Safety: refuse duplicates (both entries are left out so nothing sends to the wrong crane)
    jobs = []
    for job in rows:
        same_crane = [j for j in rows if j["crane"] == job["crane"]]
        same_port = [j for j in rows if j["port"] == job["port"]]
        if len(same_crane) > 1:
            skipped.append((job["crane"], "crane listed more than once in the Excel"))
        elif len(same_port) > 1:
            others = ", ".join(j["crane"] for j in same_port if j is not job)
            skipped.append((job["crane"], f"port {job['port']} also used by {others}"))
        else:
            jobs.append(job)
    # de-duplicate skip messages
    skipped = list(dict.fromkeys(skipped))
    return jobs, skipped


# ═════════════════════════════════════════════════════════════════════════════
#  2. FIND / KILL PROGRAMS HOLDING A UDP PORT
# ═════════════════════════════════════════════════════════════════════════════
def _run(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                              timeout=20).stdout
    except Exception:
        return ""


def udp_port_owners():
    """{port: set(pid)} for every UDP port currently open on this PC."""
    owners = {}
    if IS_WINDOWS:
        # Example line:  UDP    0.0.0.0:12201    *:*    4321
        for line in _run(["netstat", "-ano", "-p", "UDP"]).splitlines() + \
                    _run(["netstat", "-ano", "-p", "UDPv6"]).splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[0].upper() == "UDP":
                try:
                    port, pid = int(parts[1].rsplit(":", 1)[1]), int(parts[-1])
                    owners.setdefault(port, set()).add(pid)
                except ValueError:
                    pass
    else:                               # Linux (used for testing only)
        inode_port = {}
        for f in ("/proc/net/udp", "/proc/net/udp6"):
            try:
                for line in open(f).readlines()[1:]:
                    parts = line.split()
                    inode_port[parts[9]] = int(parts[1].rsplit(":", 1)[1], 16)
            except OSError:
                pass
        for pid in filter(str.isdigit, os.listdir("/proc")):
            try:
                for fd in os.listdir(f"/proc/{pid}/fd"):
                    m = re.match(r"socket:\[(\d+)\]", os.readlink(f"/proc/{pid}/fd/{fd}"))
                    if m and m.group(1) in inode_port:
                        owners.setdefault(inode_port[m.group(1)], set()).add(int(pid))
            except OSError:
                pass
    return owners


def process_name(pid):
    if IS_WINDOWS:
        out = _run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"]).strip()
        return out.split(",")[0].strip('"') if out.startswith('"') else None
    try:
        return open(f"/proc/{pid}/comm").read().strip()
    except OSError:
        return None


def kill_pid(pid, tree=False):
    if IS_WINDOWS:
        cmd = ["taskkill", "/PID", str(pid), "/F"] + (["/T"] if tree else [])
        _run(cmd)
    else:
        import signal
        try:
            if tree:
                for child in _run(["pgrep", "-P", str(pid)]).split():
                    kill_pid(int(child), tree=True)
            os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass


def port_is_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.bind((S.LISTEN_ADDRESS, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def free_ports(ports, wait=10):
    """Kill whatever holds the given UDP ports. Returns the set of ports still busy."""
    ports = set(ports)
    owners = udp_port_owners()
    me = os.getpid()
    for port in sorted(ports):
        for pid in sorted(owners.get(port, ())):
            if pid in (0, 4, me):           # 0/4 = Windows System, never kill
                continue
            log.warning("Port %d is in use by PID %d (%s) - stopping it",
                        port, pid, process_name(pid) or "unknown")
            kill_pid(pid)
    deadline = time.time() + wait
    busy = {p for p in ports if not port_is_free(p)}
    while busy and time.time() < deadline:
        time.sleep(0.5)
        busy = {p for p in busy if not port_is_free(p)}
    for p in sorted(busy):
        log.error("Port %d is STILL busy (run as Administrator?) - will keep retrying", p)
    return busy


def stop_previous_launcher():
    if not PID_FILE.exists():
        return
    try:
        old = int(PID_FILE.read_text().strip())
    except ValueError:
        return
    name = (process_name(old) or "").lower()
    if old != os.getpid() and "python" in name:
        log.warning("Previous launcher (PID %d) is still running - stopping it and its collectors", old)
        kill_pid(old, tree=True)
        time.sleep(1)


# ═════════════════════════════════════════════════════════════════════════════
#  3. SUPERVISE COLLECTORS
# ═════════════════════════════════════════════════════════════════════════════
class Collector:
    def __init__(self, job):
        self.job = job
        self.proc = None
        self.restarts = 0
        self.started_at = 0
        self.next_start = 0
        self.backoff = 10
        self.console = None

    def start(self):
        j = self.job
        if not port_is_free(j["port"]):
            busy = free_ports([j["port"]], wait=3)
            if busy:
                self.next_start = time.time() + 30
                return
        # Console output (crash tracebacks etc.) goes to a small file per crane
        self.console = open(S.LOG_DIR / f"{j['crane']}_console.txt", "a",
                            buffering=1, encoding="utf-8", errors="replace")
        self.proc = subprocess.Popen(
            [sys.executable, "-u", str(COLLECTOR), j["crane"], str(j["port"]), j["version"]],
            stdout=self.console, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
            cwd=S.BASE_DIR,
        )
        self.started_at = time.time()
        log.info("Started %-5s port %d  v%-3s  (pid %d)", j["crane"], j["port"],
                 j["version"], self.proc.pid)

    def check(self):
        now = time.time()
        if self.proc is None:
            if now >= self.next_start:
                self.start()
            return
        if self.proc.poll() is None:
            if now - self.started_at > 300:
                self.backoff = 10               # healthy for 5 min -> reset backoff
            return
        log.error("%s stopped (exit code %s) - restarting in %ds (see logs\\%s.log)",
                  self.job["crane"], self.proc.returncode, self.backoff, self.job["crane"])
        self.console.close()
        self.proc = None
        self.restarts += 1
        self.next_start = now + self.backoff
        self.backoff = min(self.backoff * 2, 120)

    def stop(self):
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(5)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        if self.console:
            self.console.close()


def write_launcher_status(collectors, skipped):
    data = {
        "pid": os.getpid(), "updated": time.time(),
        "excel": str(S.CRANE_LIST_FILE),
        "cranes": [
            {**c.job, "pid": c.proc.pid if c.proc else None,
             "running": bool(c.proc and c.proc.poll() is None), "restarts": c.restarts}
            for c in collectors
        ],
        "skipped": [{"crane": c, "reason": r} for c, r in skipped],
    }
    tmp = LAUNCHER_STATUS.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
        os.replace(tmp, LAUNCHER_STATUS)
    except OSError:
        pass


def setup_logging():
    for d in (S.LOG_DIR, S.STATUS_DIR, S.RUN_DIR):
        d.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s  [LAUNCHER]  %(levelname)s  %(message)s",
                            "%Y-%m-%d %H:%M:%S")
    fh = RotatingFileHandler(S.LOG_DIR / "launcher.log", maxBytes=S.LOG_MAX_BYTES,
                             backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    if sys.stdout.isatty():             # only when run in a window, not as a service
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        log.addHandler(sh)
    log.setLevel(logging.INFO)


def print_plan(jobs, skipped):
    print(f"\nCrane list: {S.CRANE_LIST_FILE.name}")
    print(f"  {'CRANE':<6} {'PORT':>6}  {'VER':<4} {'BYTES':>5}  SHEET")
    for j in sorted(jobs, key=lambda j: j["crane"]):
        print(f"  {j['crane']:<6} {j['port']:>6}  {j['version']:<4} "
              f"{S.PACKET_SIZE[j['version']]:>5}  {j['sheet']}")
    print(f"  -> {len(jobs)} cranes will run")
    for crane, reason in skipped:
        print(f"  NOT STARTED  {crane}: {reason}")
    print()


def _stop_signal(*_):
    raise KeyboardInterrupt


def main():
    import signal
    for name in ("SIGTERM", "SIGBREAK"):      # service stop / window closed -> clean stop
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), _stop_signal)
    setup_logging()
    check_only = "--check" in sys.argv

    if not S.CRANE_LIST_FILE.exists():
        log.error("Crane list not found: %s", S.CRANE_LIST_FILE)
        sys.exit(1)
    jobs, skipped = read_crane_list(S.CRANE_LIST_FILE)
    print_plan(jobs, skipped)
    for crane, reason in skipped:
        log.warning("NOT STARTED %s: %s", crane, reason)
    if check_only:
        return
    if not jobs:
        log.error("No cranes to start.")
        sys.exit(1)

    stop_previous_launcher()
    PID_FILE.write_text(str(os.getpid()))

    # Remove old status files so the status screen only shows current cranes
    for f in S.STATUS_DIR.glob("*.json"):
        try:
            f.unlink()
        except OSError:
            pass

    log.info("Freeing %d UDP ports before start ...", len(jobs))
    free_ports([j["port"] for j in jobs])

    collectors = [Collector(j) for j in sorted(jobs, key=lambda j: j["crane"])]
    for c in collectors:
        c.start()

    interactive = sys.stdout.isatty()
    if interactive:
        import crane_status
    next_screen = time.time() + 5
    try:
        while True:
            for c in collectors:
                c.check()
            write_launcher_status(collectors, skipped)
            if interactive and time.time() >= next_screen:
                crane_status.show(clear=True,
                                  footer="Launcher running - press Ctrl+C to stop ALL cranes")
                next_screen = time.time() + 5
            time.sleep(1)
    except KeyboardInterrupt:
        log.info("Stopping all collectors ...")
    finally:
        for c in collectors:
            c.stop()
        try:
            if PID_FILE.read_text().strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass
        write_launcher_status([], skipped)
        log.info("Launcher stopped.")


if __name__ == "__main__":
    main()
