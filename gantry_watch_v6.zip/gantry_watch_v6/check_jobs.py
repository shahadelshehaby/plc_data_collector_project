"""
check_jobs.py - checks one PLC file for the things that make job ids look wrong.

    python check_jobs.py "path\\to\\file.csv"            (summary)
    python check_jobs.py "path\\to\\file.csv" 339        (also show rows around job 339)

Works on uploaded files, NAS day files (analyzer_data\\files\\<id>\\*.csv) and raw
InfluxDB downloads. It reads the file exactly the way the analysis does and
prints:
  - repeated timestamps (the same PLC second more than once)
  - gaps in the data
  - every short "blip": a job id that appears for a moment between two runs of
    the same other id (e.g. 339, 2342, 339)
  - job ids that come back later (339 ... 340 ... 339)
Nothing is changed.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))
import pandas as pd  # noqa: E402
from data_loader import load_plc_csv, JOB_ID, JOB_TYPE  # noqa: E402


def runs_of(df):
    ids = df[JOB_ID].astype(object).where(df[JOB_ID].notna(), "(empty)")
    run_no = (ids != ids.shift()).cumsum()
    out = []
    for _, b in df.groupby(run_no, sort=True):
        out.append(dict(id=ids.loc[b.index[0]], start=b["PLCTime"].iloc[0], end=b["PLCTime"].iloc[-1],
                        rows=len(b), secs=int((b["_ts"].iloc[-1] - b["_ts"].iloc[0]).total_seconds()) + 1,
                        types=",".join(str(int(t)) for t in pd.unique(b[JOB_TYPE].dropna()))))
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    path = sys.argv[1]
    around = sys.argv[2] if len(sys.argv) > 2 else None
    raw = None
    try:  # the file as stored, before the analysis sorts it
        from influx_clean import looks_like_influx, read_raw_file
        from data_loader import _peek_rows
        peek = _peek_rows(path)
        if peek and looks_like_influx(peek[0], peek[1:]):
            raw = read_raw_file(path).astype("string")
        elif path.lower().endswith(".csv"):
            raw = pd.read_csv(path, dtype=str, low_memory=False)
    except Exception:  # noqa: BLE001 - the checks below are optional
        raw = None
    df = load_plc_csv(path, keep_repeats=True)  # show repeats; the analysis drops them
    print(f"File: {os.path.basename(path)}")
    print(f"Rows: {len(df)}   from {df['PLCTime'].iloc[0]}  to {df['PLCTime'].iloc[-1]}")

    dup = df["PLCTime"].duplicated(keep=False)
    print(f"\nRepeated timestamps: {int(df['PLCTime'].duplicated().sum())} extra rows")
    if dup.any():
        conflict = df[dup].groupby("PLCTime")[JOB_ID].nunique()
        conflict = conflict[conflict > 1]
        print(f"  seconds where the repeated rows have DIFFERENT job ids: {len(conflict)}")
        for t in conflict.index[:10]:
            print(f"    {t}: ids {sorted(df.loc[df['PLCTime'] == t, JOB_ID].astype(str).unique())}")
    if raw is not None and "PLCTime" in raw.columns:
        back = pd.to_datetime(raw["PLCTime"], format="%Y-%m-%d-%H:%M:%S", errors="coerce").diff().dt.total_seconds() < 0
        print(f"  times going backwards in the file as stored: {int(back.sum())}")

    if raw is not None and {"PLCTime", "_time"} <= set(raw.columns):
        # Raw InfluxDB download: compare the PLC's own clock with InfluxDB's time.
        from influx_clean import parse_utc, local_timezone
        plc = pd.to_datetime(raw["PLCTime"], format="%Y-%m-%d-%H:%M:%S", errors="coerce")
        nas = parse_utc(raw["_time"]).dt.tz_convert(local_timezone()).dt.tz_localize(None)
        nas.index = raw.index
        off = (plc - nas).dt.total_seconds().dropna()
        print(f"\nRows without the PLC's own PLCTime (time taken from _time instead): {int(plc.isna().sum())}")
        if len(off):
            print(f"PLC clock minus NAS time: median {off.median():.0f} s, min {off.min():.0f} s, max {off.max():.0f} s"
                  + ("   <- the clocks differ: the analysis now shifts rows timed from _time by the median"
                     if (off.abs() > 5).any() and plc.isna().any() else ""))

    gaps = df["_ts"].diff().dt.total_seconds()
    big = gaps[gaps > 5]
    print(f"\nGaps longer than 5 s: {len(big)}" + (f" (longest {int(big.max())} s)" if len(big) else ""))
    print(f"Rows with an empty job id: {int(df[JOB_ID].isna().sum())}")

    runs = runs_of(df)
    print(f"\nJob id runs: {len(runs)}")
    blips = [(runs[i - 1], runs[i], runs[i + 1]) for i in range(1, len(runs) - 1)
             if runs[i - 1]["id"] == runs[i + 1]["id"] and runs[i]["id"] != runs[i - 1]["id"]]
    print(f"Blips (A, B, A): {len(blips)}")
    for a, b, c in blips[:30]:
        print(f"  {a['id']} -> {b['id']} for {b['secs']} s ({b['rows']} rows, MoveType {b['types']}) "
              f"at {b['start']} -> back to {c['id']}")
    seen, back = {}, []
    for i, r in enumerate(runs):
        if r["id"] in seen and i - seen[r["id"]] > 2:
            back.append((r["id"], runs[seen[r["id"]]]["start"], r["start"]))
        seen[r["id"]] = i
    print(f"Ids that come back later (not counting blips): {len(back)}")
    for wid, first, again in back[:20]:
        print(f"  {wid}: first at {first}, again at {again}")

    if around is not None:
        idx = [i for i, r in enumerate(runs) if str(r["id"]) in (around, f"{around}.0")]
        print(f"\nRuns around job {around}:")
        for i in idx[:5]:
            for r in runs[max(0, i - 3): i + 4]:
                mark = " <" if r is runs[i] else ""
                print(f"  {str(r['id']):>8}  {r['start']} to {r['end'][11:]}  {r['secs']:>5} s  "
                      f"{r['rows']:>5} rows  MoveType {r['types']}{mark}")
            print()


if __name__ == "__main__":
    main()
