@echo off
REM ======================================================================
REM  Installs the Terminal 2 crane collectors as a Windows service.
REM  Right-click this file -> "Run as administrator".
REM  After this, the cranes start automatically when the PC boots,
REM  keep running when you log off / close VS Code, and restart on crash.
REM ======================================================================
setlocal
cd /d "%~dp0"
set SVC=CraneCollectorT2

net session >nul 2>&1
if errorlevel 1 (
    echo Please right-click install_service.bat and choose "Run as administrator".
    pause & exit /b 1
)

set "NSSM=%~dp0nssm.exe"
if not exist "%NSSM%" (
    echo nssm.exe was not found in this folder.
    echo Download it from https://nssm.cc/download , open the zip, and copy
    echo win64\nssm.exe into: %~dp0
    pause & exit /b 1
)

for /f "delims=" %%P in ('python -c "import sys; print(sys.executable)"') do set "PY=%%P"
if not defined PY (
    echo Python was not found. Install Python or add it to PATH.
    pause & exit /b 1
)
echo Using Python: %PY%

"%PY%" -c "import influxdb_client, openpyxl" 2>nul
if errorlevel 1 (
    echo Installing required packages ...
    "%PY%" -m pip install -r requirements.txt
)

if not exist "influx_token.txt" if not defined INFLUX_TOKEN (
    echo influx_token.txt is missing. Create it in this folder with the InfluxDB token on one line.
    pause & exit /b 1
)

echo Checking the crane list ...
"%PY%" launch_cranes.py --check
if errorlevel 1 ( pause & exit /b 1 )

"%NSSM%" stop %SVC% >nul 2>&1
"%NSSM%" remove %SVC% confirm >nul 2>&1

"%NSSM%" install %SVC% "%PY%" launch_cranes.py
"%NSSM%" set %SVC% AppDirectory "%~dp0."
"%NSSM%" set %SVC% DisplayName "Terminal 2 Crane Collectors"
"%NSSM%" set %SVC% Description "Crane PLC UDP -> InfluxDB collectors (launch_cranes.py)"
"%NSSM%" set %SVC% Start SERVICE_DELAYED_AUTO_START
"%NSSM%" set %SVC% AppExit Default Restart
"%NSSM%" set %SVC% AppRestartDelay 10000
"%NSSM%" set %SVC% AppStopMethodConsole 8000
"%NSSM%" set %SVC% AppKillProcessTree 1
if not exist logs mkdir logs
"%NSSM%" set %SVC% AppStdout "%~dp0logs\service_output.txt"
"%NSSM%" set %SVC% AppStderr "%~dp0logs\service_output.txt"
"%NSSM%" set %SVC% AppRotateFiles 1
"%NSSM%" set %SVC% AppRotateBytes 5000000

"%NSSM%" start %SVC%
echo.
echo Service %SVC% installed and started.
echo Double-click view_status.bat to see the cranes.
pause
