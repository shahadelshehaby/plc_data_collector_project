"""
run.py - double-click run.bat (or `python run.py`) to start the Engineering Building.

1. Installs missing packages (first run only): flask, psutil, openpyxl.
2. Starts the building and its process monitor.
3. Opens the building in your browser.
"""
import os
import subprocess
import sys
import threading
import time
import webbrowser

REQUIRED = {"flask": "flask", "psutil": "psutil", "openpyxl": "openpyxl"}


def ensure_dependencies():
    missing = []
    for mod, pkg in REQUIRED.items():
        try:
            __import__(mod)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"Installing missing packages: {', '.join(missing)} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    ensure_dependencies()
    from building_app import app, load_settings, start_background

    start_background()
    port = load_settings()["port"]
    url = f"http://127.0.0.1:{port}"

    def open_browser():
        time.sleep(1.5)
        webbrowser.open(url)

    threading.Thread(target=open_browser, daemon=True).start()
    print(f"\nEngineering Building running at {url}")
    print("Keep this window open while using it. Press Ctrl+C to stop.\n")
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as e:
        print(f"\nSomething went wrong: {e}")
        input("Press Enter to close...")
