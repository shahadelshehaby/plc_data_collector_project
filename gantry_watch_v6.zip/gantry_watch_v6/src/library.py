"""
library.py
===========
Everything the analyzer keeps between sessions, under analyzer_data/:

  files/<id>/<name>     uploaded PLC files (kept until you delete them in the UI)
  cache/<id>.pkl        analysis results for that file, tagged with the settings
                        they were computed with
  library.json          the file list (crane, lane, dates covered, status)
  generated/<job>/      the most recent report sets (+ job.json), so the report
                        list is still there after a restart. Older sets are
                        removed automatically (KEEP_REPORT_SETS).

Analysis is done once per file per settings. When a profile's settings
change (or the Columns_info file is replaced), cached results no longer
match and the file is re-analyzed automatically the next time it's needed.

All work (analysis and report building) runs on ONE background worker
thread, in order, so the UI stays responsive and runs never overlap.
"""
import contextlib
import hashlib
import io
import json
import os
import pickle
import queue
import re
import shutil
import threading
import time
import traceback
import uuid
from collections import defaultdict

from pipeline import analyze_file, build_reports, apply_columns_info, period_label
from utils import derive_machine_name, lane_of, display_date
from rules import set_lane_rule
import influx_clean
from results_store import open_store


def analysis_workers():
    """How many files are analysed at the same time: one per CPU core,
    keeping one core free for the app and the NAS sync (at most 6)."""
    if os.environ.get("GANTRY_WATCH_WORKERS", "").isdigit():
        return max(1, int(os.environ["GANTRY_WATCH_WORKERS"]))
    return max(1, min(6, (os.cpu_count() or 2) - 1))


def _analyze_in_process(path, machine, config, columns_info, tz_name):
    """Runs in a separate process (see Library._pool): sets up that process's
    module settings, then analyses one file."""
    try:
        influx_clean.set_local_timezone(tz_name)
    except ValueError:
        pass
    apply_columns_info(columns_info, log=lambda *a: None)
    set_lane_rule(config.rules)
    quality = {}
    results, ps_results, raw_dates = analyze_file(path, machine, config, quality=quality)
    return results, ps_results, raw_dates, quality

KEEP_REPORT_SETS = 20
# Bump when the analysis code changes in a way that makes old cached results
# wrong - every file is then re-analyzed on next use.
ANALYSIS_VERSION = "7"  # 7: data quality figures for the analysis tabs


class _LogWriter(io.TextIOBase):
    """Captures print() output from the analysis modules into a log list."""

    def __init__(self, sink):
        self.sink, self._buf = sink, ""

    def write(self, s):
        self._buf += s
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            if line.strip():
                self.sink.append(line)
        return len(s)


def safe_filename(name: str) -> str:
    base = os.path.basename(name.replace("\\", "/"))
    base = re.sub(r"[^A-Za-z0-9._\- ]+", "_", base).strip(" .")
    return base or "file"


class Library:
    def __init__(self, project_root, store, columns_info_fn):
        self.store = store
        self.columns_info_fn = columns_info_fn
        self.data_dir = os.path.join(project_root, "analyzer_data")
        self.files_dir = os.path.join(self.data_dir, "files")
        self.cache_dir = os.path.join(self.data_dir, "cache")
        self.gen_dir = os.path.join(self.data_dir, "generated")
        for d in (self.files_dir, self.cache_dir, self.gen_dir):
            os.makedirs(d, exist_ok=True)
        self.index_path = os.path.join(self.data_dir, "library.json")
        self.lock = threading.RLock()
        self.queue = queue.Queue()
        self.busy = None          # human-readable description of current work
        # Progress of the current unit of work, read by building_status.py:
        # {"step": str, "done": int, "total": int} or None when idle.
        self.progress = None
        self.sync_progress = None  # set by nas_sync.py while pulling from the NAS
        self.sync_issue = None     # (time, message) of the last failed NAS sync
        self._batch_done = 0      # files analyzed in the current upload batch
        self.files = self._load_index()
        self.jobs = self._load_jobs()
        # Results for the analysis tabs (results_store.py).
        self.results = open_store(self.data_dir)
        self._objects_cache = {}   # fid -> (cache file time, {(kind, start, workorder): result})
        # Files are analysed in parallel in separate processes (one per CPU
        # core); reports are built one at a time (the PDF charts need that).
        self.workers = analysis_workers()
        self._pool = None
        self._pool_lock = threading.Lock()
        self._report_lock = threading.Lock()
        self._inline_lock = threading.Lock()
        self._claimed = set()
        for n in range(self.workers):
            threading.Thread(target=self._worker, daemon=True, name=f"analyzer-worker-{n + 1}").start()
        threading.Thread(target=self._fill_results, daemon=True, name="results-fill").start()
        for fid, f in self.files.items():
            if f["status"] in ("pending", "analyzing", "queued"):
                f["status"] = "pending"
                self.queue.put(("analyze", fid))
            f.setdefault("source", "upload")

    # ------------------------------------------------------------ persistence
    def _load_index(self):
        if os.path.isfile(self.index_path):
            try:
                with open(self.index_path, encoding="utf-8") as f:
                    files = json.load(f)
                # drop entries whose file was removed by hand
                return {k: v for k, v in files.items() if os.path.isfile(self._file_path(v))}
            except (OSError, ValueError):
                pass
        return {}

    def _save_index(self):
        with self.lock:
            tmp = self.index_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.files, f, indent=1)
            os.replace(tmp, self.index_path)

    def _load_jobs(self):
        jobs = {}
        for jid in os.listdir(self.gen_dir):
            path = os.path.join(self.gen_dir, jid, "job.json")
            try:
                with open(path, encoding="utf-8") as f:
                    job = json.load(f)
            except (OSError, ValueError):
                shutil.rmtree(os.path.join(self.gen_dir, jid), ignore_errors=True)
                continue
            if job.get("status") in ("queued", "running"):
                job["status"] = "failed"
                job["error"] = "The analyzer was closed before this finished. Generate it again."
            jobs[jid] = job
        return jobs

    def _save_job(self, job):
        folder = os.path.join(self.gen_dir, job["id"])
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "job.json"), "w", encoding="utf-8") as f:
            json.dump(job, f, indent=1)

    def _prune_jobs(self):
        with self.lock:
            finished = sorted((j for j in self.jobs.values() if j["status"] in ("done", "failed")),
                              key=lambda j: j["created"], reverse=True)
            for job in finished[KEEP_REPORT_SETS:]:
                shutil.rmtree(os.path.join(self.gen_dir, job["id"]), ignore_errors=True)
                self.jobs.pop(job["id"], None)

    # --------------------------------------------------------------- settings
    def settings_key(self, profile):
        h = hashlib.sha1(ANALYSIS_VERSION.encode())
        h.update(self.store.profile_xml_text(profile).encode("utf-8"))
        ci = self.columns_info_fn()
        if ci and os.path.isfile(ci):
            with open(ci, "rb") as f:
                h.update(f.read())
        return h.hexdigest()[:16]

    # ------------------------------------------------------------------ files
    def _file_path(self, entry):
        return os.path.join(self.files_dir, entry["id"], entry["name"])

    def _cache_path(self, fid):
        return os.path.join(self.cache_dir, f"{fid}.pkl")

    def add_file(self, upload_name, save_fn):
        """save_fn(path) writes the uploaded bytes. A file with the same name
        as an existing one replaces it."""
        name = safe_filename(upload_name)
        with self.lock:
            for fid, f in list(self.files.items()):
                if f["name"].lower() == name.lower() and f.get("source", "upload") == "upload":
                    self._remove(fid)
            fid = uuid.uuid4().hex[:12]
            os.makedirs(os.path.join(self.files_dir, fid), exist_ok=True)
        path = os.path.join(self.files_dir, fid, name)
        save_fn(path)
        machine = derive_machine_name(name)
        entry = {"id": fid, "name": name, "machine": machine, "lane": lane_of(machine),
                 "size": os.path.getsize(path), "uploaded_at": time.time(), "dates": [],
                 "status": "pending", "error": None, "key": None, "profile": None,
                 "n_moves": None, "n_pickups": None, "source": "upload", "version": 1}
        with self.lock:
            self.files[fid] = entry
            self._save_index()
        self.queue.put(("analyze", fid))
        return entry

    # ------------------------------------------------------------- NAS rows
    def synced_file_name(self, crane, day):
        return f"{crane}_{day}_nas.csv"

    def append_synced_rows(self, tag, crane, day, rows):
        """Adds rows pulled from the NAS (DataFrame of strings with a
        local-time PLCTime) to the file for this crane and day, creating it
        if needed. Rows already in the file (same PLCTime) are skipped.
        Returns (file id, number of new rows). Does not start analysis -
        call queue_analysis() when the pull for this crane is finished."""
        import pandas as pd
        name = self.synced_file_name(crane, day)
        with self.lock:
            entry = next((f for f in self.files.values()
                          if f.get("source") == "nas" and f.get("nas_tag") == tag and f.get("nas_day") == day), None)
            if entry is None:
                fid = uuid.uuid4().hex[:12]
                os.makedirs(os.path.join(self.files_dir, fid), exist_ok=True)
                entry = {"id": fid, "name": name, "machine": crane, "lane": lane_of(crane), "size": 0,
                         "uploaded_at": time.time(), "dates": [day], "status": "new", "error": None,
                         "key": None, "profile": None, "n_moves": None, "n_pickups": None,
                         "source": "nas", "nas_tag": tag, "nas_day": day, "rows": 0, "version": 0}
                self.files[fid] = entry
        path = self._file_path(entry)
        rows = rows.drop_duplicates(subset="PLCTime", keep="last")

        if os.path.isfile(path):
            header = list(pd.read_csv(path, nrows=0).columns)
            existing = set(pd.read_csv(path, usecols=["PLCTime"], dtype=str)["PLCTime"])
            rows = rows[~rows["PLCTime"].isin(existing)]
            if rows.empty:
                return entry["id"], 0
            tmp = path + ".tmp"
            if set(rows.columns) <= set(header):
                # Same columns: copy the file and append (cheap even for a full day).
                shutil.copyfile(path, tmp)
                rows.reindex(columns=header).to_csv(tmp, mode="a", header=False, index=False)
            else:
                # A new field appeared on the NAS: rewrite with the wider header.
                old = pd.read_csv(path, dtype=str, keep_default_na=False)
                pd.concat([old, rows], ignore_index=True, sort=False).to_csv(tmp, index=False)
        else:
            if rows.empty:
                return entry["id"], 0
            tmp = path + ".tmp"
            rows.to_csv(tmp, index=False)
        self._replace_file(tmp, path)

        with self.lock:
            entry["size"] = os.path.getsize(path)
            entry["rows"] = entry.get("rows", 0) + len(rows)
            entry["version"] = entry.get("version", 0) + 1
            entry["synced_at"] = time.time()
            if entry["status"] != "analyzing":
                entry["status"] = "new"
            self._save_index()
        return entry["id"], len(rows)

    @staticmethod
    def _replace_file(tmp, path):
        # On Windows the target can be briefly locked while it is being read.
        for attempt in range(20):
            try:
                os.replace(tmp, path)
                return
            except PermissionError:
                time.sleep(0.25)
        os.replace(tmp, path)

    def queue_analysis(self, fids):
        with self.lock:
            for fid in fids:
                f = self.files.get(fid)
                if f is not None and f["status"] in ("new", "ready", "error", "outdated"):
                    f["status"] = "pending"
                    self.queue.put(("analyze", fid))
            self._save_index()

    def reanalyse_outdated(self):
        """Queues every file analysed with other settings (or an older
        version) for analysis with the current ones, newest days first, so
        the analysis tabs always show results for the current settings."""
        try:
            key = self.settings_key(self.store.load_app_settings()["active_profile"])
        except Exception:  # noqa: BLE001 - a broken profile: leave the files as they are
            return 0
        with self.lock:
            todo = [f for f in self.files.values()
                    if f["status"] in ("ready", "error") and f.get("key") != key]
        todo.sort(key=lambda f: (f.get("dates") or [""])[-1], reverse=True)
        self.queue_analysis([f["id"] for f in todo])
        return len(todo)

    def rename_synced_machine(self, tag, crane):
        """The crane name for a NAS machine changed: update its files.
        Returns the ids of the files that changed."""
        changed = []
        with self.lock:
            for f in self.files.values():
                if f.get("source") == "nas" and f.get("nas_tag") == tag and f["machine"] != crane:
                    old_path = self._file_path(f)
                    new_name = self.synced_file_name(crane, f["nas_day"])
                    if os.path.isfile(old_path):
                        os.replace(old_path, os.path.join(os.path.dirname(old_path), new_name))
                    f.update(name=new_name, machine=crane, lane=lane_of(crane), key=None,
                             status="new" if f["status"] != "analyzing" else f["status"])
                    f["version"] = f.get("version", 0) + 1
                    changed.append(f["id"])
            self._save_index()
        if changed:
            self.results.rename_machine(changed, crane)
        return changed

    def _remove(self, fid):
        self.files.pop(fid, None)
        try:
            self.results.remove_file(fid)
        except Exception:  # noqa: BLE001
            traceback.print_exc()
        shutil.rmtree(os.path.join(self.files_dir, fid), ignore_errors=True)
        if os.path.exists(self._cache_path(fid)):
            os.remove(self._cache_path(fid))

    def delete_file(self, fid):
        with self.lock:
            f = self.files.get(fid)
            if f is None:
                return False
            if f["status"] == "analyzing":
                raise RuntimeError("This file is being analyzed right now. Try again in a moment.")
            self._remove(fid)
            self._save_index()
        return True

    def list_files(self):
        profile = self.store.load_app_settings()["active_profile"]
        key = self.settings_key(profile)
        try:
            set_lane_rule(self.store.load_profile_config(profile).rules)
        except Exception:  # noqa: BLE001 - a broken profile must not hide the file list
            pass
        with self.lock:
            files = []
            for f in sorted(self.files.values(), key=lambda x: (x["machine"], x["dates"][:1], x["name"])):
                item = dict(f)
                if f["status"] == "ready" and f["key"] != key:
                    item["status"] = "outdated"
                item["lane"] = lane_of(f["machine"])
                files.append(item)
        machines = defaultdict(set)
        for f in files:
            machines[f["machine"]].update(f["dates"])
        all_dates = sorted({d for ds in machines.values() for d in ds})
        return {
            "files": files,
            "machines": [{"machine": m, "lane": lane_of(m), "dates": sorted(ds)}
                         for m, ds in sorted(machines.items())],
            "lanes": sorted({lane_of(m) for m in machines}),
            "date_min": all_dates[0] if all_dates else None,
            "date_max": all_dates[-1] if all_dates else None,
            "dates": all_dates,
            "busy": self.busy,
            "active_profile": profile,
        }

    def _analyze(self, fid, profile, config, key, log):
        with self.lock:
            f = self.files.get(fid)
            if f is None:
                return None
            f["status"] = "analyzing"
            version = f.get("version", 1)
        self.busy = f"Analyzing {f['name']}"
        if self.progress is None or not self.progress.get("report"):
            waiting = sum(1 for x in self.files.values() if x["status"] in ("pending", "analyzing"))
            self.progress = {"step": f"Analyzing {f['name']}", "done": self._batch_done,
                             "total": self._batch_done + waiting}
        try:
            results, ps_results, raw_dates, quality = self._run_analysis(self._file_path(f), f["machine"], config)
            with self.lock:
                if f.get("version", 1) != version:
                    # New rows arrived from the NAS meanwhile: analyze again.
                    f["status"] = "pending"
                    self.queue.put(("analyze", fid))
                    log(f"  {f['name']} received new rows while being analyzed; analyzing again.")
                    return results, ps_results
            with open(self._cache_path(fid), "wb") as fh:
                pickle.dump({"key": key, "results": results, "ps_results": ps_results}, fh)
            dates = sorted(set(raw_dates) | {r.date for r in results} | {r.date for r in ps_results})
            try:
                self.results.replace_file(fid, f["machine"], f["name"], key, results, ps_results, quality, dates)
            except Exception:  # noqa: BLE001 - the reports still work without the tabs
                traceback.print_exc()
            with self.lock:
                f.update(status="ready", error=None, key=key, profile=profile, analyzed_at=time.time(),
                         dates=dates, n_moves=len(results), n_pickups=len(ps_results))
            log(f"  {f['name']}: {len(results)} reposition move(s), {len(ps_results)} pickup workorder(s)")
            return results, ps_results
        except Exception as e:
            msg = (f"Column '{e.args[0]}' was not found in the file. Check Settings > Column mapping, "
                   f"or that this is a PLC export." if isinstance(e, KeyError) and e.args else str(e))
            with self.lock:
                if f.get("version", 1) != version:
                    f["status"] = "pending"
                    self.queue.put(("analyze", fid))
                    return None
                f.update(status="error", error=msg, key=key, profile=profile, analyzed_at=time.time(),
                         analyzed_version=version)
            try:
                self.results.remove_file(fid)
            except Exception:  # noqa: BLE001
                traceback.print_exc()
            log(f"  ERROR analyzing {f['name']}: {msg}")
            return None
        finally:
            self.busy = None
            self._save_index()

    def _fill_results(self):
        """Makes the results database match the library: files analysed with
        the current settings but missing there are added from their cache,
        and deleted files are removed."""
        try:
            profile = self.store.load_app_settings()["active_profile"]
            key = self.settings_key(profile)
            stored = self.results.stored_keys()
            for fid in set(stored) - set(self.files):
                self.results.remove_file(fid)
            for fid, f in list(self.files.items()):
                if f["status"] != "ready" or f.get("key") != key or stored.get(fid) == key:
                    continue
                try:
                    with open(self._cache_path(fid), "rb") as fh:
                        data = pickle.load(fh)
                except Exception:  # noqa: BLE001 - it will be analysed again
                    continue
                if data.get("key") == key:
                    self.results.replace_file(fid, f["machine"], f["name"], key, data["results"],
                                              data["ps_results"], None, f.get("dates") or [])
        except Exception:  # noqa: BLE001
            traceback.print_exc()
        self.reanalyse_outdated()

    def result_objects(self, rows):
        """Full result objects (with speed curves etc.) for rows of the
        results database, read from the per-file cache - for the charts the
        analysis tabs show on request."""
        wanted = {}
        for r in rows:
            wanted.setdefault(r["fid"], []).append(r)
        found = {}
        for fid, rs in wanted.items():
            path = self._cache_path(fid)
            try:
                stamp = os.path.getmtime(path)
                cached = self._objects_cache.get(fid)
                if cached is None or cached[0] != stamp:
                    with open(path, "rb") as fh:
                        data = pickle.load(fh)
                    index = {}
                    for e in list(data["results"]) + list(data["ps_results"]):
                        kind = "pickup" if hasattr(e, "pickup_setdown") else "reposition"
                        index[(kind, e.time_start, str(e.workorder))] = e
                    cached = (stamp, index)
                    self._objects_cache[fid] = cached
                    while len(self._objects_cache) > 8:
                        self._objects_cache.pop(next(iter(self._objects_cache)))
            except (OSError, pickle.UnpicklingError, EOFError, KeyError):
                continue
            for r in rs:
                e = cached[1].get((r["kind"], r["t_start"], str(r["workorder"])))
                if e is not None:
                    found[r["eid"]] = e
        return [found[r["eid"]] for r in rows if r["eid"] in found]

    def _get_pool(self):
        """The worker processes (created on first use), or None when work
        runs in this process only."""
        with self._pool_lock:
            if self.workers <= 1:
                return None
            if self._pool is None:
                import multiprocessing
                from concurrent.futures import ProcessPoolExecutor
                # "spawn" is what Windows always uses; using it everywhere
                # keeps the behaviour the same on every PC.
                self._pool = ProcessPoolExecutor(max_workers=self.workers,
                                                 mp_context=multiprocessing.get_context("spawn"))
            return self._pool

    def _safe_pool(self):
        try:
            return self._get_pool()
        except (OSError, ImportError, RuntimeError) as e:
            print(f"  Parallel work not available ({e}); writing reports one at a time.")
            with self._pool_lock:
                self.workers = 1
            return None

    def _run_analysis(self, path, machine, config):
        """Analyses one file in the process pool; falls back to this process
        (one file at a time) if the pool can't be used."""
        if self.workers > 1:
            from concurrent.futures.process import BrokenProcessPool
            fut = None
            try:
                pool = self._get_pool()
                if pool is not None:
                    fut = pool.submit(_analyze_in_process, path, machine, config,
                                      self.columns_info_fn(), influx_clean._local_tz_name)
                error = None
            except (OSError, ImportError, RuntimeError) as e:  # pool could not start
                error = e
            if fut is not None:
                try:
                    return fut.result()  # errors in the analysis itself are raised here as usual
                except (BrokenProcessPool, pickle.PicklingError) as e:
                    error = e
            if error is not None:
                e = error
                print(f"  Parallel analysis not available ({e.__class__.__name__}: {e}); "
                      f"analysing one file at a time.")
                with self._pool_lock:
                    self.workers = 1
                    self._pool = None
        with self._inline_lock:
            apply_columns_info(self.columns_info_fn())
            quality = {}
            results, ps_results, raw_dates = analyze_file(path, machine, config, quality=quality)
            return results, ps_results, raw_dates, quality

    def _results_for(self, fid, profile, config, key, log):
        """Cached results if they match the settings, else analyze now."""
        f = self.files.get(fid)
        if f is None:
            return None
        if f["status"] == "ready" and f["key"] == key:
            try:
                with open(self._cache_path(fid), "rb") as fh:
                    data = pickle.load(fh)
                if data.get("key") == key:
                    return data["results"], data["ps_results"]
            except Exception:
                pass  # unreadable cache: fall through and re-analyze
        if f["status"] == "error" and f["key"] == key and f.get("analyzed_version") == f.get("version", 1):
            log(f"  Skipping {f['name']} (it couldn't be analyzed: {f['error']})")
            return None
        log(f"Analyzing {f['name']}" + (" with the current settings" if f["key"] else "") + " ...")
        return self._analyze(fid, profile, config, key, log)

    # ---------------------------------------------------------------- reports
    def start_report(self, filters):
        profile = self.store.load_app_settings()["active_profile"]
        jid = uuid.uuid4().hex[:12]
        job = {"id": jid, "status": "queued", "created": time.time(), "started": None, "finished": None,
               "profile": profile, "filters": filters, "title": self._title(filters),
               "log": [], "outputs": [], "problems": [], "error": None, "note": None}
        with self.lock:
            self.jobs[jid] = job
        self._save_job(job)
        self.queue.put(("report", jid))
        return job

    def _title(self, flt):
        span = period_label(flt["date_from"], flt["date_to"])
        mode = "Period report" if flt["mode"] == "period" else "Daily reports"
        return f"{mode}, {span}"

    def _filters_text(self, flt, machines_used):
        parts = [f"Lanes: {', '.join(flt['lanes'])}" if flt.get("lanes") else "Lanes: all"]
        parts.append(f"Cranes: {', '.join(flt['machines'])}" if flt.get("machines")
                     else f"Cranes: all ({', '.join(sorted(machines_used))})")
        return "Filters - " + "; ".join(parts)

    def _run_report(self, job):
        flt = job["filters"]
        log = job["log"]
        job["status"], job["started"] = "running", time.time()
        self.busy = f"Building {job['title'].lower()}"
        writer = _LogWriter(log)
        try:
            with contextlib.redirect_stdout(writer):
                profile = job["profile"]
                if profile not in self.store.list_profiles():
                    profile = self.store.load_app_settings()["active_profile"]
                    job["profile"] = profile
                config = self.store.load_profile_config(profile)
                set_lane_rule(config.rules)
                apply_columns_info(self.columns_info_fn())
                key = self.settings_key(profile)
                d_from, d_to = flt["date_from"], flt["date_to"]
                want_m, want_l = set(flt.get("machines") or []), set(flt.get("lanes") or [])

                def machine_ok(m):
                    return (not want_m or m in want_m) and (not want_l or lane_of(m) in want_l)

                with self.lock:
                    candidates = [f for f in self.files.values() if machine_ok(f["machine"])
                                  and (not f["dates"] or any(d_from <= d <= d_to for d in f["dates"]))]
                print(f"Profile: {profile}. {len(candidates)} file(s) match the cranes and dates.")

                by_date = defaultdict(lambda: defaultdict(list))
                ps_by_date = defaultdict(lambda: defaultdict(list))
                seen = set()
                ordered = sorted(candidates, key=lambda x: x["uploaded_at"])
                total = len(ordered) + 1  # +1 = writing the PDFs
                for i, f in enumerate(ordered):
                    self.progress = {"step": f"{job['title']}: reading {f['name']}", "done": i,
                                     "total": total, "report": True}
                    res = self._results_for(f["id"], profile, config, key, print)
                    if res is None:
                        if self.files.get(f["id"], {}).get("status") == "error":
                            job["problems"].append(f"{f['name']}: {self.files[f['id']]['error']}")
                        continue
                    results, ps_results = res
                    for r in results:
                        k = ("m", r.machine, r.workorder, r.time_start)
                        if d_from <= r.date <= d_to and k not in seen:
                            seen.add(k)
                            by_date[r.date][r.machine].append(r)
                    for r in ps_results:
                        k = ("p", r.machine, r.workorder, r.time_start)
                        if d_from <= r.date <= d_to and k not in seen:
                            seen.add(k)
                            ps_by_date[r.date][r.machine].append(r)

                for d in list(by_date) + list(ps_by_date):
                    for m in by_date.get(d, {}):
                        by_date[d][m].sort(key=lambda r: r.time_start)
                    for m in ps_by_date.get(d, {}):
                        ps_by_date[d][m].sort(key=lambda r: r.time_start)

                machines_used = {m for d in by_date.values() for m in d} | {m for d in ps_by_date.values() for m in d}
                if not machines_used:
                    job["note"] = ("No moves found for these cranes between "
                                   f"{display_date(d_from)} and {display_date(d_to)}.")
                    print(job["note"])
                else:
                    print(f"Building reports for {len(machines_used)} crane(s) ...")
                    self.progress = {"step": f"{job['title']}: writing PDFs", "done": total - 1,
                                     "total": total, "report": True}
                    out_dir = os.path.join(self.gen_dir, job["id"], "files")
                    outputs, failed = build_reports(
                        {d: dict(v) for d, v in by_date.items()}, {d: dict(v) for d, v in ps_by_date.items()},
                        config, out_dir, mode=flt["mode"], date_from=d_from, date_to=d_to,
                        include_machine_reports=flt.get("include_machine_reports", True),
                        write_json=flt.get("json", False),
                        include_overview=flt.get("include_overview", True),
                        include_summary=flt.get("include_summary", True),
                        include_operation=flt.get("include_operation", True),
                        cases_shown=flt.get("cases", "settings"),
                        filters_text=self._filters_text(flt, machines_used), log=print,
                        pool=self._safe_pool(), columns_info=self.columns_info_fn())
                    job["outputs"] = outputs
                    job["problems"] += [f"Reports for {x['date']}: {x['error']}" for x in failed]
                print("Done.")
            job["status"] = "done"
        except Exception as e:
            log.append(f"ERROR: {e}")
            log.extend(traceback.format_exc().splitlines()[-6:])
            job["status"], job["error"] = "failed", str(e)
        finally:
            job["finished"] = time.time()
            self.busy = None
            self.progress = None
            self._save_job(job)
            self._prune_jobs()

    def delete_job(self, jid):
        with self.lock:
            job = self.jobs.get(jid)
            if job is None:
                return False
            if job["status"] in ("queued", "running"):
                raise RuntimeError("This report is still being built.")
            self.jobs.pop(jid, None)
        shutil.rmtree(os.path.join(self.gen_dir, jid), ignore_errors=True)
        return True

    def job_file(self, jid, relpath):
        job = self.jobs.get(jid)
        if job is None or relpath not in {o["relpath"] for o in job["outputs"]}:
            return None
        return os.path.join(self.gen_dir, jid, "files", *relpath.split("/"))

    # ----------------------------------------------------------------- worker
    def _worker(self):
        while True:
            kind, ident = self.queue.get()
            try:
                if kind == "analyze":
                    with self.lock:
                        f = self.files.get(ident)
                        if f is None or ident in self._claimed:
                            continue  # already being analysed by another worker
                        profile = self.store.load_app_settings()["active_profile"]
                        key = self.settings_key(profile)
                        if f["status"] == "ready" and f["key"] == key:
                            continue
                        self._claimed.add(ident)
                    try:
                        self._analyze(ident, profile, self.store.load_profile_config(profile), key, print)
                    finally:
                        with self.lock:
                            self._claimed.discard(ident)
                    self._batch_done += 1
                elif kind == "report":
                    job = self.jobs.get(ident)
                    if job is not None:
                        with self._report_lock:
                            self._run_report(job)
            except Exception:
                traceback.print_exc()
            finally:
                if self.queue.empty():
                    self.progress = None
                    self._batch_done = 0
                    if kind == "analyze" and not self._claimed:
                        # Settings changed while files were being analysed:
                        # those files still have old results, so queue them.
                        self.reanalyse_outdated()
