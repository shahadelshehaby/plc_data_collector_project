@echo off
REM Live status of all cranes. Closing this window does NOT stop the cranes.
cd /d "%~dp0"
title Terminal 2 - crane status
python crane_status.py
