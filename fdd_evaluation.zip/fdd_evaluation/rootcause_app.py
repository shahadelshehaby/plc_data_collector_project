"""
FDD Root Cause Analysis — standalone program (port 5001).

Reads what the Evaluation program saved when it evaluated a fault — the real events and how each one lined up
with the rule — plus the stored PLC data, and works out WHY each fault happened. It only READS the Evaluation
project's files (folder set in rootcause_config.json); everything it writes (pattern groups, labels) goes to its
own folder, rootcause_data/<terminal_type>/rootcause_state.json. Each terminal/type is reviewed separately.
"""
import sys
if sys.version_info < (3, 9):
    print("This tool needs Python 3.9 or newer. Download it from https://python.org/downloads")
    input("Press Enter to close...")
    sys.exit(1)

import re
import traceback

import pandas as pd
from flask import Flask, jsonify, request

import building_status as bs
import fta
import rc_core as core
from fta_ui import FTA_CSS, FTA_HTML, FTA_JS
from rc_common import (PORT_ROOT_CAUSE, ensure_config, eval_dir, load_registry, normalize_feature_specs, program_label,
                       rc_state_load, rc_state_save, read_handoff, read_json, read_manifest, register_logo, rule_hash,
                       run_server, serve_page, ws_paths)

ensure_config()
app = Flask(__name__)
register_logo(app)
try:
    bs.register(app)     # GET /building/status for the Engineering Building dashboard
except Exception:        # noqa: BLE001  (the integration must never be able to stop the program starting)
    traceback.print_exc()

fta.register(app)   # Fault Tree Analysis tab: /api/fta/programs, /api/fta/trees
_plc_cache = {}   # program key -> {"sig", "plc", "by"}


def load_plc(key, ts_col, machine_col):
    """One program's stored PLC data (cached until the file changes), whole and split per machine."""
    p = ws_paths(key).plc_store
    if not p.exists() or not ts_col:
        return None, None
    st = p.stat()
    sig = (st.st_mtime_ns, st.st_size, ts_col, machine_col)
    c = _plc_cache.get(key)
    if not c or c["sig"] != sig:
        df = pd.read_csv(p)
        df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
        df = df.dropna(subset=[ts_col]).sort_values(ts_col).reset_index(drop=True)
        if machine_col and machine_col in df.columns:
            df[machine_col] = df[machine_col].astype(str).str.strip()
            by = {name: g for name, g in df.groupby(machine_col)}
        else:
            by = {None: df}
        c = _plc_cache[key] = {"sig": sig, "plc": df, "by": by}
    return c["plc"], c["by"]


def effective_specs(rule, fs):
    """Context columns as set in the Evaluation program, with any 'converted to threshold' made here applied on top."""
    specs = normalize_feature_specs(rule.get("feature_columns"))
    overrides = (fs or {}).get("feature_overrides", {})
    for s in specs:
        if s["column"] in overrides:
            s.update(overrides[s["column"]])
    return specs


@app.route("/")
def index():
    html = (INDEX_HTML.replace("<!--FTA_HTML-->", FTA_HTML).replace("/*FTA_CSS*/", FTA_CSS)
            .replace("/*FTA_JS*/", FTA_JS))
    return serve_page(html)


@app.route("/api/faults")
def api_faults():
    out, not_ready, any_manifest = [], 0, False
    for prog in load_registry()["programs"]:
        key = prog["key"]
        manifest = read_manifest(key)
        if not manifest.get("faults"):
            continue
        any_manifest = True
        settings = read_json(ws_paths(key).settings, {}) or {}
        rc = rc_state_load(key)
        for name, entry in manifest["faults"].items():
            rule = (settings.get("rules") or {}).get(name) or {}
            versions = rule.get("versions") or []
            if not versions:
                continue
            ready = bool(effective_specs(rule, rc["faults"].get(name, {})))
            not_ready += 0 if ready else 1
            out.append({"program": key, "terminal": prog["terminal"], "type": prog["type"], "program_label": program_label(prog),
                        "name": name, "ready": ready, "evaluated_at": entry.get("evaluated_at"),
                        "counts": entry.get("counts"), "ground_truth": entry.get("ground_truth"),
                        "stale_logic": entry.get("rule_hash") != rule_hash(versions, settings.get("bypasses")),
                        "machine_aware": entry.get("machine_aware")})
    out.sort(key=lambda f: (str(f["terminal"]), str(f["type"]).lower(), f["name"].lower()))
    ed = eval_dir()
    return jsonify(ok=True, manifest_exists=any_manifest, faults=out, not_ready_count=not_ready,
                    eval_dir=str(ed), eval_found=(ed / 'programs.json').exists())


@app.route("/api/rc/evaluate", methods=["POST"])
def api_rc_evaluate():
    b = request.get_json(force=True) or {}
    with bs.job(f"Reviewing root causes: {b.get('fault', '')}", total=1, process="root_cause") as j:
        resp = _rc_evaluate(b)
        j.progress(done=1)
    return resp


def _rc_evaluate(b):
    fault, pkey = b.get("fault", ""), b.get("program")
    programs = {p["key"]: p for p in load_registry()["programs"]}
    if pkey not in programs:
        return jsonify(ok=False, error="Unknown terminal/type."), 400
    try:
        manifest = read_manifest(pkey)
        entry = (manifest.get("faults") or {}).get(fault)
        if not entry:
            return jsonify(ok=False, error="This fault hasn't been evaluated yet. Evaluate it in the Evaluation program first, then press Refresh here."), 400
        settings = read_json(ws_paths(pkey).settings, {}) or {}
        rule = (settings.get("rules") or {}).get(fault) or {}
        versions_raw = rule.get("versions") or []
        if not versions_raw:
            return jsonify(ok=False, error="This fault no longer has rule logic in the Evaluation program."), 400

        rc = rc_state_load(pkey)
        fs = rc["faults"].setdefault(fault, {})
        feature_specs = effective_specs(rule, fs)
        if not feature_specs:
            return jsonify(ok=False, error="Select at least one context column for this fault in the Evaluation program (Logic tab) first."), 400

        mapping = manifest.get("mapping") or {}
        ts_col, machine_col = mapping.get("plc_ts_col"), mapping.get("plc_machine_col")
        plc, plc_by_machine = load_plc(pkey, ts_col, machine_col)
        if plc is None:
            return jsonify(ok=False, error="No stored PLC data was found. Load PLC files (or sync from the NAS) and press Save settings in the Evaluation program first."), 400

        max_gap = float((entry.get("params") or {}).get("max_gap_seconds", 2))
        matched, iv = read_handoff(pkey, entry["slug"])
        matched_tp = matched[matched["status"] == "matched"].copy()
        feature_columns = [s["column"] for s in feature_specs]

        notices, warnings = [], []
        if rule_hash(versions_raw, settings.get("bypasses")) != entry.get("rule_hash"):
            notices.append({"kind": "warn", "text": "The rule logic for this fault has changed since it was last evaluated. Evaluate this fault again in the Evaluation program so these events match the current logic."})
        if entry.get("plc_rows") is not None and int(entry["plc_rows"]) != len(plc):
            notices.append({"kind": "warn", "text": f"The stored PLC data has changed since this fault was evaluated ({int(entry['plc_rows']):,} rows then, {len(plc):,} now). Evaluate again in the Evaluation program."})
        if entry.get("machines_without_plc"):
            notices.append({"kind": "warn", "text": "No PLC data is stored for: " + ", ".join(entry["machines_without_plc"][:8]) + " — their events can't be reviewed here."})
        conversions = [{"column": c, "mode": o.get("mode")} for c, o in (fs.get("feature_overrides") or {}).items()]
        params = entry.get("params") or {}
        evaluation = {"evaluated_at": entry.get("evaluated_at"), "counts": entry.get("counts"), "ground_truth": entry.get("ground_truth"),
                      "program_label": program_label(programs[pkey]),
                      "date_from": params.get("date_from"), "date_to": params.get("date_to")}
        if params.get("date_from") or params.get("date_to"):
            notices.append({"kind": "info", "text": "This fault was last evaluated for "
                            + (params.get("date_from") or "the start of the data") + " → " + (params.get("date_to") or "the latest data")
                            + " only, so only events in those dates are reviewed here. Evaluate it with all dates in the Evaluation program to review its full history."})

        if matched_tp.empty:
            return jsonify(ok=True, events=[], feature_columns=feature_columns, warnings=warnings, notices=notices, machines=[],
                            conversions=conversions, evaluation=evaluation,
                            note="No matched real events for this fault — nothing to review.")

        has_machine = bool(machine_col) and "machine" in matched_tp.columns and machine_col in plc.columns

        def _safe(s):
            return re.sub(r"[\"'\\<>|]", "", str(s))
        coming_strs = matched_tp["coming"].astype(str).tolist()
        machines_list = matched_tp["machine"].astype(str).tolist() if has_machine else [None] * len(coming_strs)
        keys = [(f"{_safe(mm)}|{cs}" if mm is not None else cs) for mm, cs in zip(machines_list, coming_strs)]
        machine_of = dict(zip(keys, machines_list))
        interval_idxs = matched_tp["matched_interval_idx"].astype(int).tolist()

        # drop events whose machine has no stored PLC rows any more
        present = [i for i, k in enumerate(keys) if machine_of[k] in plc_by_machine]
        if len(present) < len(keys):
            notices.append({"kind": "warn", "text": f"{len(keys) - len(present)} event(s) skipped: their machine has no stored PLC data."})
            keys = [keys[i] for i in present]
            interval_idxs = [interval_idxs[i] for i in present]
        if not keys:
            return jsonify(ok=True, events=[], feature_columns=feature_columns, warnings=warnings, notices=notices, machines=[],
                            conversions=conversions, evaluation=evaluation, note="No reviewable events.")

        # Snapshot at each event's matched predicted-interval start (not the historian's recorded time):
        # the two can differ by up to the match tolerance, and a pulsed I/O signal may already have reset.
        starts = [iv.iloc[i]["start"] for i in interval_idxs]
        ends = [iv.iloc[i]["end"] for i in interval_idxs]
        snapshot_time_by_key = dict(zip(keys, starts))
        interval_bounds_by_key = {k: (s, e) for k, s, e in zip(keys, starts, ends)}

        feature_rows = {}
        for mname in {machine_of[k] for k in keys}:  # each machine's readings come from that machine's own PLC rows
            ks = [k for k in keys if machine_of[k] == mname]
            feats = core.snapshot_features(plc_by_machine[mname], ts_col, [snapshot_time_by_key[k] for k in ks], feature_columns)
            feature_rows.update(dict(zip(ks, feats)))

        warnings += core.check_trigger_variance(feature_rows, feature_specs)

        clusters = fs.setdefault("clusters", [])
        assignment = core.cluster_events(feature_rows, feature_specs, clusters, machine_by_key=(machine_of if has_machine else None))
        fs["event_cluster_map"] = assignment
        rc_state_save(pkey, rc)

        cluster_by_id = {c["id"]: c for c in clusters}
        size_by_id, keys_by_cluster = {}, {}
        for k, cid in assignment.items():
            size_by_id[cid] = size_by_id.get(cid, 0) + 1
            keys_by_cluster.setdefault(cid, []).append(k)

        overrides = fs.get("event_overrides", {})
        known_descriptions = sorted({c["description"] for c in clusters if c.get("description")} | {d for d in overrides.values() if d})

        diagnostic_specs = [s for s in feature_specs if s.get("role", "diagnostic") != "trigger"]
        ewma_span = 10          # soft recency window; not sensitive enough to need tuning
        flicker_threshold = 2   # by definition: 1 rising edge = a clean latch, 2+ = not a clean latch
        flicker_window = max(max_gap, 2)
        jump_multiplier = 3.0   # Tukey's "extreme outlier" convention

        # exposure ("how often was the machine near this pattern at all") is counted on the cluster's own machine
        risk_by_cluster = {}
        if diagnostic_specs:
            for cid, cluster_keys in keys_by_cluster.items():
                cl = cluster_by_id[cid]
                plc_m = plc_by_machine.get(cl.get("machine"), plc)
                risk_by_cluster[cid] = core.compute_cluster_risk(
                    plc_m, ts_col, diagnostic_specs, cl["representative"], max_gap,
                    [snapshot_time_by_key[k] for k in cluster_keys], ewma_span)

        tot = {}  # "elevated" is judged against THIS machine's own baseline fault rate
        for cid, r in risk_by_cluster.items():
            if r:
                mk = cluster_by_id[cid].get("machine")
                f_, v_ = tot.get(mk, (0, 0))
                tot[mk] = (f_ + r["fault_count"], v_ + r["exposure_count"])
        baseline_by_machine = {mk: (f_ / v_ if v_ else 0.0) for mk, (f_, v_) in tot.items()}

        all_columns = sorted({s["column"] for s in feature_specs})
        column_kind = {c: ("digital" if core.is_digital_column(plc, c) else "analog") for c in all_columns}
        analog_cache = {}

        def analog_baseline(mname, col):
            if (mname, col) not in analog_cache:
                analog_cache[(mname, col)] = core.analog_jump_baseline(plc_by_machine[mname], col, jump_multiplier)
            return analog_cache[(mname, col)]

        description_by_key, duration_by_key = {}, {}
        for k in keys:
            cl = cluster_by_id[assignment[k]]
            description_by_key[k] = overrides.get(k) or (cl.get("description") or None)
            i_start, i_end = interval_bounds_by_key[k]
            duration_by_key[k] = (i_end - i_start).total_seconds()

        duration_points = [(duration_by_key[k], description_by_key[k]) for k in keys if description_by_key[k]]
        duration_threshold, duration_basis, best_conf = None, None, 0.0
        for desc in sorted({d for _, d in duration_points}):
            sug = core.suggest_threshold(duration_points, desc, min_samples=7)
            if sug and sug["confidence"] >= 0.8 and sug["confidence"] > best_conf:
                duration_threshold, best_conf = sug["threshold"], sug["confidence"]
                duration_basis = {"source": "engineer feedback", "confidence": sug["confidence"], "for_label": desc}
        if duration_threshold is None:
            guess = core.natural_split(list(duration_by_key.values()))
            if guess is not None:
                duration_threshold = guess
                duration_basis = {"source": "data pattern (no labels yet)", "confidence": None, "for_label": None}

        events = []
        for k in keys:
            mname = machine_of[k]
            plc_m = plc_by_machine[mname]
            where = f" on {mname}" if mname else ""
            cl = cluster_by_id[assignment[k]]
            group_description = cl.get("description") or None
            override = overrides.get(k)
            description = description_by_key[k]
            risk = risk_by_cluster.get(cl["id"])
            elevated_bar = max(baseline_by_machine.get(cl.get("machine"), 0.0) * 1.5, 0.15)
            flagged = bool(risk and risk["exposure_count"] >= 3
                           and risk["wilson_lower"] is not None and risk["wilson_lower"] >= elevated_bar
                           and risk["ewma_risk"] is not None and risk["ewma_risk"] >= elevated_bar)

            i_start, i_end = interval_bounds_by_key[k]
            win_start = i_start - pd.Timedelta(seconds=flicker_window)
            win_end = i_end + pd.Timedelta(seconds=flicker_window)

            sensor_issue = None  # the sensor check runs FIRST: a diagnosis built on a bad reading isn't trustworthy
            for col in all_columns:
                if column_kind[col] == "digital":
                    flick = core.compute_flicker_info(plc_m, ts_col, [col], win_start, win_end, flicker_threshold)
                    if flick["flicker"]:
                        sensor_issue = f'Check the sensor — "{col}"{where} is flickering rather than latching cleanly'
                        break
                else:
                    jump = core.check_analog_jump(plc_m, ts_col, col, win_start, win_end, analog_baseline(mname, col))
                    if jump["flagged"]:
                        sensor_issue = f'Check the sensor — "{col}"{where} jumped abnormally (Δ={jump["max_jump"]:.2f}, typical up to {jump["bound"]:.2f})'
                        break

            auto_suggestion = sensor_issue
            if auto_suggestion is None and not group_description:
                cluster_size = size_by_id[cl["id"]]
                is_short = duration_threshold is not None and duration_by_key[k] < duration_threshold
                is_recurring = cluster_size >= 2
                if flagged:
                    auto_suggestion = f"Likely an object/obstruction at this location{where} (recurred {cluster_size} times, statistically elevated)"
                elif is_recurring and is_short:
                    auto_suggestion = f"Brief but repeatable event at this location{where} — possibly a small structural issue, not a sensor fault (recurred {cluster_size} times, duration {duration_by_key[k]:.1f}s)"
                elif is_recurring and not is_short:
                    auto_suggestion = f"Recurring event at this location{where} (recurred {cluster_size} times) — worth checking, though not yet statistically elevated vs other locations"
                elif not is_recurring and is_short:
                    auto_suggestion = f"Brief, isolated occurrence{where}, not tied to a consistent location (duration {duration_by_key[k]:.1f}s) — possible sensor artifact"
                elif diagnostic_specs:
                    auto_suggestion = f"Sensor reads consistently{where} but at inconsistent locations — check the sensor"

            events.append({
                "key": k, "machine": mname, "features": feature_rows[k],
                "code": cl["code"], "cluster_id": cl["id"],
                "group_description": group_description, "description": description,
                "has_override": bool(override), "status": "labeled" if description else "unknown",
                "auto_suggestion": auto_suggestion, "sensor_issue": sensor_issue,
                "duration_seconds": duration_by_key[k], "cluster_size": size_by_id[cl["id"]],
                "risk": risk, "flagged": flagged,
            })
        events.sort(key=lambda e: (e["code"], e["key"]))

        threshold_suggestions = []  # auto-discover a cutoff from repeated manual labels, with a confidence %
        for col in [s["column"] for s in diagnostic_specs if s.get("mode") != "threshold"]:
            labeled_points = [(e["features"].get(col), e["description"]) for e in events if e["description"]]
            for desc in sorted({d for _, d in labeled_points}):
                sug = core.suggest_threshold(labeled_points, desc, min_samples=7)
                if sug and sug["confidence"] >= 0.8:
                    threshold_suggestions.append({"column": col, "description": desc, "threshold": sug["threshold"],
                                                  "direction": sug["direction"], "confidence": sug["confidence"],
                                                  "n": sug["n"], "n_target": sug["n_target"]})

        # tell the building dashboard once per evaluation if this review found something a person should look at
        if any(e["sensor_issue"] or e["flagged"] for e in events) and fs.get("issues_recorded_for") != entry.get("evaluated_at"):
            bs.record_issues(1)
            fs["issues_recorded_for"] = entry.get("evaluated_at")
            rc_state_save(pkey, rc)

        return jsonify(ok=True, events=events, feature_columns=feature_columns, known_descriptions=known_descriptions,
                        warnings=warnings, notices=notices, threshold_suggestions=threshold_suggestions,
                        duration_threshold=duration_threshold, duration_basis=duration_basis,
                        machines=sorted({e["machine"] for e in events if e["machine"]}),
                        conversions=conversions, evaluation=evaluation)
    except Exception as e:  # noqa: BLE001
        traceback.print_exc()
        return jsonify(ok=False, error=str(e)), 400


def _known_program(key):
    return key if key in {p["key"] for p in load_registry()["programs"]} else None


@app.route("/api/rc/label", methods=["POST"])
def api_rc_label():
    body = request.get_json(force=True)
    pkey = _known_program(body.get("program"))
    if not pkey:
        return jsonify(ok=False, error="Unknown terminal/type."), 400
    fault, key = body.get("fault", ""), body.get("key", "")
    scope = body.get("scope", "all")  # "all" = whole pattern group, "one" = just this occurrence
    description = (body.get("description") or "").strip()
    rc = rc_state_load(pkey)
    fs = rc["faults"].setdefault(fault, {})
    if body.get("clear"):
        fs.get("event_overrides", {}).pop(key, None)
        rc_state_save(pkey, rc)
        return jsonify(ok=True)
    if not description:
        return jsonify(ok=False, error="Description is required."), 400
    if scope == "one":
        fs.setdefault("event_overrides", {})[key] = description
        rc_state_save(pkey, rc)
        return jsonify(ok=True)
    cluster_id = body.get("cluster_id") or (fs.get("event_cluster_map") or {}).get(key)
    for cl in fs.get("clusters", []):
        if cl["id"] == cluster_id:
            cl["description"] = description
            rc_state_save(pkey, rc)
            return jsonify(ok=True)
    return jsonify(ok=False, error="Pattern group not found — reload the events and try again."), 400


@app.route("/api/rc/convert", methods=["POST"])
def api_rc_convert():
    """Turn a suggested cutoff into a threshold rule — applied here, in Root Causes only."""
    b = request.get_json(force=True)
    pkey = _known_program(b.get("program"))
    if not pkey:
        return jsonify(ok=False, error="Unknown terminal/type."), 400
    desc, thr = b["description"], float(b["threshold"])
    buckets = ([{"upper_bound": thr, "label": desc}, {"upper_bound": None, "label": "Other"}] if b["direction"] == "<"
               else [{"upper_bound": thr, "label": "Other"}, {"upper_bound": None, "label": desc}])
    rc = rc_state_load(pkey)
    rc["faults"].setdefault(b["fault"], {}).setdefault("feature_overrides", {})[b["column"]] = {"mode": "threshold", "buckets": buckets}
    rc_state_save(pkey, rc)
    return jsonify(ok=True)


@app.route("/api/rc/convert/reset", methods=["POST"])
def api_rc_convert_reset():
    b = request.get_json(force=True) or {}
    pkey = _known_program(b.get("program"))
    if not pkey:
        return jsonify(ok=False, error="Unknown terminal/type."), 400
    rc = rc_state_load(pkey)
    rc["faults"].setdefault(b.get("fault", ""), {}).pop("feature_overrides", None)
    rc_state_save(pkey, rc)
    return jsonify(ok=True)


INDEX_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FDD Root Cause Analysis</title>
<link rel="icon" href="/logo">
<style>/*THEME*/
/*FTA_CSS*/</style>
</head>
<body>
<header class="app-header">
  <span class="logo-wrap" id="logoWrap"><img id="logoImg" src="/logo" alt="Company logo" hidden><button class="small" id="logoAdd" type="button" hidden>Add logo</button><input type="file" id="logoFile" accept=".png,.jpg,.jpeg,.svg,.webp" hidden></span>
  <h1>FDD Root Cause Analysis</h1>
  <span class="status" id="liveStatus" role="status" aria-live="polite"><span class="dot dot-off"></span><span id="liveStatusText">Starting…</span></span>
  <nav class="tabs" aria-label="Section"><a href="#rc" id="tabRC" class="active" aria-current="page">Root Causes</a><a href="#fta" id="tabFTA">Fault Tree Analysis</a></nav>
</header>
<main id="viewRC">
  <div id="rcBanner"></div>
  <div class="layout">
    <div class="panel fault-list">
      <h2>Evaluated faults</h2>
      <input type="text" id="rcFaultSearch" placeholder="Search…" aria-label="Search faults">
      <div id="rcFaultListBox"></div>
      <div class="toolbar" style="margin:10px 0 0;"><button class="small" onclick="refreshFaults()">Refresh</button></div>
    </div>
    <div class="panel rule-panel" id="rcResultsPanel">
      <div class="hint" id="rcErr" style="margin:0;">Select a fault on the left.</div>
      <div id="rcNotices" style="margin-top:10px;"></div>
      <div id="rcWarnings"></div>
      <div id="rcInfo" class="hint" style="margin:0 0 10px;"></div>
      <div class="toolbar" id="rcToolbar" style="display:none;"><label class="hint" for="rcMachineFilter" style="margin:0;">Machine</label><select id="rcMachineFilter" style="width:auto;" onchange="applyFilter()"></select></div>
      <div style="overflow-x:auto;"><table id="rcTable" style="display:none;"><thead><tr id="rcTableHead"></tr></thead><tbody id="rcTableBody"></tbody></table></div>
    </div>
  </div>
</main>
<!--FTA_HTML-->

<script>
/*LOGOJS*/
function $(id){ return document.getElementById(id); }
function esc(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function setStatus(text, kind){
  const el = $('liveStatus');
  $('liveStatusText').textContent = text;
  el.className = 'status' + (kind==='err' ? ' err' : '');
  el.querySelector('.dot').className = 'dot dot-' + (kind||'ok');
}
const READY_TEXT = 'Ready — reads saved evaluations only, no PLC connection';
async function postJSON(url, body){
  setStatus('Working…','attn');
  try{
    const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
    const d = await r.json();
    if(d && d.ok===false && d.error) setStatus('⚠ '+d.error,'err'); else setStatus(READY_TEXT,'ok');
    return d;
  } catch(e){ setStatus('⚠ '+e.message,'err'); throw e; }
}

let faults = [], selectedFault = null, selectedProgram = null;

// ---------------------------------------------------------------- fault list
async function refreshFaults(){
  setStatus('Loading evaluations…','attn');
  let d;
  try{ d = await (await fetch('/api/faults')).json(); } catch(e){ setStatus('⚠ '+e.message,'err'); return; }
  faults = d.faults || [];
  if(!d.manifest_exists){
    $('rcBanner').innerHTML = d.eval_found
      ? `<div class="panel empty"><b>Nothing has been evaluated yet</b>Evaluate a fault in the Evaluation program (all machines). The results show up here after you press Refresh.</div>`
      : `<div class="panel empty"><b>Can’t find the Evaluation data</b>Looked in <code>${esc(d.eval_dir)}</code>. Open <code>rootcause_config.json</code> in this folder and set <code>evaluation_dir</code> to the Evaluation project’s folder, then restart.</div>`;
  } else {
    let html = '';
    if(d.not_ready_count) html += `<div class="notice info">${d.not_ready_count} evaluated fault(s) have no context columns yet — pick them in the Evaluation program (Logic tab) to review those faults here.</div>`;
    $('rcBanner').innerHTML = html;
  }
  renderFaultList();
  setStatus(READY_TEXT,'ok');
}
function renderFaultList(){
  const q = ($('rcFaultSearch').value||'').toLowerCase();
  let html = '', last = null;
  faults.forEach((f,i)=>{
    if(!(f.name+' '+f.program_label).toLowerCase().includes(q)) return;
    if(f.program !== last){ html += `<div class="group-title">${esc(f.program_label)}</div>`; last = f.program; }
    const active = f.name===selectedFault && f.program===selectedProgram;
    const badge = !f.ready ? 'no context' : (f.stale_logic ? 'stale' : '');
    html += `<div class="fault-item${active?' active':''}" style="${f.ready?'':'opacity:.55;'}" onclick="selectFault(${i})">${esc(f.name)}${badge?`<span class="badge">${badge}</span>`:''}</div>`;
  });
  $('rcFaultListBox').innerHTML = html || '<div class="hint" style="margin:0;">None yet.</div>';
}
$('rcFaultSearch').addEventListener('input', renderFaultList);
function selectFault(i){ selectedProgram = faults[i].program; selectedFault = faults[i].name; renderFaultList(); loadEvents(); }

// ---------------------------------------------------------------- events
async function loadEvents(){
  if(!selectedFault) return;
  $('rcErr').textContent = 'Loading…'; $('rcErr').className = 'hint'; $('rcErr').style.display = 'block';
  ['rcNotices','rcWarnings','rcInfo'].forEach(id=>$(id).innerHTML='');
  $('rcTable').style.display = 'none'; $('rcToolbar').style.display = 'none';
  const data = await postJSON('/api/rc/evaluate', {program: selectedProgram, fault: selectedFault});
  if(!data.ok){ $('rcErr').textContent = '⚠ '+data.error; $('rcErr').className = 'hint err'; return; }
  if(data.note){ $('rcErr').textContent = data.note; $('rcErr').className = 'hint'; } else { $('rcErr').style.display = 'none'; }

  const ev = data.evaluation || {};
  if(ev.evaluated_at){
    const c = ev.counts || {};
    const dates = (ev.date_from || ev.date_to) ? ` · dates ${esc(ev.date_from||'start')} → ${esc(ev.date_to||'latest')}` : '';
    $('rcInfo').innerHTML = `${esc(ev.program_label||'')} · Evaluated ${esc(new Date(ev.evaluated_at).toLocaleString())}${dates} · ${c.tp ?? '—'} of ${ev.ground_truth ?? '—'} real events matched by the rule`;
  }
  let n = (data.notices||[]).map(x=>`<div class="notice ${x.kind||'info'}">${esc(x.text)}</div>`).join('');
  if((data.conversions||[]).length){
    n += `<div class="notice info">Converted to a threshold rule here (Root Causes only): ${data.conversions.map(c=>esc(c.column)).join(', ')}.
      <button class="small" style="margin-left:8px;" onclick="resetConversions()">Reset</button></div>`;
  }
  $('rcNotices').innerHTML = n;

  let w = (data.warnings||[]).map(x=>`<div class="notice err">⚠ ${esc(x)}</div>`).join('');
  window._rcSuggestions = data.threshold_suggestions || [];
  w += window._rcSuggestions.map((s,i)=>`<div class="notice info">It looks like “${esc(s.description)}” occurs when <b>${esc(s.column)} ${esc(s.direction)} ${s.threshold.toFixed(2)}</b>
      — <b>${Math.round(s.confidence*100)}% confident</b>, based on ${s.n} labeled example(s).
      <button class="small" style="margin-left:8px;" onclick="convertToThreshold(${i})">Convert to threshold rule</button></div>`).join('');
  if(data.duration_basis){
    const b = data.duration_basis;
    const conf = b.confidence!=null ? ` (${Math.round(b.confidence*100)}% confident, based on your “${esc(b.for_label)}” labels)` : ' (preliminary — no labels yet, refines as you label occurrences)';
    w += `<div class="hint" style="margin:0 0 8px;">Short/long duration cutoff: <b>${data.duration_threshold.toFixed(1)}s</b> — source: ${esc(b.source)}${conf}</div>`;
  }
  $('rcWarnings').innerHTML = w;

  window._rcData = data;
  const ms = data.machines || [], sel = $('rcMachineFilter'), cur = sel.value;
  $('rcToolbar').style.display = ms.length > 1 ? 'flex' : 'none';
  sel.innerHTML = '<option value="">All machines</option>' + ms.map(m=>`<option>${esc(m)}</option>`).join('');
  if(ms.includes(cur)) sel.value = cur;
  applyFilter();
}
function applyFilter(){
  const d = window._rcData, m = $('rcMachineFilter').value;
  renderTable(m ? {...d, events: d.events.filter(e=>e.machine===m)} : d);
}
async function convertToThreshold(i){
  const s = window._rcSuggestions[i];
  await postJSON('/api/rc/convert', {program: selectedProgram, fault: selectedFault, column: s.column, threshold: s.threshold, direction: s.direction, description: s.description});
  loadEvents();
}
async function resetConversions(){
  await postJSON('/api/rc/convert/reset', {program: selectedProgram, fault: selectedFault});
  loadEvents();
}

// show readings to at most 2 decimals so long floats don't squeeze the table
function fmt(v){ return (typeof v === 'number' && !Number.isInteger(v)) ? String(+v.toFixed(2)) : v; }

function renderTable(data){
  window._rcEvents = data.events;
  window._rcKnown = data.known_descriptions || [];
  if(!data.events.length){ $('rcTable').style.display = 'none'; return; }
  $('rcTable').style.display = 'table';
  const feats = data.feature_columns, hasM = data.events.some(e=>e.machine);
  $('rcTableHead').innerHTML = `<th>Event time</th>${hasM?'<th>Machine</th>':''}${feats.map(f=>`<th>${esc(f)}</th>`).join('')}<th>Description</th><th></th>`;

  const groups = [], byCode = {};
  data.events.forEach((ev,i)=>{
    ev._i = i;
    if(!byCode[ev.code]){ byCode[ev.code] = {code:ev.code, size:ev.cluster_size, desc:ev.group_description, risk:ev.risk, flagged:ev.flagged, machine:ev.machine, rows:[]}; groups.push(byCode[ev.code]); }
    byCode[ev.code].rows.push(ev);
  });
  const unknown = '<span class="hint" style="margin:0;">Unknown</span>';
  $('rcTableBody').innerHTML = groups.map(g=>{
    const riskInfo = g.risk && g.risk.exposure_count
      ? `<span class="hint" style="margin:0;">${g.risk.fault_count}/${g.risk.exposure_count} visits faulted, recent rate ${(g.risk.ewma_risk*100).toFixed(0)}%</span>` : '';
    const flag = g.flagged ? ` <span class="pill" style="background:var(--tint-danger); color:var(--danger);">⚠ Recurring — worth checking</span>` : '';
    const parent = `<tr style="background:var(--s2);">
      <td colspan="${1+(hasM?1:0)}"><b>${esc(g.code)}</b>${g.machine?` <span class="hint" style="margin:0;">· ${esc(g.machine)}</span>`:''}${flag}<br>${riskInfo}</td>
      ${feats.map(()=>'<td></td>').join('')}
      <td class="desc">${g.desc ? esc(g.desc) : unknown}</td>
      <td class="act"><button class="small" onclick="openLabelForm('all','${esc(g.code)}')">Name group (${g.size})</button></td></tr>`;
    const kids = g.rows.map(ev=>{
      const when = ev.key.includes('|') ? ev.key.split('|').slice(1).join('|') : ev.key;
      const desc = ev.description
        ? `${esc(ev.description)}${ev.has_override ? ' <span class="hint" style="margin:0;">(custom)</span>' : ''}`
        : (ev.sensor_issue ? `<span class="hint err" style="margin:0;">⚠ ${esc(ev.sensor_issue)}</span>`
           : (ev.auto_suggestion ? `<span class="hint" style="margin:0;">Suggested: ${esc(ev.auto_suggestion)}</span>` : unknown));
      return `<tr><td class="nowrap" style="padding-left:12px;">${esc(when)}</td>${hasM?`<td>${esc(ev.machine||'')}</td>`:''}
        ${feats.map(f=>`<td>${ev.features[f]!=null ? esc(fmt(ev.features[f])) : '—'}</td>`).join('')}
        <td class="desc">${desc}</td>
        <td class="act"><button class="small" onclick="openLabelForm('one',${ev._i})">${ev.has_override?'Edit':'Name this one'}</button></td></tr>`;
    }).join('');
    return parent + kids;
  }).join('');
}

// ---------------------------------------------------------------- naming a group / one occurrence
function openLabelForm(scope, ref){
  const isAll = scope === 'all';
  const ev = isAll ? window._rcEvents.find(e=>e.code===ref) : window._rcEvents[ref];
  const known = (window._rcKnown||[]).map(d=>`<option value="${esc(d)}">${esc(d)}</option>`).join('');
  const prefill = (!isAll && ev.has_override) ? ev.description : (ev.sensor_issue || ev.auto_suggestion || '');
  const hint = isAll
    ? `Applies to all ${ev.cluster_size} occurrence(s) of this pattern${ev.machine?` on ${esc(ev.machine)}`:''}, including future matches — except any single occurrence you've already given its own description.`
    : `Applies only to this one occurrence${ev.machine?` (${esc(ev.machine)})`:''}. The rest of the group keeps its current description.`;
  const clear = (!isAll && ev.has_override) ? `<button id="rcClearBtn">Clear custom description</button>` : '';
  document.body.insertAdjacentHTML('beforeend', `
    <div style="position:fixed; inset:0; background:rgba(0,0,0,.5); display:flex; align-items:center; justify-content:center; z-index:50;" id="rcModal" role="dialog" aria-modal="true">
      <div class="panel" style="width:460px; max-width:94vw; margin:0;">
        <h2>${esc(ev.code)}${isAll?'':' — single occurrence'}</h2>
        <div class="hint" style="margin:0 0 12px;">${hint}</div>
        <div class="field"><label for="rcDescSelect">Pick a known root cause</label>
          <select id="rcDescSelect"><option value="">— or type a new one below —</option>${known}</select></div>
        <div class="field" style="margin-top:10px;"><label for="rcDesc">Or new description</label>
          <input type="text" id="rcDesc" placeholder="Describe the root cause" value="${esc(prefill)}"></div>
        <div class="toolbar" style="margin:16px 0 0;">
          <button class="primary" id="rcSaveBtn">Save</button>
          <button onclick="document.getElementById('rcModal').remove()">Cancel</button>${clear}
        </div>
      </div>
    </div>`);
  $('rcDesc').focus();
  $('rcDescSelect').addEventListener('change', e=>{ if(e.target.value) $('rcDesc').value = e.target.value; });
  if($('rcClearBtn')) $('rcClearBtn').addEventListener('click', async ()=>{
    const r = await postJSON('/api/rc/label', {program:selectedProgram, fault:selectedFault, key:ev.key, clear:true});
    $('rcModal').remove(); if(r.ok) loadEvents();
  });
  $('rcSaveBtn').addEventListener('click', async ()=>{
    const description = $('rcDesc').value.trim();
    if(!description){ $('rcDesc').focus(); return; }
    const r = await postJSON('/api/rc/label', {program:selectedProgram, fault:selectedFault, key: isAll ? '' : ev.key, description, scope, cluster_id: ev.cluster_id});
    $('rcModal').remove(); if(r.ok) loadEvents();
  });
}

/*FTA_JS*/
refreshFaults();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    run_server(app, PORT_ROOT_CAUSE, "FDD Root Cause Analysis")
