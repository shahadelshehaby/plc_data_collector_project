"""THE THEME — the only place colours, fonts, sizes and radii are defined.

Both programs (Rule Builder on port 5120, Root Causes on port 5001) inject THEME_CSS into
their pages, so editing the variables in :root below restyles both at once.
"""
THEME_CSS = r'''
  /* =====================================================================
     THEME — "Engineering Building" design system.
     Every colour, size and radius used by the platform comes from the
     variables in this one block. Change the look here, nowhere else.
     ===================================================================== */
  :root{
    color-scheme: light dark;
    /* palette */
    --text:#2C2C2A; --text2:#5F5E5A; --page:#FFFFFF; --s1:#F1EFE8; --s2:#E7E5DE; --border:#D3D1C7;
    --accent:#185FA5; --on-accent:#FFFFFF;
    --success:#3B6D11; --warn:#854F0B; --danger:#A32D2D;
    /* status dots */
    --dot-ok:#639922; --dot-attn:#EF9F27; --dot-err:#E24B4A; --dot-off:#B4B2A9;
    /* chart colours */
    --chart-blue:#378ADD; --chart-teal:#5DCAA5; --chart-amber:#EF9F27; --chart-red:#E24B4A;
    /* light tinted backgrounds for pills and notices */
    --tint-accent:#E6F1FB; --on-tint-accent:#0C447C;
    --tint-success:#EAF3DE; --tint-warn:#FAEEDA; --tint-danger:#FCEBEB;
    /* type */
    --sans:"Segoe UI",system-ui,-apple-system,sans-serif;
    --mono:Consolas,"Cascadia Mono",monospace;
    /* shape */
    --radius-card:10px; --radius-ctl:6px; --radius-seg:8px; --gap:14px;
    /* older inline styles in the scripts refer to these names — kept as aliases */
    --bg:var(--page); --panel:var(--s1); --panel2:var(--s2); --line:var(--border);
    --text-dim:var(--text2); --text-faint:var(--text2);
    --red:var(--danger); --red-dim:var(--tint-danger); --green:var(--success); --green-dim:var(--tint-success);
    --amber:var(--warn); --amber-dim:var(--tint-warn); --blue:var(--accent); --blue-dim:var(--tint-accent);
  }
  @media (prefers-color-scheme: dark){
    :root{
      --text:#F1EFE8; --text2:#B4B2A9; --page:#1E1E1C; --s1:#2C2C2A; --s2:#3A3A37; --border:#444441;
      --accent:#85B7EB; --on-accent:#1E1E1C;
      --success:#97C459; --warn:#FAC775; --danger:#F09595;
      --tint-accent:#1F3347; --on-tint-accent:#85B7EB;
      --tint-success:#2A3321; --tint-warn:#3A3121; --tint-danger:#3D2626;
    }
  }

  /* ---------- base ---------- */
  *{box-sizing:border-box;}
  body{margin:0; background:var(--page); color:var(--text); font-family:var(--sans); font-size:15px; line-height:1.45;}
  h1,h2,h3{margin:0;}
  a{color:var(--accent);}
  main{max-width:1100px; margin:0 auto; padding:20px;}
  .tabpage{display:none;}
  .tabpage.active{display:block;}
  .muted{color:var(--text2);}

  /* ---------- header: logo | title | live status ........ segmented tabs ---------- */
  .app-header{max-width:1100px; margin:0 auto; padding:20px 20px 0; display:flex; align-items:center; gap:14px; flex-wrap:wrap;}
  .logo-wrap{display:flex; align-items:center; height:64px;}
  .logo-wrap img{height:64px; width:auto; display:block;}
  @media (prefers-color-scheme: dark){
    .logo-wrap.has-logo{background:#FFFFFF; border-radius:var(--radius-ctl); padding:3px; height:70px;}
  }
  .app-header h1{font-size:22px; font-weight:600;}
  .status{display:flex; align-items:center; gap:6px; font-size:13px; color:var(--text2); min-width:0;}
  .status.err{color:var(--danger);}
  .dot{width:8px; height:8px; border-radius:50%; background:var(--dot-off); flex:none;}
  .dot-ok{background:var(--dot-ok);} .dot-attn{background:var(--dot-attn);} .dot-err{background:var(--dot-err);} .dot-off{background:var(--dot-off);}
  .tabs{margin-left:auto; display:flex; gap:2px; padding:4px; background:var(--s1); border-radius:var(--radius-seg);}
  .tabs button{border:0; background:transparent; padding:6px 12px; border-radius:6px; font-weight:400; color:var(--text);}
  .tabs button:hover:not(.active){background:var(--s2);}
  .tabs button.active{background:var(--page); font-weight:600;}

  /* sub-navigation inside a page: underline tabs */
  .subtabs{display:flex; gap:18px; border-bottom:1px solid var(--border); margin-bottom:var(--gap);}
  .subtabs button{border:0; border-bottom:2px solid transparent; border-radius:0; background:none; padding:8px 2px; color:var(--text2);}
  .subtabs button:hover:not(.active){background:none; color:var(--text);}
  .subtabs button.active{border-bottom-color:var(--accent); color:var(--text); font-weight:600;}

  /* ---------- cards ---------- */
  .panel{background:var(--s1); border-radius:var(--radius-card); padding:16px 20px; margin-bottom:var(--gap);}
  .panel h2{font-size:16px; font-weight:600; margin:0 0 12px;}

  /* ---------- buttons ---------- */
  button{font:inherit; font-size:14px; padding:7px 14px; border-radius:var(--radius-ctl); border:1px solid var(--border);
         background:var(--page); color:var(--text); cursor:pointer;}
  button:hover:not(:disabled){background:var(--s1);}
  .panel button:hover:not(:disabled){background:var(--s2);}
  button.primary{background:var(--accent); border-color:var(--accent); color:var(--on-accent);}
  .panel button.primary:hover:not(:disabled), button.primary:hover:not(:disabled){background:var(--accent); filter:brightness(1.1);}
  button.small{padding:4px 10px; font-size:13px;}
  button.danger{color:var(--danger); border-color:var(--danger);}
  .panel button.danger:hover:not(:disabled), button.danger:hover:not(:disabled){background:var(--tint-danger);}
  button:disabled{opacity:.5; cursor:not-allowed;}

  /* ---------- inputs ---------- */
  select, input[type=text], input[type=number], input[type=date], input[type=password]{
    width:100%; font:inherit; font-size:14px; padding:7px 9px; color:var(--text);
    background:var(--page); border:1px solid var(--border); border-radius:var(--radius-ctl);
  }
  input[type=checkbox]{accent-color:var(--accent);}
  ::placeholder{color:var(--text2); opacity:.8;}

  /* visible keyboard focus everywhere */
  button:focus-visible, input:focus-visible, select:focus-visible, textarea:focus-visible, a:focus-visible{
    outline:2px solid var(--accent); outline-offset:1px;
  }

  /* ---------- forms: label 220px | field, 12px helper text under the field ---------- */
  .form-row{display:grid; grid-template-columns:220px minmax(0,1fr); gap:4px 16px; align-items:start; padding:8px 0;}
  .form-row > label{font-size:13px; color:var(--text2); padding-top:8px;}
  .form-row select, .form-row input[type=text], .form-row input[type=number], .form-row input[type=password], .form-row input[type=date]{max-width:440px;}
  .helper{font-size:12px; color:var(--text2); margin-top:4px; line-height:1.45;}
  .field{flex:1; min-width:200px;}
  .field label{display:block; font-size:13px; color:var(--text2); margin-bottom:4px;}
  .row{display:flex; gap:16px; flex-wrap:wrap;}
  .checklist{max-height:180px; overflow-y:auto; background:var(--page); border:1px solid var(--border); border-radius:var(--radius-ctl);
             padding:10px 12px; display:grid; grid-template-columns:repeat(auto-fill,minmax(170px,1fr)); gap:4px;}
  .file-row{display:flex; gap:8px; align-items:center; margin-bottom:6px;}
  .file-row input[type=text]{flex:1;}

  /* ---------- hints, messages ---------- */
  .hint{font-size:13px; color:var(--text2); margin-top:8px; line-height:1.5;}
  .hint.err, .err{color:var(--danger);}
  .hint.ok, .ok{color:var(--success);}
  .hint.warn, .warn{color:var(--warn);}
  .toolbar{display:flex; gap:10px; align-items:center; margin-bottom:var(--gap); flex-wrap:wrap;}

  /* ---------- sticky save bar (Settings, Logic) ---------- */
  .savebar{position:sticky; bottom:0; z-index:5; display:flex; align-items:center; gap:14px; margin-top:var(--gap);
           padding:12px 0; background:var(--page); border-top:1px solid var(--border);}
  .panel .savebar{background:var(--s1);}
  .savebar .hint{margin:0;}

  /* ---------- tables ---------- */
  table{width:100%; border-collapse:collapse; font-size:14px;}
  th{text-align:left; padding:8px 10px; font-size:12px; font-weight:600; color:var(--text2); border-bottom:1px solid var(--border); white-space:nowrap;}
  td{padding:8px 10px; border-bottom:1px solid var(--border); vertical-align:top;}
  tr.clickable{cursor:pointer;}
  tr.clickable:hover{background:var(--s2);}

  /* ---------- key figures ---------- */
  .cards{display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:var(--gap); margin:12px 0;}
  .card{background:none; border:0; padding:0;}
  .card .v{font-size:26px; font-weight:600; line-height:1.2;}
  .card .l{font-size:13px; color:var(--text2); margin-top:2px;}
  .card.tp .v{color:var(--success);} .card.fp .v{color:var(--danger);} .card.fn .v{color:var(--warn);}

  /* ---------- pills / tags ---------- */
  .pill{display:inline-block; padding:2px 9px; border-radius:10px; font-size:12px; line-height:1.5; background:var(--tint-accent); color:var(--on-tint-accent);}
  .pill.matched{background:var(--tint-success); color:var(--success);}
  .pill.missed{background:var(--tint-warn); color:var(--warn);}
  .pill.nodata{background:var(--s2); color:var(--text2);}

  /* ---------- two/three-column page layouts, fault lists ---------- */
  .layout{display:flex; gap:var(--gap); align-items:flex-start;}
  .fault-list{width:230px; flex-shrink:0;}
  .fault-list input{margin-bottom:10px;}
  .rule-panel{flex:1; min-width:0; overflow-x:auto;}
  .fault-item{padding:7px 10px; border-radius:var(--radius-ctl); cursor:pointer; font-size:14px; margin-bottom:2px; display:flex; justify-content:space-between; align-items:baseline; gap:8px;}
  .fault-item:hover{background:var(--s2);}
  .fault-item.active{background:var(--tint-accent); color:var(--on-tint-accent); font-weight:600;}
  .fault-item .badge{font-size:12px; color:var(--text2); font-weight:400; white-space:nowrap;}
  @media (max-width:860px){ .layout{flex-direction:column;} .fault-list{width:100%;} .form-row{grid-template-columns:1fr;} .form-row > label{padding-top:0;} }

  /* ---------- rule editor ---------- */
  .cond-row{display:flex; gap:8px; align-items:center; margin-bottom:8px; flex-wrap:wrap;}
  .cond-row select{width:auto; flex:1 1 100px; min-width:90px;}
  .cond-row input[type=number]{width:90px; flex:0 0 90px;}
  .version-card{background:var(--page); border:1px solid var(--border); border-radius:var(--radius-ctl); padding:14px 16px; margin-bottom:12px;}
  .version-card .vh{display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;}
  .version-card .vh b{font-size:14px;}
  mono, code{font-family:var(--mono);}

  /* ---------- additions used by both programs ---------- */
  .tabs a{padding:6px 12px; border-radius:6px; color:var(--text); text-decoration:none; line-height:1.45; white-space:nowrap;}
  .tabs a:hover{background:var(--s2);}
  .tabs a.active{background:var(--page); font-weight:600;}
  button{white-space:nowrap;}
  td.nowrap{white-space:nowrap;}
  .notice{border-radius:var(--radius-ctl); padding:8px 12px; margin-bottom:8px; font-size:13px; line-height:1.5;}
  .notice.err{background:var(--tint-danger); color:var(--danger);}
  .notice.warn{background:var(--tint-warn); color:var(--warn);}
  .notice.info{background:var(--tint-accent); color:var(--on-tint-accent);}
  .empty{text-align:center; padding:28px 12px; color:var(--text2);}
  td.desc{min-width:180px;}
  td.act{width:1%; white-space:nowrap;}
  .empty b{display:block; font-size:16px; color:var(--text); margin-bottom:4px;}

  [hidden]{display:none !important;}

  /* ---------- terminal / type bar, scope pickers, dialogs ---------- */
  .progbar{display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin-bottom:var(--gap); padding:10px 16px; background:var(--s1); border-radius:var(--radius-card);}
  .progbar label{font-size:13px; color:var(--text2);}
  .progbar select{width:auto; min-width:90px;}
  .chips{display:flex; flex-wrap:wrap; gap:6px;}
  .chip{display:inline-flex; align-items:center; gap:6px; padding:3px 10px; border-radius:10px; font-size:13px; background:var(--page); border:1px solid var(--border); cursor:pointer;}
  .chip input{margin:0;}
  .scope-row{display:grid; grid-template-columns:110px minmax(0,1fr); gap:6px 16px; padding:8px 0; align-items:start;}
  .scope-row > label{font-size:13px; color:var(--text2); padding-top:3px;}
  .group-title{font-size:12px; font-weight:600; color:var(--text2); margin:12px 0 4px;}
  .group-title:first-child{margin-top:0;}
  .modal-bg{position:fixed; inset:0; background:rgba(0,0,0,.5); display:flex; align-items:center; justify-content:center; z-index:50;}
  .modal-card{width:460px; max-width:94vw; margin:0;}
  .logo-wrap button{white-space:nowrap;}
  @media (max-width:860px){ .scope-row{grid-template-columns:1fr;} }
'''
