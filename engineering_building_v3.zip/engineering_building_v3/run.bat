@echo off
cd /d "%~dp0"
REM Prefer the Python launcher (py.exe) - picks your newest installed Python.
where py >nul 2>nul
if %errorlevel%==0 (
    py run.py
) else (
    python run.py
)
pause
