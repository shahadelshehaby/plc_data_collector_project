"""
results_api.py
===============
JSON endpoints for the analysis tabs (Cases, Performance, Pickups, Energy,
Data quality). They read results_store.py only, so they answer instantly
for any date range and crane. Charts for one case or one move are drawn
on request from the per-file cache.

Every endpoint takes the same filters as query parameters:
  date_from, date_to   YYYY-MM-DD (both optional)
  lanes                comma-separated lane letters (optional)
  machines             comma-separated crane names (optional)
"""
import csv
import io
import json
import threading
from collections import OrderedDict

from flask import Blueprint, jsonify, request, abort, Response

from rules import set_lane_rule
from utils import lane_of

bp = Blueprint("results", __name__)
_get_library = None
_chart_lock = threading.Lock()   # matplotlib is not thread-safe

PERF_GROUPS = OrderedDict([
    ("speed", ("Slower than expected", "perf='issue'")),
    ("aborted", ("Aborted", "perf='aborted'")),
    ("no_movement", ("No movement", "perf='no_movement'")),
    ("sequence", ("Step sequence abnormal", "seq_abnormal=1")),
    ("reference", ("Did not reach its reference", "reached_ref=0")),
    ("ok", ("No issue", "perf='perfect' AND COALESCE(seq_abnormal,0)=0 AND COALESCE(reached_ref,1)=1")),
])
PICKUP_VERDICTS = ("necessary", "unnecessary", "unknown")


def register(app, get_library):
    global _get_library
    _get_library = get_library
    app.register_blueprint(bp)


# ----------------------------------------------------------------- helpers
def _lib():
    return _get_library()


def _store():
    return _lib().results


def _apply_lane_rule():
    lib = _lib()
    try:
        profile = lib.store.load_app_settings()["active_profile"]
        set_lane_rule(lib.store.load_profile_config(profile).rules)
    except Exception:  # noqa: BLE001 - a broken profile must not break the tabs
        pass


def _filters():
    """Query parameters -> store filter dict (lanes resolved to cranes)."""
    a = request.args
    flt = {"date_from": (a.get("date_from") or "")[:10] or None,
           "date_to": (a.get("date_to") or "")[:10] or None}
    lanes = {x.strip().upper() for x in (a.get("lanes") or "").split(",") if x.strip()}
    machines = {x.strip() for x in (a.get("machines") or "").split(",") if x.strip()}
    if lanes or machines:
        _apply_lane_rule()
        known = {r["machine"] for r in _store().machines_and_dates()}
        chosen = known
        if lanes:
            chosen = {m for m in chosen if lane_of(m).upper() in lanes}
        if machines:
            chosen = chosen & machines
        flt["machines"] = sorted(chosen)
    return flt


def _int(name, default, lo=0, hi=100000):
    try:
        return max(lo, min(hi, int(request.args.get(name, default))))
    except (TypeError, ValueError):
        return default


def _csv(rows, columns, filename):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([c[1] for c in columns])
    for r in rows:
        w.writerow([r.get(c[0]) if not isinstance(r.get(c[0]), (list, dict)) else json.dumps(r.get(c[0]))
                    for c in columns])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


def _wants_csv():
    return request.args.get("format") == "csv"


# --------------------------------------------------------------- endpoints
@bp.get("/api/results/meta")
def meta():
    """Cranes, lanes and dates that have results, plus a revision number
    that changes whenever results change (the tabs refresh on it)."""
    _apply_lane_rule()
    lib = _lib()
    machines = {}
    for r in _store().machines_and_dates():
        machines.setdefault(r["machine"], set()).add(r["date"])
    dates = sorted({d for ds in machines.values() for d in ds})
    waiting = sum(1 for f in lib.files.values() if f["status"] in ("pending", "analyzing"))
    not_analysed = sum(1 for f in lib.files.values() if f["status"] in ("new", "outdated")
                       or (f["status"] == "ready" and f.get("key") != lib.settings_key(
                           lib.store.load_app_settings()["active_profile"])))
    return jsonify({
        "revision": _store().revision,
        "machines": [{"machine": m, "lane": lane_of(m), "dates": sorted(ds)} for m, ds in sorted(machines.items())],
        "lanes": sorted({lane_of(m) for m in machines}),
        "dates": dates, "date_min": dates[0] if dates else None, "date_max": dates[-1] if dates else None,
        "waiting": waiting, "not_analysed": not_analysed, "busy": lib.busy,
    })


@bp.get("/api/results/cases")
def cases():
    flt = _filters()
    outcome = request.args.get("outcome") or None
    sort = request.args.get("sort") or "time"
    desc = request.args.get("dir", "desc") != "asc"
    if _wants_csv():
        data = _store().cases(flt, outcome, sort, desc, limit=1000000)
        return _csv(data["rows"], [("machine", "Crane"), ("date", "Date"), ("t_start", "Start"), ("t_end", "End"),
                                   ("outcome", "Outcome"), ("n_moves", "Moves"), ("n_unnecessary", "Unnecessary"),
                                   ("n_necessary", "Necessary"), ("n_unknown", "Unknown"), ("closed", "Closed"),
                                   ("duration_s", "Time (s)"), ("wasted_s", "Wasted time (s)"),
                                   ("distance_m", "Distance (m)"), ("energy_kwh", "Energy (kWh)"),
                                   ("wasted_kwh", "Wasted energy (kWh)"), ("workorders", "Workorders")],
                    "cases.csv")
    return jsonify(_store().cases(flt, outcome, sort, desc, _int("limit", 100, 1, 1000), _int("offset", 0)))


@bp.get("/api/results/case")
def case_detail():
    c = _store().case(request.args.get("id", ""))
    if c is None:
        abort(404)
    return jsonify(c)


@bp.get("/api/results/case.png")
def case_chart():
    c = _store().case(request.args.get("id", ""))
    if c is None:
        abort(404)
    moves = _lib().result_objects(c["events"])
    if not moves:
        abort(404)
    from operation_agent import OperationCase
    from operation_chart import build_case_illustration
    with _chart_lock:
        img = build_case_illustration(OperationCase(case_num=c.get("case_num") or 1, machine=c["machine"], moves=moves))
    if img is None:
        abort(404)
    return Response(img.png_bytes, mimetype="image/png", headers={"Cache-Control": "no-store"})


@bp.get("/api/results/move.png")
def move_chart():
    eid = request.args.get("id", "")
    rows = _store()._rows("SELECT * FROM events WHERE eid=?", (eid,))
    if not rows or rows[0]["kind"] != "reposition":
        abort(404)
    objs = _lib().result_objects(rows)
    if not objs:
        abort(404)
    from performance_chart import build_speed_chart
    with _chart_lock:
        img = build_speed_chart(objs[0].performance, objs[0].sequence.dominant_axis)
    if img is None:
        abort(404)
    return Response(img.png_bytes, mimetype="image/png", headers={"Cache-Control": "no-store"})


@bp.get("/api/results/performance")
def performance():
    flt = _filters()
    st = _store()
    select = ", ".join(f"SUM(CASE WHEN {cond} THEN 1 ELSE 0 END) AS {key}"
                       for key, (_, cond) in PERF_GROUPS.items())
    select += ", COUNT(*) AS moves, AVG(actual_s) AS avg_actual_s, AVG(expected_s) AS avg_expected_s"
    by_machine = st.summary(flt, select, "machine", kind="reposition")
    totals = st.summary(flt, select, "'all'", kind="reposition")
    issue = request.args.get("issue") or "issues"
    if issue in PERF_GROUPS:
        cond = PERF_GROUPS[issue][1]
    else:  # every move with any issue
        cond = "NOT (" + PERF_GROUPS["ok"][1] + ")"
    if _wants_csv():
        _, rows = st.events(flt, "reposition", cond, limit=1000000)
        return _csv(rows, _MOVE_COLUMNS, "performance.csv")
    n, rows = st.events(flt, "reposition", cond, limit=_int("limit", 100, 1, 1000), offset=_int("offset", 0))
    return jsonify({"groups": [{"key": k, "label": v[0]} for k, v in PERF_GROUPS.items()],
                    "totals": totals[0] if totals else {}, "by_machine": by_machine, "count": n, "rows": rows})


_MOVE_COLUMNS = [("machine", "Crane"), ("date", "Date"), ("t_start", "Start"), ("t_end", "End"),
                 ("workorder", "Workorder"), ("kind", "Job"), ("verdict", "Necessity"), ("axis", "Axis"),
                 ("distance_m", "Distance (m)"), ("duration_s", "Time (s)"), ("expected_s", "Expected (s)"),
                 ("actual_s", "Actual (s)"), ("perf", "Performance"), ("perf_msg", "Performance note"),
                 ("seq_abnormal", "Sequence abnormal"), ("seq_steps", "Steps"), ("energy_kwh", "Energy (kWh)"),
                 ("reason", "Reason")]


@bp.get("/api/results/pickups")
def pickups():
    flt = _filters()
    st = _store()
    select = ("COUNT(*) AS jobs, SUM(verdict='necessary') AS necessary, SUM(verdict='unnecessary') AS unnecessary, "
              "SUM(verdict='unknown') AS unknown, SUM(has_setdown=1) AS with_setdown, "
              "SUM(CASE WHEN waste=1 THEN duration_s ELSE 0 END) AS wasted_s, SUM(wasted_kwh) AS wasted_kwh")
    by_machine = st.summary(flt, select, "machine", kind="pickup")
    totals = st.summary(flt, select, "'all'", kind="pickup")
    verdict = request.args.get("verdict")
    cond, args = ("verdict=?", (verdict,)) if verdict in PICKUP_VERDICTS else ("1", ())
    if _wants_csv():
        _, rows = st.events(flt, "pickup", cond, args, limit=1000000)
        return _csv(rows, _MOVE_COLUMNS[:10] + [("has_setdown", "Set down"), ("energy_kwh", "Energy (kWh)"),
                                                ("reason", "Reason")], "pickups.csv")
    n, rows = st.events(flt, "pickup", cond, args, limit=_int("limit", 100, 1, 1000), offset=_int("offset", 0))
    return jsonify({"totals": totals[0] if totals else {}, "by_machine": by_machine, "count": n, "rows": rows})


@bp.get("/api/results/energy")
def energy():
    flt = _filters()
    group = request.args.get("group") or "date"
    select = ("COUNT(*) AS jobs, SUM(energy_kwh) AS counted_kwh, SUM(used_kwh) AS used_kwh, "
              "SUM(fed_kwh) AS fed_kwh, SUM(wasted_kwh) AS wasted_kwh, "
              "SUM(CASE WHEN kind='reposition' THEN energy_kwh ELSE 0 END) AS reposition_kwh, "
              "SUM(CASE WHEN kind='pickup' THEN energy_kwh ELSE 0 END) AS pickup_kwh")
    st = _store()
    totals = st.summary(flt, select, "'all'")
    if group == "lane":
        _apply_lane_rule()
        lanes = OrderedDict()
        for r in st.summary(flt, select, "machine"):
            lane = lane_of(r["grp"])
            acc = lanes.setdefault(lane, {"grp": lane})
            for k, v in r.items():
                if k != "grp":
                    acc[k] = (acc.get(k) or 0) + (v or 0)
        rows = [lanes[k] for k in sorted(lanes)]
    else:
        rows = st.summary(flt, select, "machine" if group == "machine" else "date")
    for r in rows + totals:
        r["net_kwh"] = (r.get("used_kwh") or 0) - (r.get("fed_kwh") or 0)
    if _wants_csv():
        return _csv(rows, [("grp", group.title()), ("jobs", "Jobs"), ("used_kwh", "Used (kWh)"),
                           ("fed_kwh", "Fed back (kWh)"), ("net_kwh", "Net (kWh)"), ("counted_kwh", "Counted (kWh)"),
                           ("wasted_kwh", "Wasted (kWh)"), ("reposition_kwh", "Repositions (kWh)"),
                           ("pickup_kwh", "Pickups/setdowns (kWh)")], f"energy_by_{group}.csv")
    cost = None
    try:
        lib = _lib()
        profile = lib.store.load_app_settings()["active_profile"]
        cfg = lib.store.load_profile_config(profile)
        cost = {"per_kwh": getattr(cfg.power, "cost_per_kwh", None), "currency": getattr(cfg.power, "currency", "")}
        basis = getattr(getattr(cfg, "energy", None), "basis", None)
    except Exception:  # noqa: BLE001
        basis = None
    return jsonify({"group": group, "rows": rows, "totals": totals[0] if totals else {}, "cost": cost,
                    "basis": basis})


@bp.get("/api/results/quality")
def quality():
    rows = _store().quality(_filters())
    if _wants_csv():
        return _csv(rows, [("machine", "Crane"), ("name", "File"), ("first", "From"), ("last", "To"),
                           ("rows", "Rows"), ("repeated", "Repeated seconds"), ("blip_count", "Job id blips"),
                           ("gaps", "Gaps > 5 s"), ("gap_seconds", "Missing seconds"),
                           ("longest_gap", "Longest gap (s)"), ("empty_ids", "Rows without job id"),
                           ("ids_back", "Job ids that come back"), ("jobs", "Jobs")], "data_quality.csv")
    totals = {k: sum(r.get(k) or 0 for r in rows)
              for k in ("rows", "repeated", "blip_count", "gaps", "gap_seconds", "empty_ids", "ids_back", "jobs")}
    totals["files"] = len(rows)
    totals["files_with_issues"] = sum(1 for r in rows if (r["repeated"] or r["blip_count"] or r["gaps"]
                                                         or r["empty_ids"] or r["ids_back"]))
    return jsonify({"rows": rows, "totals": totals})
