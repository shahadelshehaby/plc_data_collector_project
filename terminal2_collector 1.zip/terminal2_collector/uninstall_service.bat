@echo off
REM Run as administrator. Stops all cranes and removes the service.
"%~dp0nssm.exe" stop CraneCollectorT2
"%~dp0nssm.exe" remove CraneCollectorT2 confirm
pause
