"use strict";
/* =====================================================================
   Gantry Watch - analysis tabs (Cases, Performance, Pickups, Energy,
   Data quality). Reads /api/results/... (results_api.py). Uses the
   helpers from app.js ($, $$, el, api, fmtDate, addDays, showTab, toast).
   Results update by themselves: every few seconds the page asks whether
   anything new was analysed (after an upload or NAS sync) and reloads the
   open tab if so.
   ===================================================================== */
const ANA_TABS = ["cases", "performance", "pickups", "energy", "quality"];
const ana = {
  meta: null,
  revision: null,
  tab: null,
  loadedRev: {},           // tab -> revision + filter key it last showed
  limit: { cases: 50, performance: 50, pickups: 50 },
  open: { cases: new Set(), performance: new Set(), pickups: new Set(), quality: new Set() },
  from: "", to: "", lanes: new Set(), machines: null,   // machines: null = all cranes
  updatedAt: null,
  timer: null,
};

/* ------------------------------------------------------------ formatting */
function fmtDur(s) {
  if (s === null || s === undefined || isNaN(s)) return "–";
  s = Math.round(s);
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  return `${Math.floor(s / 3600)} h ${String(Math.round((s % 3600) / 60)).padStart(2, "0")} min`;
}
function fmtKwh(v, unit = true) {
  if (v === null || v === undefined || isNaN(v)) return "–";
  const a = Math.abs(v);
  const txt = a >= 100 ? v.toFixed(0) : a >= 10 ? v.toFixed(1) : a >= 0.1 ? v.toFixed(2) : v.toFixed(3);
  return unit ? `${txt} kWh` : txt;
}
function fmtM(v) { return v === null || v === undefined ? "–" : `${v.toFixed(1)} m`; }
function fmtN(v) { return (v || 0).toLocaleString(); }
function pct(a, b) { return b ? Math.round((100 * a) / b) : 0; }
function oneDay() { return ana.from && ana.from === ana.to; }
function fmtWhen(t) {
  if (!t) return "";
  const [d, time] = t.split(" ");
  if (oneDay()) return time;
  const [, m, day] = d.split("-");
  return `${day}.${m} ${time}`;
}
function verdictPill(v) {
  const cls = { necessary: "green", unnecessary: "red", unknown: "grey" }[v] || "grey";
  return el("span", { class: `pill ${cls}`, text: v });
}
function outcomePill(o) {
  const map = { successful: ["green", "Successful"], unnecessary: ["red", "Unnecessary moves"], open: ["grey", "Open"] };
  const [cls, text] = map[o] || ["grey", o];
  return el("span", { class: `pill ${cls}`, text });
}
const KIND_TEXT = { reposition: "Reposition (3)", pickup: "Pickup (1/2)" };
function figure(num, label, sub, cls) {
  return el("div", { class: `figure${cls ? " " + cls : ""}` },
    el("span", { class: "num", text: num }), el("span", { class: "lbl", text: label }),
    sub ? el("span", { class: "sub", text: sub }) : null);
}
function table(node, head, rows, emptyText) {
  node.replaceChildren(
    el("thead", {}, el("tr", {}, head.map(h => el("th", { text: h })))),
    el("tbody", {}, rows.length ? rows : el("tr", {}, el("td", { colspan: head.length, class: "muted", text: emptyText || "Nothing to show for these filters." }))));
}
function numTd(v, fmt = fmtN, flagIfPositive = false) {
  return el("td", { class: `num${!v ? " zero" : flagIfPositive ? " flag" : ""}`, text: fmt(v) });
}
function craneCell(m) {
  return el("td", {}, el("button", { class: "machine-chip link-chip", text: m, title: `Show only ${m}`,
    onclick: e => { e.stopPropagation(); ana.machines = new Set([m]); renderAnaFilters(); filtersChanged(); } }));
}

/* ------------------------------------------------------------ filters */
function anaQuery(extra = {}) {
  const p = new URLSearchParams();
  if (ana.from) p.set("date_from", ana.from);
  if (ana.to) p.set("date_to", ana.to);
  if (ana.lanes.size) p.set("lanes", [...ana.lanes].join(","));
  if (ana.machines) p.set("machines", [...ana.machines].join(",") || "-");
  for (const [k, v] of Object.entries(extra)) if (v !== null && v !== undefined && v !== "") p.set(k, v);
  return p.toString();
}
function filterKey() { return anaQuery(); }

function saveAnaFilters() {
  try {
    localStorage.setItem("gw.anaFilters", JSON.stringify({ from: ana.from, to: ana.to, lanes: [...ana.lanes],
      machines: ana.machines ? [...ana.machines] : null }));
  } catch { /* storage not available: filters just aren't remembered */ }
}
function loadAnaFilters() {
  try {
    const f = JSON.parse(localStorage.getItem("gw.anaFilters") || "null");
    if (!f) return false;
    ana.from = f.from || ""; ana.to = f.to || "";
    ana.lanes = new Set(f.lanes || []);
    ana.machines = f.machines ? new Set(f.machines) : null;
    return true;
  } catch { return false; }
}

function setRange(r) {
  const m = ana.meta;
  if (!m || !m.date_max) return;
  const end = m.date_max;
  ana.to = end;
  ana.from = r === "all" ? m.date_min : r === "latest" ? end : [addDays(end, -(Number(r) - 1)), m.date_min].sort().at(-1);
}

function visibleCranes() {
  return (ana.meta ? ana.meta.machines : []).filter(m => !ana.lanes.size || ana.lanes.has(m.lane));
}

function renderAnaFilters() {
  const m = ana.meta;
  if (!m) return;
  for (const id of ["#anaFrom", "#anaTo"]) { $(id).min = m.date_min || ""; $(id).max = m.date_max || ""; }
  $("#anaFrom").value = ana.from;
  $("#anaTo").value = ana.to;
  for (const l of [...ana.lanes]) if (!m.lanes.includes(l)) ana.lanes.delete(l);
  $("#anaLanes").replaceChildren(
    el("span", { class: "inline-label", text: "Lanes" }),
    ...m.lanes.map(l => el("button", { type: "button", "aria-pressed": String(ana.lanes.has(l)), text: l, title: `Lane ${l}`,
      onclick: () => { ana.lanes.has(l) ? ana.lanes.delete(l) : ana.lanes.add(l); renderAnaFilters(); filtersChanged(); } })));
  const cranes = visibleCranes();
  $("#anaCranes").replaceChildren(...cranes.map(c => {
    const input = el("input", { type: "checkbox", value: c.machine, checked: !ana.machines || ana.machines.has(c.machine) });
    input.addEventListener("change", () => {
      if (!ana.machines) ana.machines = new Set(visibleCranes().map(x => x.machine));
      input.checked ? ana.machines.add(c.machine) : ana.machines.delete(c.machine);
      if (visibleCranes().every(x => ana.machines.has(x.machine))) ana.machines = null;
      updateCraneSummary();
      filtersChanged();
    });
    const n = c.dates.filter(d => (!ana.from || d >= ana.from) && (!ana.to || d <= ana.to)).length;
    return el("label", { class: n ? "" : "nodata", title: n ? `${n} day(s) with results in the selected dates` : "No results in the selected dates" },
      input, c.machine, el("small", { text: c.lane }));
  }));
  updateCraneSummary();
}
function updateCraneSummary() {
  const cranes = visibleCranes();
  const chosen = ana.machines ? cranes.filter(c => ana.machines.has(c.machine)) : cranes;
  $("#anaCraneSummary").textContent = !ana.machines ? `All cranes (${cranes.length})`
    : chosen.length === 1 ? `Crane ${chosen[0].machine}` : `${chosen.length} of ${cranes.length} cranes`;
}

function filtersChanged() {
  saveAnaFilters();
  for (const k of Object.keys(ana.limit)) ana.limit[k] = 50;
  for (const s of Object.values(ana.open)) s.clear();
  loadAnaTab(true);
}

$("#anaFrom").addEventListener("change", e => { ana.from = e.target.value; if (ana.to && ana.from > ana.to) ana.to = ana.from; renderAnaFilters(); filtersChanged(); });
$("#anaTo").addEventListener("change", e => { ana.to = e.target.value; if (ana.from && ana.from > ana.to) ana.from = ana.to; renderAnaFilters(); filtersChanged(); });
$$("[data-ana-range]").forEach(b => b.addEventListener("click", () => { setRange(b.dataset.anaRange); renderAnaFilters(); filtersChanged(); }));
$("#anaCranesAll").addEventListener("click", () => { ana.machines = null; renderAnaFilters(); filtersChanged(); });
$("#anaCranesNone").addEventListener("click", () => { ana.machines = new Set(); renderAnaFilters(); filtersChanged(); });
document.addEventListener("click", e => { const d = $("#anaCranePick"); if (d.open && !d.contains(e.target)) d.open = false; });

/* ------------------------------------------------------------ meta + refresh */
async function loadMeta() {
  const m = await api("GET", "/api/results/meta");
  const first = !ana.meta;
  ana.meta = m;
  if (first) {
    const remembered = loadAnaFilters();
    if (!remembered || !ana.from || !ana.to) setRange("7");
  }
  if (m.date_max && (!ana.from || !ana.to)) setRange("7");
  renderAnaFilters();
  return m;
}

function setAnaStatus() {
  const m = ana.meta;
  const box = $("#anaStatus");
  if (!m) return;
  const working = m.waiting > 0;
  box.className = `ana-status${working ? " working" : ""}`;
  const when = ana.updatedAt ? ana.updatedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "";
  box.textContent = working
    ? `Analysing ${m.waiting} file${m.waiting === 1 ? "" : "s"}… results update by themselves.`
    : m.not_analysed
      ? `${m.not_analysed} file${m.not_analysed === 1 ? " has" : "s have"} new rows or settings not analysed yet: they are analysed when a report needs them, or switch on "Analyze the new rows right away" in Settings > NAS sync.`
      : `Up to date${when ? `, updated ${when}` : ""}. New NAS data is added automatically.`;
}

async function tick() {
  if (!ANA_TABS.includes(ana.tab) || document.hidden) return;
  try {
    const before = ana.meta ? ana.meta.revision : null;
    await loadMeta();
    if (ana.meta.revision !== before) loadAnaTab(false);
    else setAnaStatus();
  } catch { /* try again next time */ }
}

window.analysisShow = async function (name) {
  ana.tab = name;
  const on = ANA_TABS.includes(name);
  $("#anaFilters").hidden = !on;
  if (!on) { $("#anaEmpty").hidden = true; return; }
  clearInterval(ana.timer);
  ana.timer = setInterval(tick, 8000);
  try { await loadMeta(); } catch (e) { toast(e.errors ? e.errors[0] : "Couldn't load results.", true); return; }
  loadAnaTab(false);
};

async function loadAnaTab(force) {
  const tab = ana.tab;
  if (!ANA_TABS.includes(tab)) return;
  const has = ana.meta && ana.meta.machines.length > 0;
  $("#anaEmpty").hidden = has;
  $(`#tab-${tab}`).hidden = !has;
  $("#anaFilters").hidden = !has && !ana.meta.waiting;
  if (!has) { setAnaStatus(); return; }
  const key = `${ana.meta.revision}|${filterKey()}|${JSON.stringify(ana.limit)}`;
  if (!force && ana.loadedRev[tab] === key) { setAnaStatus(); return; }
  try {
    await LOADERS[tab]();
    ana.loadedRev[tab] = key;
    ana.updatedAt = new Date();
  } catch (e) {
    toast(e.errors ? e.errors[0] : "Couldn't load results.", true);
  }
  setAnaStatus();
}

/* ------------------------------------------------------------ expandable rows */
function expandable(tab, id, cells, colspan, buildDetail) {
  const tr = el("tr", { class: "row", tabindex: "0", "aria-expanded": "false" }, cells);
  const toggle = async () => {
    const next = tr.nextElementSibling;
    if (next && next.classList.contains("detail")) {
      next.remove(); tr.classList.remove("open"); tr.setAttribute("aria-expanded", "false"); ana.open[tab].delete(id);
      return;
    }
    tr.classList.add("open"); tr.setAttribute("aria-expanded", "true"); ana.open[tab].add(id);
    const td = el("td", { colspan }, el("p", { class: "muted", text: "Loading…" }));
    tr.after(el("tr", { class: "detail" }, td));
    try { td.replaceChildren(await buildDetail()); }
    catch (e) { td.replaceChildren(el("p", { class: "muted", text: e.errors ? e.errors[0] : "Couldn't load the details." })); }
  };
  tr.addEventListener("click", e => { if (!e.target.closest("button, a")) toggle(); });
  tr.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });
  if (ana.open[tab].has(id)) setTimeout(() => { ana.open[tab].delete(id); toggle(); }, 0);
  return tr;
}

function chartImg(url, alt) {
  const img = el("img", { src: url, alt, loading: "lazy" });
  img.addEventListener("error", () => img.replaceWith(el("p", { class: "muted", text: "No chart for this one (its file may be re-analysing)." })));
  return img;
}

function moreRow(box, tab, shown, total) {
  box.replaceChildren();
  if (total > shown) {
    box.append(el("span", { text: `Showing ${fmtN(shown)} of ${fmtN(total)}.` }),
      el("button", { class: "btn small", text: "Show more", onclick: () => { ana.limit[tab] += 200; loadAnaTab(true); } }));
  } else if (total) {
    box.append(el("span", { text: `${fmtN(total)} in total.` }));
  }
}

function eventsTable(events) {
  const t = el("table", { class: "data-table" });
  table(t, ["Start", "Job", "Workorder", "Necessity", "Distance", "Time", "Energy", "Notes"], events.map(e => el("tr", {},
    el("td", { class: "num", text: fmtWhen(e.t_start) }),
    el("td", { text: KIND_TEXT[e.kind] || e.kind }),
    el("td", { class: "num", text: e.workorder }),
    el("td", {}, verdictPill(e.verdict)),
    el("td", { class: "num", text: fmtM(e.distance_m) }),
    el("td", { class: "num", text: fmtDur(e.duration_s) }),
    el("td", { class: "num", text: fmtKwh(e.energy_kwh) }),
    el("td", { class: "note", text: [e.reason, ...(e.warnings || [])].filter(Boolean).join(" ") }))));
  return el("div", { class: "table-wrap" }, t);
}

async function caseDetail(caseId) {
  const c = await api("GET", `/api/results/case?id=${encodeURIComponent(caseId)}`);
  return el("div", { class: "detail-grid" },
    el("p", { class: "note", text: `Case ${c.case_num} of ${c.machine} on ${fmtDate(c.date)}: ${c.n_moves} job${c.n_moves === 1 ? "" : "s"}, ` +
      `${c.n_unnecessary} unnecessary, ${fmtDur(c.duration_s)} in total` + (c.closed ? "." : ". Not completed yet (open).") }),
    chartImg(`/api/results/case.png?id=${encodeURIComponent(caseId)}`, `Case chart for ${c.machine}`),
    eventsTable(c.events));
}

/* ------------------------------------------------------------ Cases */
function radioValue(name) { const r = $(`input[name="${name}"]:checked`); return r ? r.value : ""; }

async function loadCases() {
  const outcome = radioValue("casesOutcome");
  const sort = $("#casesSort").value;
  const q = anaQuery({ outcome, sort, dir: sort === "crane" ? "asc" : "desc", limit: ana.limit.cases });
  const d = await api("GET", `/api/results/cases?${q}`);
  $("#casesCsv").href = `/api/results/cases?${anaQuery({ outcome, sort, format: "csv" })}`;
  const t = { cases: 0, moves: 0, unnecessary: 0, wasted_s: 0, wasted_kwh: 0 };
  const by = {};
  for (const r of d.totals) {
    by[r.outcome] = r.cases;
    for (const k of Object.keys(t)) t[k] += r[k] || 0;
  }
  const ok = by.successful || 0, bad = by.unnecessary || 0, open = by.open || 0;
  $("#casesFigures").replaceChildren(
    figure(fmtN(t.cases), "Cases", `${fmtN(t.moves)} jobs`),
    figure(fmtN(ok), "Successful", `${pct(ok, t.cases)}% of cases`, "good"),
    figure(fmtN(bad), "With unnecessary moves", `${pct(bad, t.cases)}% of cases`, bad ? "bad" : ""),
    figure(fmtN(t.unnecessary), "Unnecessary moves", `${pct(t.unnecessary, t.moves)}% of jobs`),
    figure(fmtDur(t.wasted_s), "Time wasted", "in unnecessary moves"),
    figure(fmtKwh(t.wasted_kwh), "Energy wasted"),
    ...(open ? [figure(fmtN(open), "Open", "not completed yet")] : []));
  table($("#casesByCrane"), ["Crane", "Lane", "Cases", "Successful", "With unnecessary", "Open", "Success rate", "Unnecessary moves", "Time wasted", "Energy wasted"],
    d.by_machine.map(r => el("tr", {},
      craneCell(r.machine),
      el("td", {}, el("span", { class: "lane-tag", text: laneOfAna(r.machine) })),
      numTd(r.cases), numTd(r.successful), numTd(r.unnecessary_cases, fmtN, true), numTd(r.open),
      el("td", { class: "bar-cell", title: `${pct(r.successful, r.cases)}% successful` },
        el("div", { class: "bar" },
          el("span", { class: "ok", style: `width:${pct(r.successful, r.cases)}%` }),
          el("span", { class: "bad", style: `width:${pct(r.unnecessary_cases, r.cases)}%` }),
          el("span", { class: "open", style: `width:${pct(r.open, r.cases)}%` }))),
      numTd(r.unnecessary, fmtN, true), el("td", { class: "num", text: fmtDur(r.wasted_s) }),
      el("td", { class: "num", text: fmtKwh(r.wasted_kwh) }))),
    "No cases for these filters.");
  table($("#casesTable"), ["Crane", "Start", "Jobs", "Unnecessary", "Time", "Time wasted", "Distance", "Energy wasted", "Result"],
    d.rows.map(c => expandable("cases", c.case_id, [
      el("td", {}, el("span", { class: "machine-chip", text: c.machine })),
      el("td", { class: "num", text: fmtWhen(c.t_start) }),
      el("td", { title: c.workorders.join(", "), text: c.kinds.map(k => (k === "pickup" ? "1" : "3")).join(" → ") }),
      numTd(c.n_unnecessary, fmtN, true),
      el("td", { class: "num", text: fmtDur(c.duration_s) }),
      el("td", { class: "num", text: c.wasted_s ? fmtDur(c.wasted_s) : "–" }),
      el("td", { class: "num", text: fmtM(c.distance_m) }),
      el("td", { class: "num", text: c.wasted_kwh ? fmtKwh(c.wasted_kwh) : "–" }),
      el("td", {}, outcomePill(c.outcome)),
    ], 9, () => caseDetail(c.case_id))),
    "No cases of this kind for these filters.");
  moreRow($("#casesMore"), "cases", d.rows.length, d.count);
}
$$('input[name="casesOutcome"]').forEach(r => r.addEventListener("change", () => { ana.limit.cases = 50; ana.open.cases.clear(); loadAnaTab(true); }));
$("#casesSort").addEventListener("change", () => { ana.limit.cases = 50; loadAnaTab(true); });

function laneOfAna(machine) {
  const m = ana.meta && ana.meta.machines.find(x => x.machine === machine);
  return m ? m.lane : "";
}

/* ------------------------------------------------------------ Performance */
const PERF_PILL = { speed: ["amber", "Slower"], aborted: ["red", "Aborted"], no_movement: ["grey", "No movement"],
  sequence: ["amber", "Sequence"], reference: ["red", "Not at reference"] };
function perfPills(e) {
  const out = [];
  if (e.perf === "issue") out.push("speed");
  if (e.perf === "aborted") out.push("aborted");
  if (e.perf === "no_movement") out.push("no_movement");
  if (e.seq_abnormal) out.push("sequence");
  if (e.reached_ref === 0) out.push("reference");
  if (!out.length) return el("span", { class: "pill green", text: "OK" });
  return out.map(k => el("span", { class: `pill ${PERF_PILL[k][0]}`, text: PERF_PILL[k][1] }));
}
let perfGroupsBuilt = false;
async function loadPerformance() {
  const issue = $("#perfIssue").value || "issues";
  const d = await api("GET", `/api/results/performance?${anaQuery({ issue, limit: ana.limit.performance })}`);
  if (!perfGroupsBuilt) {
    $("#perfIssue").replaceChildren(el("option", { value: "issues", text: "Any issue" }),
      ...d.groups.map(g => el("option", { value: g.key, text: g.label })), el("option", { value: "all", text: "All moves" }));
    $("#perfIssue").value = issue;
    perfGroupsBuilt = true;
  }
  $("#perfCsv").href = `/api/results/performance?${anaQuery({ issue, format: "csv" })}`;
  const t = d.totals || {};
  const moves = t.moves || 0;
  $("#perfFigures").replaceChildren(
    figure(fmtN(moves), "Reposition moves", t.avg_actual_s ? `avg ${fmtDur(t.avg_actual_s)} (expected ${fmtDur(t.avg_expected_s)})` : ""),
    figure(fmtN(t.ok), "No issue", `${pct(t.ok, moves)}% of moves`, "good"),
    ...d.groups.filter(g => g.key !== "ok").map(g =>
      figure(fmtN(t[g.key]), g.label, `${pct(t[g.key], moves)}% of moves`, t[g.key] ? "warn" : "")));
  table($("#perfByCrane"), ["Crane", "Moves", "No issue", ...d.groups.filter(g => g.key !== "ok").map(g => g.label)],
    d.by_machine.map(r => el("tr", {}, craneCell(r.grp), numTd(r.moves),
      el("td", { class: "num", text: `${pct(r.ok, r.moves)}%` }),
      ...d.groups.filter(g => g.key !== "ok").map(g => numTd(r[g.key], fmtN, true)))));
  table($("#perfTable"), ["Crane", "Start", "Workorder", "Axis", "Distance", "Expected", "Actual", "Result"],
    d.rows.map(e => expandable("performance", e.eid, [
      el("td", {}, el("span", { class: "machine-chip", text: e.machine })),
      el("td", { class: "num", text: fmtWhen(e.t_start) }),
      el("td", { class: "num", text: e.workorder }),
      el("td", { text: e.axis || "" }),
      el("td", { class: "num", text: fmtM(e.distance_m) }),
      el("td", { class: "num", text: fmtDur(e.expected_s) }),
      el("td", { class: "num", text: fmtDur(e.actual_s) }),
      el("td", {}, perfPills(e)),
    ], 8, async () => el("div", { class: "detail-grid" },
      el("p", { class: "note", text: [e.perf_msg, e.seq_steps ? `Steps: ${e.seq_steps}.` : "", ...(e.warnings || [])].filter(Boolean).join(" ") }),
      chartImg(`/api/results/move.png?id=${encodeURIComponent(e.eid)}`, "Speed chart"),
      e.case_id ? el("button", { class: "btn small", text: "Show its case", onclick: () => openCase(e.case_id) }) : null))),
    "No moves of this kind for these filters.");
  moreRow($("#perfMore"), "performance", d.rows.length, d.count);
}
$("#perfIssue").addEventListener("change", () => { ana.limit.performance = 50; ana.open.performance.clear(); loadAnaTab(true); });

async function openCase(caseId) {
  ana.open.cases.clear();
  ana.open.cases.add(caseId);
  const all = $('input[name="casesOutcome"][value=""]');
  all.checked = true;
  $("#casesSort").value = "time";
  ana.limit.cases = 1000;
  showTab("cases");
  setTimeout(() => {
    const row = [...$$("#casesTable tr.row")].find(r => r.classList.contains("open"));
    if (row) row.scrollIntoView({ block: "center" });
  }, 600);
}

/* ------------------------------------------------------------ Pickups */
async function loadPickups() {
  const verdict = radioValue("pickVerdict");
  const d = await api("GET", `/api/results/pickups?${anaQuery({ verdict, limit: ana.limit.pickups })}`);
  $("#pickCsv").href = `/api/results/pickups?${anaQuery({ verdict, format: "csv" })}`;
  const t = d.totals || {};
  $("#pickFigures").replaceChildren(
    figure(fmtN(t.jobs), "Pickup jobs", `${fmtN(t.with_setdown)} set down`),
    figure(fmtN(t.necessary), "Necessary", `${pct(t.necessary, t.jobs)}%`, "good"),
    figure(fmtN(t.unnecessary), "Unnecessary", `${pct(t.unnecessary, t.jobs)}%`, t.unnecessary ? "bad" : ""),
    figure(fmtN(t.unknown), "Unknown", "data ended first"),
    figure(fmtDur(t.wasted_s), "Time wasted"),
    figure(fmtKwh(t.wasted_kwh), "Energy wasted"));
  table($("#pickByCrane"), ["Crane", "Jobs", "Necessary", "Unnecessary", "Unknown", "Set down", "Time wasted", "Energy wasted"],
    d.by_machine.map(r => el("tr", {}, craneCell(r.grp), numTd(r.jobs), numTd(r.necessary), numTd(r.unnecessary, fmtN, true),
      numTd(r.unknown), numTd(r.with_setdown), el("td", { class: "num", text: fmtDur(r.wasted_s) }),
      el("td", { class: "num", text: fmtKwh(r.wasted_kwh) }))));
  table($("#pickTable"), ["Crane", "Start", "Workorder", "Set down", "Time", "Necessity", "Reason"],
    d.rows.map(e => expandable("pickups", e.eid, [
      el("td", {}, el("span", { class: "machine-chip", text: e.machine })),
      el("td", { class: "num", text: fmtWhen(e.t_start) }),
      el("td", { class: "num", text: e.workorder }),
      el("td", { text: e.has_setdown ? "Yes" : "No" }),
      el("td", { class: "num", text: fmtDur(e.duration_s) }),
      el("td", {}, verdictPill(e.verdict)),
      el("td", { class: "note", text: e.reason || "" }),
    ], 7, () => (e.case_id ? caseDetail(e.case_id) : Promise.resolve(el("p", { class: "muted", text: "Not part of a case yet." }))))),
    "No pickup jobs of this kind for these filters.");
  moreRow($("#pickMore"), "pickups", d.rows.length, d.count);
}
$$('input[name="pickVerdict"]').forEach(r => r.addEventListener("change", () => { ana.limit.pickups = 50; ana.open.pickups.clear(); loadAnaTab(true); }));

/* ------------------------------------------------------------ Energy */
async function loadEnergy() {
  const group = radioValue("energyGroup") || "date";
  const d = await api("GET", `/api/results/energy?${anaQuery({ group })}`);
  $("#energyCsv").href = `/api/results/energy?${anaQuery({ group, format: "csv" })}`;
  const t = d.totals || {};
  const cost = d.cost && d.cost.per_kwh ? (v => `${(v * d.cost.per_kwh).toFixed(2)} ${d.cost.currency || ""}`) : null;
  const basisText = { consumed: "only the energy used", net: "net energy (used minus fed back)" }[d.basis] || "the energy basis set in Settings";
  $("#energyBasis").textContent = `"Counted" follows Settings > Energy: ${basisText}.`;
  $("#energyFigures").replaceChildren(
    figure(fmtKwh(t.used_kwh), "Used"),
    figure(fmtKwh(t.fed_kwh), "Fed back"),
    figure(fmtKwh(t.net_kwh), "Net"),
    figure(fmtKwh(t.counted_kwh), "Counted", cost ? cost(t.counted_kwh || 0) : ""),
    figure(fmtKwh(t.wasted_kwh), "Wasted", cost ? cost(t.wasted_kwh || 0) : "in unnecessary moves", t.wasted_kwh ? "bad" : ""));
  const max = Math.max(1e-9, ...d.rows.map(r => r.used_kwh || 0));
  const label = { date: "Day", machine: "Crane", lane: "Lane" }[group];
  const head = [label, "Jobs", "Used", "Fed back", "Net", "", "Counted", "Wasted", "Repositions", "Pickups"];
  table($("#energyTable"), head, d.rows.map(r => el("tr", {},
    group === "machine" ? craneCell(r.grp) : el("td", { class: "num", text: group === "date" ? fmtDate(r.grp) : r.grp }),
    numTd(r.jobs),
    el("td", { class: "num", text: fmtKwh(r.used_kwh, false) }),
    el("td", { class: "num", text: fmtKwh(r.fed_kwh, false) }),
    el("td", { class: "num", text: fmtKwh(r.net_kwh, false) }),
    el("td", { class: "bar-cell", title: `Used ${fmtKwh(r.used_kwh)}, fed back ${fmtKwh(r.fed_kwh)}` },
      el("div", { class: "bar" },
        el("span", { class: "used", style: `width:${(100 * ((r.used_kwh || 0) - (r.fed_kwh || 0))) / max}%` }),
        el("span", { class: "fed", style: `width:${(100 * (r.fed_kwh || 0)) / max}%` }))),
    el("td", { class: "num", text: fmtKwh(r.counted_kwh, false) }),
    numTd(r.wasted_kwh, v => fmtKwh(v, false), true),
    el("td", { class: "num", text: fmtKwh(r.reposition_kwh, false) }),
    el("td", { class: "num", text: fmtKwh(r.pickup_kwh, false) }))));
  $("#energyTable thead th:nth-child(6)").replaceChildren(el("span", { class: "legend" },
    el("span", {}, el("i", { style: "background:var(--chart-blue)" }), "net"),
    el("span", {}, el("i", { style: "background:var(--chart-teal)" }), "fed back")));
}
$$('input[name="energyGroup"]').forEach(r => r.addEventListener("change", () => loadAnaTab(true)));

/* ------------------------------------------------------------ Data quality */
async function loadQuality() {
  const d = await api("GET", `/api/results/quality?${anaQuery()}`);
  $("#qualityCsv").href = `/api/results/quality?${anaQuery({ format: "csv" })}`;
  const t = d.totals;
  $("#qualityFigures").replaceChildren(
    figure(fmtN(t.files), "Files", `${fmtN(t.rows)} rows`),
    figure(fmtN(t.files_with_issues), "Files with findings", "", t.files_with_issues ? "warn" : "good"),
    figure(fmtN(t.repeated), "Repeated seconds", "dropped"),
    figure(fmtN(t.blip_count), "Job id blips", "ignored"),
    figure(fmtN(t.gaps), "Gaps over 5 s", `${fmtDur(t.gap_seconds)} missing`),
    figure(fmtN(t.ids_back), "Job ids that come back"));
  table($("#qualityTable"), ["Crane", "File", "Data from", "To", "Rows", "Repeated", "Blips", "Gaps", "Longest gap", "No job id", "Ids back"],
    d.rows.map(r => {
      const cells = [
        el("td", {}, el("span", { class: "machine-chip", text: r.machine })),
        el("td", { class: "fname", title: r.name, text: r.name }),
        el("td", { class: "num", text: (r.first || "").replace(/^(\d+)-(\d+)-(\d+)-/, "$3.$2.$1 ") }),
        el("td", { class: "num", text: (r.last || "").replace(/^(\d+)-(\d+)-(\d+)-/, "$3.$2.$1 ") }),
        numTd(r.rows), numTd(r.repeated, fmtN, true), numTd(r.blip_count, fmtN, true), numTd(r.gaps, fmtN, true),
        el("td", { class: "num", text: r.longest_gap ? fmtDur(r.longest_gap) : "–" }),
        numTd(r.empty_ids, fmtN, true), numTd(r.ids_back, fmtN, true),
      ];
      if (!r.blip_count) return el("tr", {}, cells);
      return expandable("quality", r.fid, cells, 11, async () => {
        const t2 = el("table", { class: "data-table" });
        table(t2, ["Time", "Job id for a moment", "For"], r.blips.map(b => el("tr", {},
          el("td", { class: "num", text: (b.time || "").replace(/^(\d+)-(\d+)-(\d+)-/, "$3.$2.$1 ") }),
          el("td", { class: "num", text: b.id }), el("td", { class: "num", text: fmtDur(b.seconds) }))));
        return el("div", { class: "detail-grid" },
          el("p", { class: "note", text: "The job id changed for a moment and then came back. These rows were kept in the surrounding job." }),
          el("div", { class: "table-wrap" }, t2));
      });
    }),
    "No files for these filters. Files analysed before this version show here after they are analysed again.");
}

const LOADERS = { cases: loadCases, performance: loadPerformance, pickups: loadPickups, energy: loadEnergy, quality: loadQuality };
document.addEventListener("visibilitychange", () => { if (!document.hidden) tick(); });
